<?php
declare(strict_types=1);

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');

$configPath = __DIR__ . '/config.php';
if (!file_exists($configPath)) {
    respond(500, ['error' => 'API config.php is missing. Copy config.sample.php to config.php and add database credentials.']);
}

$config = require $configPath;

/**
 * Modules are loaded defensively because this site is deployed by uploading files, and a
 * partial upload is normal rather than exceptional. A bare require_once on a file that did
 * not make it up is a fatal error before any handler runs, which takes the ENTIRE API down
 * - every route, including ones that do not use the missing module - and returns an empty
 * 500 that says nothing about why. That has happened; this makes it impossible.
 *
 * Anything missing is recorded instead. Routes that need it fail individually with a
 * message naming the file, and everything else keeps working.
 */
/**
 * One timezone for everything.
 *
 * PHP and MySQL each default to whatever the host decided, and they disagreed by an hour on
 * both the live server and this laptop. Anything written by one and compared by the other -
 * a lockout expiry, an event's start time deciding whether it is upcoming or past - was
 * wrong by that hour.
 *
 * Set here rather than in php.ini because php.ini is not reliably editable on shared
 * hosting. Nairobi because that is where the society and its events are: a date an admin
 * types should mean what it says.
 */
date_default_timezone_set('Africa/Nairobi');

$missingModules = [];
foreach (['portal-mail', 'mpesa', 'throttle', 'mfa', 'security-assessment', 'blog', 'social-ingest', 'invites', 'crypto', 'input-guard', 'events', 'attendance', 'ict', 'ict-infrastructure', 'ict-assets', 'ict-credentials', 'ict-licenses', 'ict-tickets', 'academy', 'academy-assessments', 'academy-certificates', 'membership', 'elections', 'welfare', 'abstracts', 'abstracts-review', 'abstracts-decisions', 'abstracts-figures', 'conference', 'conference-api', 'conference-programme', 'conference-sponsors', 'conference-groups', 'conference-survey', 'conference-speakers', 'conference-presentations', 'proof', 'qr', 'google-signin', 'mdt', 'careers', 'directory', 'newsletter', 'staff', 'staff-portal', 'staff-field', 'staff-timesheet', 'staff-payroll', 'staff-procurement', 'staff-appraisal', 'staff-geo', 'staff-hr-import', 'passkey', 'migrate', 'view-as'] as $module) {
    $modulePath = __DIR__ . '/lib/' . $module . '.php';
    if (is_file($modulePath)) {
        require_once $modulePath;
    } else {
        $missingModules[] = 'lib/' . $module . '.php';
        error_log("API module not deployed: lib/{$module}.php");
    }
}

/**
 * Rate limiting degrades to the previous behaviour when its module is absent - no limiting,
 * but authentication still works. A portal nobody can log into is a worse outcome than one
 * missing a control it did not have last week, and the threat assessment reports the module
 * as missing so it cannot pass unnoticed.
 */
if (!function_exists('throttleCheck')) {
    function throttleCheck(PDO $pdo, array $config, string $action, string $subject): void {}
    function throttleFailure(PDO $pdo, array $config, string $action, string $subject): void {}
    function throttleSuccess(PDO $pdo, array $config, string $action, string $subject): void {}
    function authThrottleCheck(PDO $pdo, array $config, string $email): void {}
    function authThrottleFailure(PDO $pdo, array $config, string $email): void {}
    function authThrottleSuccess(PDO $pdo, array $config, string $email): void {}
    function securityLog(PDO $pdo, array $config, string $type, string $severity = 'info',
                         ?string $action = null, ?string $detail = null, ?int $userId = null): void {}
}

/**
 * Two-factor degrades differently, and deliberately so. Skipping the second factor because
 * its file is missing would turn a deployment slip into an authentication bypass for
 * exactly the accounts that enrolled to be safest. So these shims cover only the parts that
 * are safe to skip; the login route refuses outright if an enrolled member arrives while
 * the module is absent.
 */
if (!function_exists('botScreen')) {
    function botScreen(array $data, int $minSeconds = 0): ?string { return null; }
    function botScreenOrFakeSuccess(PDO $pdo, array $config, array $data, string $action, array $pretend, int $minSeconds = 0): void {}
    function validateInput(array $data, array $rules): void {}
}

if (!function_exists('cryptoEncrypt')) {
    function cryptoEncrypt(array $config, ?string $plain): ?string { return $plain; }
    function cryptoDecrypt(array $config, ?string $stored): ?string { return $stored; }
    function cryptoAvailable(array $config): bool { return false; }
    // cryptoConfig is shimmed too. mapMember() calls it with no guard of its own, so
    // without this a missing crypto.php would fatal on every member the admin panel lists.
    function cryptoConfig(?array $set = null): array { return []; }
}

if (!function_exists('ictTicketsSummary')) {
    function ictTicketsSummary(PDO $pdo): array {
        return ['open' => 0, 'unassigned' => 0, 'overdue' => 0, 'resolvedThisMonth' => 0,
                'medianResponseHours' => null, 'medianResolutionHours' => null];
    }
}

if (!function_exists('ictLicensesSummary')) {
    function ictLicensesSummary(PDO $pdo): array {
        return ['total' => 0, 'expiringSoon' => 0, 'expired' => 0,
                'annualCost' => 0.0, 'seatsIdle' => 0, 'overAllocated' => 0];
    }
}

if (!function_exists('ictCredentialsSummary')) {
    function ictCredentialsSummary(PDO $pdo): array {
        return ['total' => 0, 'critical' => 0, 'noMfa' => 0, 'criticalNoMfa' => 0,
                'rotationOverdue' => 0, 'noVaultLink' => 0, 'noOwner' => 0];
    }
}

if (!function_exists('ictAssetsSummary')) {
    function ictAssetsSummary(PDO $pdo): array {
        return ['total' => 0, 'byStatus' => [], 'value' => 0.0,
                'warrantyExpiring' => 0, 'maintenanceDue' => 0];
    }
}

if (!function_exists('ictInfraSummary')) {
    function ictInfraSummary(PDO $pdo): array {
        return ['total' => 0, 'bands' => [], 'overall' => 'unknown', 'attention' => []];
    }
}

if (!function_exists('ictCan')) {
    function ictEnsureTables(PDO $pdo): bool { return false; }
    function ictCan(PDO $pdo, array $user, array $config, string $capability): bool { return false; }
    function ictHasAnyAccess(PDO $pdo, array $user, array $config): bool { return false; }
    function ictCapabilitiesFor(PDO $pdo, int $userId): array { return []; }
    function ictCapabilityList(): array { return []; }
    function ictAudit(PDO $pdo, ?int $a, string $b, ?string $c = null, ?string $d = null,
                      ?string $e = null, ?array $f = null, ?array $g = null): void {}
    function ictAuditRecent(PDO $pdo, int $limit = 40): array { return []; }
    function ictRequire(PDO $pdo, array $user, array $config, string $capability): void {
        respond(503, ['error' => 'The ICT module is not deployed.', 'missing' => 'lib/ict.php']);
    }
}

if (!function_exists('attendanceEnsureTables')) {
    function attendanceEnsureTables(PDO $pdo): bool { return false; }
    function tokensSummary(PDO $pdo, int $eventId): array { return []; }
}

if (!function_exists('eventsUpcoming')) {
    function eventsUpcoming(PDO $pdo, int $limit = 50): array { return []; }
    function eventsPast(PDO $pdo, int $limit = 12): array { return []; }
    function eventLegacyShape(array $public): array { return $public; }
}

if (!function_exists('blogRequireTables')) {
    // Reached only if the guards above ever change order; the module check fires first.
    function blogRequireTables(PDO $pdo): void {}
}

if (!function_exists('mfaEnsureColumns')) {
    function mfaEnsureColumns(PDO $pdo): bool { return false; }
    function mfaRequiredForRole(string $role): bool { return false; }
}

// Give the crypto helpers the config once, so decryption works from anywhere. Always
// defined by this point - the real one, or the shim above.
cryptoConfig($config);

/** Refuses a route whose module is absent, saying which file to upload. */
function requireModule(string $function, string $file): void
{
    if (!function_exists($function)) {
        respond(503, [
            'error' => 'This feature is not available: a required file is missing on the server.',
            'missing' => $file,
        ]);
    }
}

$debugValue = array_key_exists('debug', $config) ? $config['debug'] : getenv('RESOK_DEBUG');
$isDebug = filter_var($debugValue ?: false, FILTER_VALIDATE_BOOLEAN);

/**
 * Sends a JSON response and stops. Nothing after a call to this runs.
 *
 * Documented as @return never so static analysis knows execution ends here. The native
 * never type is deliberately not used: it needs PHP 8.1, and if the shared host is on 8.0
 * it would be a parse error - taking down every route in the API, which is the exact
 * failure this project has already had twice. A docblock costs nothing at runtime.
 *
 * @return never
 */
function respond(int $status, array $payload): void {
    // JSON only - never a document. This says so explicitly, so a browser coaxed into
    // rendering a response cannot run anything from it.
    header("Content-Security-Policy: default-src 'none'");
    header('X-Content-Type-Options: nosniff');
    http_response_code($status);
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}

// Used for links people land on by clicking an email (verification, etc.) - a browser
// visits these directly, so they get a branded page instead of raw JSON.
function respondHtmlPage(int $status, string $title, string $message, bool $isError = false, ?string $ctaText = null, ?string $ctaUrl = null): void {
    http_response_code($status);
    header_remove('Content-Type');
    header('Content-Type: text/html; charset=UTF-8');
    header('Cache-Control: no-store');
    $accent = $isError ? '#bc0b22' : '#00932e';
    $icon = $isError ? '&#10060;' : '&#9989;';
    $cta = '';
    if ($ctaText !== null && $ctaUrl !== null) {
        $cta = '<a href="' . htmlspecialchars($ctaUrl, ENT_QUOTES) . '" style="display:inline-block;margin-top:24px;background:' . $accent . ';color:#fff;text-decoration:none;font-weight:700;padding:14px 32px;border-radius:6px;font-size:15px;font-family:Segoe UI,Arial,sans-serif;">' . htmlspecialchars($ctaText, ENT_QUOTES) . '</a>';
    }
    echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . htmlspecialchars($title, ENT_QUOTES) . ' - ReSoK</title></head>'
        . '<body style="margin:0;padding:0;background:#f5f7fa;font-family:Segoe UI,Arial,sans-serif;color:#0f172a;display:flex;align-items:center;justify-content:center;min-height:100vh;">'
        . '<div style="max-width:440px;width:90%;background:#fff;border-radius:12px;box-shadow:0 14px 40px rgba(15,23,42,.10);overflow:hidden;text-align:center;">'
        . '<div style="background:' . $accent . ';height:6px;"></div>'
        . '<div style="padding:40px 32px;">'
        . '<div style="font-size:44px;line-height:1;margin-bottom:16px;">' . $icon . '</div>'
        . '<h1 style="margin:0 0 12px;font-size:22px;">' . htmlspecialchars($title, ENT_QUOTES) . '</h1>'
        . '<p style="margin:0;color:#667085;font-size:15px;line-height:1.6;">' . htmlspecialchars($message, ENT_QUOTES) . '</p>'
        . $cta
        . '</div></div></body></html>';
    exit;
}

function input(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return $_POST ?: [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : ($_POST ?: []);
}

function db(array $config): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        $config['db_host'],
        (int)($config['db_port'] ?? 3306),
        $config['db_name']
    );
    $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    // Pins this connection to the same offset PHP is using, so NOW() and PHP's date() agree.
    // A fixed offset rather than 'Africa/Nairobi', because the named-timezone tables are
    // often not loaded on shared MySQL and setting an unknown name is an error. Kenya has
    // never observed daylight saving, so +03:00 is correct year round.
    try {
        $pdo->exec("SET time_zone = '+03:00'");
    } catch (Throwable $e) {
        // Not fatal. Worth knowing about, but not worth refusing to serve the site over.
        error_log('Could not set the database session timezone: ' . $e->getMessage());
    }
    return $pdo;
}

function requireConfig(array $config): void {
    foreach (['db_name', 'db_user', 'jwt_secret'] as $key) {
        if (empty($config[$key])) respond(500, ['error' => 'Portal API is not configured.']);
    }
    if (strlen((string)$config['jwt_secret']) < 32 || strpos((string)$config['jwt_secret'], 'replace_with') === 0) {
        respond(500, ['error' => 'Portal API is not configured.']);
    }
}

function b64url(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

/**
 * Refuses a save made from a stale copy of a record (30 Oct 2026 audit, item 36).
 *
 * The edit forms send back every field, so when two people had the same record open, the
 * second Save silently undid the first. A form now sends the 'version' it loaded (the row's
 * updated_at); if the row has changed since, the save is refused with 409 and the person is
 * asked to reload. A request without a version (the asset scanner, older pages) is let
 * through as before. updated_at counts seconds, so two saves within one second still race;
 * that is far rarer than the minutes-long overlap this is for.
 */
function editConflictGuard(PDO $pdo, string $table, int $id, array $data): void {
    $version = $data['version'] ?? null;
    if (!is_string($version) || $version === '' || !preg_match('/^[a-z_]+$/', $table)) return;
    $stmt = $pdo->prepare("SELECT updated_at FROM `$table` WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $current = $stmt->fetchColumn();
    if ($current !== false && (string)$current !== $version) {
        respond(409, [
            'error' => 'Someone else changed this while you had it open. Reload it to see their changes, then make yours again.',
            'conflict' => true,
        ]);
    }
}

/**
 * Which key signed a session token: 'current', 'previous', or null when neither did.
 *
 * Changing jwt_secret used to sign everybody out at once (30 Oct 2026 audit, item 70). To
 * rotate it now: move the old value into 'jwt_secret_previous' (a string, or a list) in
 * config.local.php and put the new one in jwt_secret. Sessions signed with the old key keep
 * working and are re-signed with the new one on their next request; after
 * RESOK_SESSION_MAX_LIFETIME (7 days) none can be left, and the old key can be deleted.
 * Short-lived things derived from the key (a view-as cookie, a staff location exception
 * request, a two-factor challenge in progress) are not carried over and simply start again.
 */
function tokenSignedWith(string $body, string $sig, array $config): ?string {
    if (hash_equals(b64url(hash_hmac('sha256', $body, (string)$config['jwt_secret'], true)), $sig)) return 'current';
    foreach ((array)($config['jwt_secret_previous'] ?? []) as $previous) {
        if (strlen((string)$previous) < 32) continue;
        if (hash_equals(b64url(hash_hmac('sha256', $body, (string)$previous, true)), $sig)) return 'previous';
    }
    return null;
}

// Absolute cap on a session: even a member who never stops clicking has to log in again
// after this. In practice the idle timeout below almost always ends the session first.
const RESOK_SESSION_MAX_LIFETIME = 7 * 24 * 60 * 60;

// A session ends after this long with no authenticated request. Every call through auth()
// slides the window forward, so "activity" means any portal page that talks to the API,
// plus /learning on the main site (member-gate.php enforces the same window - keep the
// two constants in step if this changes).
const RESOK_SESSION_IDLE_TIMEOUT = 20 * 60;

// Re-signing the cookie on literally every request would put a Set-Cookie header on every
// JSON response for no benefit. Refreshing at most this often keeps the sliding window
// accurate to within a minute, which is plenty against a 20-minute timeout.
const RESOK_SESSION_REFRESH_INTERVAL = 60;

/**
 * `exp` is the absolute end of the session and is carried over unchanged when a token is
 * refreshed; `seen` is the last-activity stamp that auth() moves forward. Pass $expiresAt
 * to preserve an existing session's cap; omit it when minting a brand new session.
 */
function token(array $payload, string $secret, ?int $expiresAt = null): string {
    $payload['exp'] = $expiresAt ?? (time() + RESOK_SESSION_MAX_LIFETIME);
    $payload['seen'] = time();
    // Set once, when a session is first minted, and carried unchanged through every refresh:
    // iat is what "sign out everywhere" compares against, jti is what a single logout
    // revokes. See sessionLookup().
    $payload['iat'] = (int)($payload['iat'] ?? time());
    $payload['jti'] = (string)($payload['jti'] ?? bin2hex(random_bytes(16)));
    $body = b64url(json_encode($payload));
    $sig = b64url(hash_hmac('sha256', $body, $secret, true));
    return $body . '.' . $sig;
}

/**
 * Whether this request arrived over a secure connection.
 *
 * Checks X-Forwarded-Proto as well as HTTPS, because TLS is terminated at the host's proxy
 * and Apache frequently never sees HTTPS=on - the force-HTTPS rule in .htaccess and the HSTS
 * header both had to learn the same thing.
 *
 * Only a plain-HTTP request on localhost returns false, and that is the one case where a
 * Secure cookie is worse than useless: the browser will not store it, so the session is lost
 * the moment the page makes its first API call.
 */
function requestIsSecure(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') return true;
    if (strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') return true;
    if ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443) return true;
    return false;
}

// httpOnly cookie is the primary session for browser clients (see issueAuthCookie());
// the Authorization header stays supported as a fallback for any non-browser API caller.
// SameSite=Lax + HttpOnly + Secure is treated as sufficient CSRF protection here — every
// state-changing call in this API is a fetch() POST, which Lax already blocks cross-site,
// so no separate CSRF token is issued. Don't "fix" that without re-adding one.
// The cookie itself is given the idle window, not the 7-day cap, so a browser left closed
// past the timeout discards the session on its own instead of sending a token the server
// is only going to reject. Each refresh in auth() extends it again.
function issueAuthCookie(string $token): void {
    setcookie('resok_token', $token, [
        'expires' => time() + RESOK_SESSION_IDLE_TIMEOUT,
        'path' => '/',
        'secure' => requestIsSecure(),
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
}

/**
 * Everything after the first factor has passed - a correct password, or a verified Google
 * token: the second factor if the account has one, then the session cookie and the answer
 * the login page uses to decide where to go. One function, so every way in goes through the
 * same two-factor check.
 *
 * $user needs id, email, role, membership_status, membership_id and cpd_points.
 *
 * @return never
 */
/**
 * The end of a successful second factor, whichever it was (app code, recovery code or
 * passkey): the session cookie and what the login page needs to route the person.
 */
function mfaGrantSession(PDO $pdo, array $config, int $userId, array $extra = []): void
{
    $stmt = $pdo->prepare('SELECT u.id, u.email, u.role, mp.membership_status, mp.membership_id, mp.cpd_points
                             FROM users u LEFT JOIN member_profiles mp ON mp.user_id = u.id WHERE u.id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if (!$user) respond(401, ['error' => 'That sign-in attempt is no longer valid.']);
    if (function_exists('geoGuardSignIn')) geoGuardSignIn($pdo, $config, (int)$user['id'], (string)$user['role']);
    $loginToken = token(['userId' => (int)$user['id'], 'email' => $user['email'], 'role' => $user['role']], $config['jwt_secret']);
    issueAuthCookie($loginToken);
    respond(200, $extra + [
        'token' => $loginToken,
        'user' => [
            'id' => (int)$user['id'],
            'isLearner' => $user['role'] === 'member' && $user['membership_status'] === null,
            'isStaff' => function_exists('staffIs') && staffIs($pdo, (int)$user['id']),
            'isWelfareVoter' => function_exists('welfareDuringWindow') && welfareDuringWindow($pdo, (int)$user['id']),
            'email' => $user['email'],
            'role' => $user['role'],
            'membershipStatus' => $user['membership_status'],
            'membershipId' => $user['membership_id'],
            'cpdPoints' => (int)($user['cpd_points'] ?? 0)
        ]
    ]);
}

function completeLogin(PDO $pdo, array $config, array $user): void
{
    // Second factor. The password is only the first step for anyone whose account can
    // reach member data; the challenge token proves this step passed and nothing more.
    //
    // Read separately rather than joined into the login query. That query must work on a
    // database where the mfa_ columns were never added - if it names a column that does
    // not exist, the SELECT fails and nobody can log in at all, which is how this broke.
    $mfaEnabled = false;
    if (mfaEnsureColumns($pdo)) {
        try {
            $mfaStmt = $pdo->prepare('SELECT mfa_enabled FROM users WHERE id = ? LIMIT 1');
            $mfaStmt->execute([(int)$user['id']]);
            $mfaEnabled = (bool)(int)($mfaStmt->fetch()['mfa_enabled'] ?? 0);
        } catch (Throwable $e) {
            error_log('Could not read two-factor state: ' . $e->getMessage());
        }
    }
    if ($mfaEnabled) {
        // Refuse rather than wave them through: this member enrolled precisely so that
        // a password alone would not be enough.
        requireModule('mfaIssueChallenge', 'lib/mfa.php');
        securityLog($pdo, $config, 'mfa_challenge_issued', 'info', 'login', null, (int)$user['id']);
        // A passkey (face or fingerprint) can stand in for the code; the page offers it only
        // when this account has one.
        $hasPasskey = function_exists('passkeyCount') && passkeyCount($pdo, (int)$user['id']) > 0;
        respond(200, [
            'mfaRequired' => true,
            'challenge' => mfaIssueChallenge($config, (int)$user['id']),
            'passkey' => $hasPasskey,
            'message' => $hasPasskey ? 'Use your face or fingerprint, or enter the code from your authenticator app.'
                                     : 'Enter the 6-digit code from your authenticator app.',
        ]);
    }
    // A staff account that has not enrolled gets a session, but one that reaches only the
    // enrolment routes until two-factor is on (enforced in auth()). That keeps them able to
    // fix it themselves, without the password alone opening any member data.
    $mfaSetupRequired = sessionNeedsMfaSetup($pdo, $config, (int)$user['id'], (string)$user['role']);
    if (mfaRequiredForRole((string)$user['role'])) {
        // Logged whether or not the gate is on: with require_staff_mfa switched off this is
        // the only trace that a staff password alone opened the admin panel.
        securityLog($pdo, $config, 'mfa_missing_privileged_login', 'warning', 'login',
            $mfaSetupRequired
                ? 'Staff account signed in without two-factor; held at enrolment'
                : 'Staff account signed in without two-factor (require_staff_mfa is off)',
            (int)$user['id']);
    }
    // Staff sign in from Kenya (and their counties) only, unless an exception is approved.
    if (function_exists('geoGuardSignIn')) geoGuardSignIn($pdo, $config, (int)$user['id'], (string)$user['role']);
    $loginToken = token(['userId' => (int)$user['id'], 'email' => $user['email'], 'role' => $user['role']], $config['jwt_secret']);
    issueAuthCookie($loginToken);
    // A non-member who signed up to submit an abstract, and never joined the Academy,
    // is sent to their abstracts rather than to an Academy they did not ask for.
    $isAuthor = false;
    if ($user['role'] === 'member' && $user['membership_status'] === null) {
        try {
            $kind = $pdo->prepare('SELECT (SELECT COUNT(*) FROM abs_profiles WHERE user_id = ?) AS author,
                                          (SELECT COUNT(*) FROM academy_learners WHERE user_id = ?) AS learner');
            $kind->execute([(int)$user['id'], (int)$user['id']]);
            $k = $kind->fetch();
            $isAuthor = (int)$k['author'] > 0 && (int)$k['learner'] === 0;
        } catch (Throwable $kindError) {
            $isAuthor = false;
        }
    }
    respond(200, [
        'token' => $loginToken,
        'mfaSetupRequired' => $mfaSetupRequired,
        'user' => [
            'id' => (int)$user['id'],
            // A member account with no membership record is an Academy learner.
            'isLearner' => $user['role'] === 'member' && $user['membership_status'] === null,
            'isAuthor' => $isAuthor,
            // Staff without a membership go to the staff home page rather than the Academy.
            'isStaff' => function_exists('staffIs') && staffIs($pdo, (int)$user['id']),
            'isWelfareVoter' => function_exists('welfareDuringWindow') && welfareDuringWindow($pdo, (int)$user['id']),
            'email' => $user['email'],
            'role' => $user['role'],
            'membershipStatus' => $user['membership_status'],
            'membershipId' => $user['membership_id'],
            'cpdPoints' => (int)($user['cpd_points'] ?? 0)
        ]
    ]);
}

function clearAuthCookie(): void {
    setcookie('resok_token', '', [
        'expires' => time() - 3600,
        'path' => '/',
        'secure' => requestIsSecure(),
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
}

/**
 * Server-side session control.
 *
 * The session token is signed, so the server can trust it without storing it. On its own
 * that meant nothing the server did could end a session early: logging out only cleared the
 * browser's copy, and a password reset or a demotion left every existing session working
 * until it timed out - up to 7 days for one kept busy. These close that:
 *
 *   - role and email are read from the users table on every authenticated request, never
 *     trusted from the token, so a demotion takes effect on the next click;
 *   - session_revocations holds, per account, a moment before which every session is dead
 *     ("sign out everywhere": password reset, role change);
 *   - revoked_tokens holds the ids of single sessions ended by logout, until the moment
 *     they would have expired anyway.
 *
 * Both tables are created on first use. If the database user cannot create them, the live
 * role check still works, and the Security page reports revocation as missing - rather than
 * login breaking over a control that was never there before.
 */
const RESOK_MFA_SETUP_ROUTES = ['auth/mfa/setup', 'auth/mfa/enable', 'auth/mfa/status', 'auth/logout'];

function sessionTablesCreate(PDO $pdo): bool
{
    static $created = null;
    if ($created !== null) return $created;
    try {
        $pdo->exec('CREATE TABLE IF NOT EXISTS session_revocations (
            user_id INT NOT NULL PRIMARY KEY,
            revoked_before INT UNSIGNED NOT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $pdo->exec('CREATE TABLE IF NOT EXISTS revoked_tokens (
            jti CHAR(32) NOT NULL PRIMARY KEY,
            expires_at INT UNSIGNED NOT NULL,
            KEY idx_revoked_tokens_expiry (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $created = true;
    } catch (Throwable $e) {
        error_log('Session revocation unavailable - could not create its tables: ' . $e->getMessage());
        $created = false;
    }
    return $created;
}

/** Ends every session the account has, on every device, as of now. Never fatal. */
function sessionRevokeAll(PDO $pdo, int $userId): bool
{
    if ($userId <= 0 || !sessionTablesCreate($pdo)) return false;
    try {
        $pdo->prepare('INSERT INTO session_revocations (user_id, revoked_before) VALUES (?, ?)
                       ON DUPLICATE KEY UPDATE revoked_before = VALUES(revoked_before)')
            ->execute([$userId, time()]);
        return true;
    } catch (Throwable $e) {
        error_log('Could not revoke sessions for user ' . $userId . ': ' . $e->getMessage());
        return false;
    }
}

/** Ends one session - the one a logout came from. Never fatal. */
function sessionRevokeToken(PDO $pdo, string $jti, int $expiresAt): bool
{
    if (!preg_match('/^[a-f0-9]{32}$/', $jti) || !sessionTablesCreate($pdo)) return false;
    try {
        $pdo->prepare('INSERT IGNORE INTO revoked_tokens (jti, expires_at) VALUES (?, ?)')
            ->execute([$jti, $expiresAt]);
        // A revoked id only matters until its session would have expired on its own.
        $pdo->prepare('DELETE FROM revoked_tokens WHERE expires_at < ?')->execute([time()]);
        return true;
    } catch (Throwable $e) {
        error_log('Could not revoke a session: ' . $e->getMessage());
        return false;
    }
}

/**
 * Whether this account must enrol in two-factor before it can do anything else.
 *
 * Only staff roles are asked (mfaRequiredForRole), and only while require_staff_mfa is on.
 * Never when the mfa columns are missing: nobody could enrol then, and demanding it would
 * lock every administrator out of their own site.
 */
function sessionNeedsMfaSetup(PDO $pdo, array $config, int $userId, string $role): bool
{
    if (empty($config['require_staff_mfa']) || !mfaRequiredForRole($role)) return false;
    if (!mfaEnsureColumns($pdo)) return false;
    try {
        $stmt = $pdo->prepare('SELECT mfa_enabled FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        return (int)($stmt->fetch()['mfa_enabled'] ?? 0) !== 1;
    } catch (Throwable $e) {
        error_log('Could not read two-factor state for the session check: ' . $e->getMessage());
        return false;
    }
}

/**
 * The session as the database sees it right now, or null when it has been ended or the
 * account no longer exists. Role and email are replaced with the live values, and
 * mfaSetupRequired is added. Throws only when the database cannot be read at all.
 */
function sessionLookup(PDO $pdo, array $config, array $payload): ?array
{
    static $tablesUsable = null;
    $userId = (int)($payload['userId'] ?? 0);
    if ($userId <= 0) return null;

    $sql = 'SELECT u.email, u.role, r.revoked_before,
                   (SELECT 1 FROM revoked_tokens t WHERE t.jti = ? LIMIT 1) AS token_revoked
              FROM users u LEFT JOIN session_revocations r ON r.user_id = u.id
             WHERE u.id = ? LIMIT 1';
    $params = [(string)($payload['jti'] ?? ''), $userId];
    $row = null;
    if ($tablesUsable !== false) {
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $row = $stmt->fetch();
            $tablesUsable = true;
        } catch (Throwable $e) {
            // Most likely the tables do not exist yet. Build them and ask again.
            $tablesUsable = sessionTablesCreate($pdo);
            if ($tablesUsable) {
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $row = $stmt->fetch();
            }
        }
    }
    if ($tablesUsable === false) {
        $stmt = $pdo->prepare('SELECT email, role, NULL AS revoked_before, NULL AS token_revoked FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
    }

    if (!$row) return null;
    if ((int)($row['token_revoked'] ?? 0) === 1) return null;
    // Ended if started in an earlier second than the revocation. A login in the same second
    // survives: a password reset is followed at once by a fresh login (the account-claim
    // flow does exactly this), and refusing it signed the member straight back out. Tokens
    // from before iat existed carry none, so they read as 0 and end with the first revocation.
    if ($row['revoked_before'] !== null && (int)($payload['iat'] ?? 0) < (int)$row['revoked_before']) return null;

    $payload['email'] = (string)$row['email'];
    $payload['role'] = (string)$row['role'];
    $payload['mfaSetupRequired'] = sessionNeedsMfaSetup($pdo, $config, $userId, $payload['role']);
    return $payload;
}

/**
 * True only on the developer machine: the request came through the local vhost, which sets
 * RESOK_LOCAL itself (a request cannot), and from this computer. Both are required, so the
 * live server - which never sets RESOK_LOCAL - can never take this path.
 */
function isLocalDevRequest(): bool {
    $flag = (string)($_SERVER['RESOK_LOCAL'] ?? $_SERVER['REDIRECT_RESOK_LOCAL'] ?? getenv('RESOK_LOCAL') ?: '');
    $addr = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    // The tools/dev test suites call the API with curl and expect signed-out requests to be
    // refused, so they keep the normal behaviour. Skipping only ever removes access.
    $isCurl = stripos((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 'curl/') === 0;
    return $flag === '1' && !$isCurl && in_array($addr, ['127.0.0.1', '::1'], true);
}

/**
 * On localhost, a session for the first admin account, so every portal page can be reviewed
 * without logging in. Null anywhere else, or when the local database has no admin yet.
 */
function localDevPayload(array $config): ?array {
    static $resolved = false, $payload = null;
    if ($resolved) return $payload;
    $resolved = true;
    if (!isLocalDevRequest()) return null;
    try {
        $row = db($config)->query("SELECT id, email, role FROM users WHERE role = 'admin' ORDER BY id LIMIT 1")->fetch();
    } catch (Throwable $error) {
        return null;
    }
    if (!$row) return null;
    $payload = [
        'userId' => (int)$row['id'],
        'email' => (string)$row['email'],
        'role' => (string)$row['role'],
        'exp' => time() + 3600,
        'seen' => time(),
        'localDev' => true,
    ];
    return $payload;
}

function auth(array $config): array {
    // Localhost: a real login still wins; otherwise act as the local admin instead of a 401.
    $localDev = localDevPayload($config);
    if ($localDev !== null) return viewAsAct($config, withSuperAdminFlag(authOptionalToken($config) ?? $localDev, $config));

    $fromCookie = true;
    $token = $_COOKIE['resok_token'] ?? '';
    if (!$token) {
        $fromCookie = false;
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!$header && function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            $header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        }
        if (!preg_match('/^Bearer\s+(.+)$/', $header, $m)) {
            respond(401, ['error' => 'Missing token']);
        }
        $token = $m[1];
    }
    [$body, $sig] = array_pad(explode('.', $token, 2), 2, '');
    $signedWith = ($body && $sig) ? tokenSignedWith($body, $sig, $config) : null;
    if ($signedWith === null) {
        respond(401, ['error' => 'Invalid token']);
    }
    $payload = json_decode(base64_decode(strtr($body, '-_', '+/')), true);
    if (!is_array($payload) || (($payload['exp'] ?? 0) < time())) {
        respond(401, ['error' => 'Expired token']);
    }

    // Idle timeout. Tokens minted before this existed carry no `seen` claim; those are
    // grandfathered (their window starts on this request) rather than logging out every
    // signed-in member the moment this deploys. The refresh below stamps them.
    $seen = (int)($payload['seen'] ?? 0);
    $idleFor = time() - $seen;
    if ($seen > 0 && $idleFor > RESOK_SESSION_IDLE_TIMEOUT) {
        clearAuthCookie();
        respond(401, [
            'error' => 'You were signed out after 20 minutes of inactivity. Please log in again.',
            'reason' => 'idle'
        ]);
    }

    // Ask the database whether this session still stands, and who it belongs to now.
    try {
        $live = sessionLookup(db($config), $config, $payload);
    } catch (Throwable $e) {
        error_log('Session check failed: ' . $e->getMessage());
        respond(503, ['error' => 'We could not check your session just now. Please try again in a moment.']);
    }
    if ($live === null) {
        clearAuthCookie();
        respond(401, ['error' => 'Your session has ended. Please log in again.', 'reason' => 'revoked']);
    }
    // A staff account without two-factor reaches the enrolment routes and nothing else. The
    // password alone is no longer enough to open member data.
    if (!empty($live['mfaSetupRequired']) && !in_array((string)($GLOBALS['route'] ?? ''), RESOK_MFA_SETUP_ROUTES, true)) {
        respond(403, [
            'error' => 'Your account can reach member data, so two-factor authentication has to be set up before you continue.',
            'mfaSetupRequired' => true,
        ]);
    }
    // Staff location rules on every request, so a session taken abroad stops working too.
    if (function_exists('geoGuardSession')) geoGuardSession(db($config), $config, $live);

    // Slide the window forward. The original `exp` is carried over untouched, so an active
    // session still ends at the absolute cap rather than renewing itself forever. Header
    // callers have no cookie to refresh - they just re-authenticate.
    if ($fromCookie && ($idleFor >= RESOK_SESSION_REFRESH_INTERVAL || $signedWith === 'previous')) {
        $refreshed = $payload;
        unset($refreshed['exp'], $refreshed['seen']);
        issueAuthCookie(token($refreshed, $config['jwt_secret'], (int)$payload['exp']));
    }

    return viewAsAct($config, withSuperAdminFlag($live, $config));
}

/**
 * The super administrator's "View as member" (lib/view-as.php): the member they are viewing,
 * in place of themselves, when that is on. Unchanged when the module is not deployed.
 */
function viewAsAct(array $config, array $user): array {
    return function_exists('viewAsApply') ? viewAsApply($config, $user) : $user;
}

/**
 * Stamps the session with whether it is a super admin. Computed on every request from the
 * server's config, never read from the token, so it cannot be forged or go stale.
 */
function withSuperAdminFlag(array $payload, array $config): array {
    $payload['superAdmin'] = isSuperAdmin($payload, $config);
    return $payload;
}

/**
 * Who is signed in, or null - for pages that are public but read differently when they know
 * you.
 *
 * Deliberately not auth() with a flag. auth() answers "prove you may be here" and ends the
 * request when the answer is no; this one answers "is anyone there", where every no - absent,
 * malformed, expired, idle - is the same ordinary answer. A stale cookie must not take down
 * a page that never needed a session in the first place, which is exactly what reusing
 * auth() here would do: the public course page would start returning 401 to a visitor whose
 * only mistake was having signed in last week.
 *
 * It never refreshes the cookie. Sliding the idle window on an anonymous page view would let
 * a background poll keep a session alive forever without anybody using the portal.
 */
function authOptional(array $config): ?array {
    $user = authOptionalToken($config) ?? localDevPayload($config);
    if ($user === null) return null;
    // A staff account that has not enrolled in two-factor reads as an ordinary member here,
    // so nothing privileged is reachable through a public page either.
    if (!empty($user['mfaSetupRequired'])) $user['role'] = 'member';
    // A staff account outside where it may be used reads as nobody here.
    if (empty($user['localDev']) && function_exists('geoCheck') && geoCheck(db($config), $config, (int)$user['userId'], (string)$user['role']) !== null) return null;
    return viewAsAct($config, withSuperAdminFlag($user, $config));
}

/** The signed-in session's payload, or null - authOptional() without the localhost fallback. */
function authOptionalToken(array $config): ?array {
    $token = $_COOKIE['resok_token'] ?? '';
    if (!$token) {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!$header && function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            $header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        }
        if (!preg_match('/^Bearer\s+(.+)$/', $header, $m)) return null;
        $token = $m[1];
    }
    [$body, $sig] = array_pad(explode('.', $token, 2), 2, '');
    if (!$body || !$sig || tokenSignedWith($body, $sig, $config) === null) return null;

    $payload = json_decode(base64_decode(strtr($body, '-_', '+/')), true);
    if (!is_array($payload) || (($payload['exp'] ?? 0) < time())) return null;

    $seen = (int)($payload['seen'] ?? 0);
    if ($seen > 0 && (time() - $seen) > RESOK_SESSION_IDLE_TIMEOUT) return null;

    try {
        return sessionLookup(db($config), $config, $payload);
    } catch (Throwable $e) {
        error_log('Optional session check failed: ' . $e->getMessage());
        return null;
    }
}

function memberRow(PDO $pdo, int $userId): ?array {
    $stmt = $pdo->prepare('SELECT mp.*, u.email, u.email_verified FROM member_profiles mp JOIN users u ON u.id = mp.user_id WHERE mp.user_id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if ($row) $row['member_since'] = memberSinceYear($pdo, (int)$row['id']);
    return $row ?: null;
}

function memberRowByProfileId(PDO $pdo, int $profileId): ?array {
    $stmt = $pdo->prepare('SELECT mp.*, u.email, u.email_verified FROM member_profiles mp JOIN users u ON u.id = mp.user_id WHERE mp.id = ? LIMIT 1');
    $stmt->execute([$profileId]);
    $row = $stmt->fetch();
    if ($row) $row['member_since'] = memberSinceYear($pdo, (int)$row['id']);
    return $row ?: null;
}

/**
 * The first year a member paid for, as printed under "Member since" on the card.
 *
 * The register of paid years is the authority - it reaches back before the portal existed.
 * A member with no register row falls back to the year of their first confirmed portal
 * payment. Kept as its own guarded query rather than a join in memberRow, because memberRow
 * sits under sign-in: a missing years table must cost the card a date, never the login.
 */
function memberSinceYear(PDO $pdo, int $profileId): ?int {
    try {
        $stmt = $pdo->prepare('SELECT MIN(year) FROM member_payment_years WHERE member_profile_id = ?');
        $stmt->execute([$profileId]);
        $year = $stmt->fetchColumn();
        if ($year) return (int)$year;
    } catch (Throwable $e) {
        error_log('Member-since lookup (register) failed: ' . $e->getMessage());
    }
    try {
        $stmt = $pdo->prepare("SELECT MIN(YEAR(created_at)) FROM payments WHERE member_profile_id = ? AND status = 'paid'");
        $stmt->execute([$profileId]);
        $year = $stmt->fetchColumn();
        return $year ? (int)$year : null;
    } catch (Throwable $e) {
        error_log('Member-since lookup (payments) failed: ' . $e->getMessage());
        return null;
    }
}

function mapMember(?array $row): ?array {
    if (!$row) return null;
    $profileImage = $row['profile_image'] ?? null;
    return [
        'id' => (int)$row['id'],
        'userId' => (int)$row['user_id'],
        'email' => $row['email'] ?? '',
        // False for an account nobody has claimed yet - imported from the register and never
        // signed in. Null when the query behind this row did not select the column.
        'emailVerified' => array_key_exists('email_verified', $row) ? (bool)(int)$row['email_verified'] : null,
        'title' => $row['title'],
        'firstName' => $row['first_name'],
        'middleName' => $row['middle_name'],
        'surname' => $row['surname'],
        'country' => $row['country'],
        'county' => $row['county'],
        'division' => $row['division'],
        'profession' => $row['profession'] ?? null,
        'specialization' => $row['specialization'] ?? null,
        'institution' => $row['institution'] ?? null,
        'physicalAddress' => $row['physical_address'] ?? null,
        'payerType' => $row['payer_type'] ?? 'Individual',
        'category' => $row['category'],
        'idType' => $row['id_type'],
        // Decrypts when encrypted, passes through when the row predates the key.
        'idNumber' => cryptoDecrypt(cryptoConfig(), $row['id_number']),
        'mobile' => $row['mobile'],
        'profileImage' => $profileImage,
        'profileImageUrl' => !empty($profileImage) ? 'api/index.php?route=profile-images/' . rawurlencode(basename((string)$profileImage)) : null,
        'membershipStatus' => $row['membership_status'],
        'membershipId' => $row['membership_id'],
        'cpdPoints' => (int)$row['cpd_points'],
        'renewalDue' => $row['renewal_due'],
        // Only set where the row came through memberRow / memberRowByProfileId; lists skip it.
        'memberSince' => isset($row['member_since']) ? (int)$row['member_since'] : null,
        'reviewReason' => $row['review_reason'],
        // What the dates actually mean today - whether the member is current, due, inside
        // grace or lapsed, and whether benefits apply. Computed rather than read from the
        // status column, so it is right on a day the lapse job has not run.
        'standing' => function_exists('membershipStanding')
            ? membershipStanding($row)
            : ['standing' => 'unknown', 'benefits' => true, 'band' => 'notice', 'label' => '']
    ];
}

function requireAdmin(array $user): void {
    if (($user['role'] ?? '') !== 'admin') respond(403, ['error' => 'Admin access required']);
}

/**
 * A super administrator is named by email in config, not by a database column.
 *
 * That is deliberate on two counts. It needs no ALTER TABLE, which this host may not permit
 * and which has already broken login once. And it means the highest privilege on the site
 * can only be granted by someone with server access - not by anyone who reaches the admin
 * panel, which is precisely the account an attacker would be sitting in.
 *
 * With no list configured, nobody is a super administrator. This used to fall back to "every
 * admin is a super admin", which quietly handed membership officers the elections console,
 * analytics, ICT and the security pages. An ordinary admin works on membership only; the
 * cost of an unset list is now a super admin who must add their email to config.local.php
 * ('super_admins'), not every admin holding the highest privilege without anyone deciding so.
 */
function isSuperAdmin(array $user, array $config): bool {
    if (($user['role'] ?? '') !== 'admin') return false;
    $list = $config['super_admins'] ?? [];
    if (!$list) return false;
    $email = strtolower(trim((string)($user['email'] ?? '')));
    foreach ($list as $candidate) {
        if ($email !== '' && $email === strtolower(trim((string)$candidate))) return true;
    }
    return false;
}

function requireSuperAdmin(array $user, array $config): void {
    requireAdmin($user);
    if (!isSuperAdmin($user, $config)) {
        respond(403, ['error' => 'This area is restricted to super administrators.']);
    }
}

function requireFields(array $data, array $fields): void {
    foreach ($fields as $field) {
        if (!isset($data[$field]) || trim((string)$data[$field]) === '') {
            respond(400, ['error' => 'Required registration fields are missing']);
        }
    }
}

function uploadedMime(array $file): string {
    $tmpName = (string)($file['tmp_name'] ?? '');
    if ($tmpName !== '' && is_file($tmpName) && function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = finfo_file($finfo, $tmpName);
            finfo_close($finfo);
            if (is_string($mime) && $mime !== '') return $mime;
        }
    }
    return (string)($file['type'] ?? '');
}

// Membership IDs are issued as ReSoK0001, ReSoK0002, ... (Moses, 15 Oct 2026). Older IDs
// were issued as RESOK0001; the numbering is shared across both spellings, so matching and
// the uniqueness check ignore case and a new ID never reuses an old number.
function generateMembershipId(PDO $pdo): string {
    $stmt = $pdo->query(
        "SELECT membership_id
         FROM member_profiles
         WHERE UPPER(membership_id) REGEXP '^RESOK[0-9]+$'
         ORDER BY CAST(SUBSTRING(membership_id, 6) AS UNSIGNED) DESC
         LIMIT 1"
    );
    $latest = $stmt->fetchColumn();
    $next = $latest ? ((int)substr((string)$latest, 5) + 1) : 1;

    for ($i = 0; $i < 20; $i++, $next++) {
        $candidate = 'ReSoK' . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare('SELECT id FROM member_profiles WHERE UPPER(membership_id) = UPPER(?) LIMIT 1');
        $stmt->execute([$candidate]);
        if (!$stmt->fetch()) return $candidate;
    }

    return 'ReSoK' . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
}

function ensurePaymentProofColumns(PDO $pdo): void {
    $columns = [];
    foreach ($pdo->query('SHOW COLUMNS FROM payments')->fetchAll() as $column) {
        $columns[$column['Field']] = true;
    }

    $required = [
        'provider_reference' => 'ALTER TABLE payments ADD COLUMN provider_reference VARCHAR(120) NULL AFTER reference',
        'proof_filename' => 'ALTER TABLE payments ADD COLUMN proof_filename VARCHAR(255) NULL AFTER provider_reference',
        'proof_original_name' => 'ALTER TABLE payments ADD COLUMN proof_original_name VARCHAR(255) NULL AFTER proof_filename',
        'proof_mime_type' => 'ALTER TABLE payments ADD COLUMN proof_mime_type VARCHAR(120) NULL AFTER proof_original_name',
        'proof_file_size' => 'ALTER TABLE payments ADD COLUMN proof_file_size INT UNSIGNED NULL AFTER proof_mime_type'
    ];

    foreach ($required as $column => $sql) {
        if (empty($columns[$column])) {
            $pdo->exec($sql);
        }
    }
}

/**
 * Server-defined event catalog. Members can't award themselves arbitrary CPD points,
 * so registration always credits exactly the points listed here. Update this list as
 * ReSoK schedules real events -- this replaces the old hardcoded/broken demo cards
 * that used to live directly in events.html.
 */
function eventCatalog(): array {
    return [
        [
            'id' => 'asthma-guidelines-2026',
            'title' => 'Asthma Management Guidelines 2026',
            'type' => 'CME',
            'date' => '2026-06-15',
            'time' => '9AM - 4PM',
            'location' => 'Nairobi, Hybrid',
            'cpdPoints' => 6,
            'fee' => 2500,
            'currency' => 'KES'
        ],
        [
            'id' => 'copd-updates-webinar',
            'title' => 'Webinar: COPD Updates',
            'type' => 'Webinar',
            'date' => '2026-06-28',
            'time' => '7PM - 8:30PM',
            'location' => 'Online (Zoom)',
            'cpdPoints' => 2,
            'fee' => 0,
            'currency' => 'KES'
        ],
        [
            'id' => 'annual-conference-2026',
            'title' => 'Annual ReSoK Conference 2026',
            'type' => 'Conference',
            'date' => '2026-07-10',
            'time' => '2 Days',
            'location' => 'Mombasa',
            'cpdPoints' => 15,
            'fee' => 8500,
            'currency' => 'KES'
        ]
    ];
}

function ensureEventRegistrationsTable(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS event_registrations (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            member_profile_id INT UNSIGNED NOT NULL,
            event_id VARCHAR(60) NOT NULL,
            event_title VARCHAR(160) NOT NULL,
            cpd_points INT NOT NULL DEFAULT 0,
            registered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY event_registrations_unique (member_profile_id, event_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}

function ensureCpdTable(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS cpd_activities (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            member_profile_id INT UNSIGNED NOT NULL,
            description VARCHAR(255) NOT NULL,
            points INT NOT NULL DEFAULT 0,
            occurred_on DATE NULL,
            added_by INT UNSIGNED NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY cpd_activities_member_idx (member_profile_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}

function ensureAuditTable(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS admin_actions (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            admin_user_id INT UNSIGNED NULL,
            action VARCHAR(60) NOT NULL,
            target_member_profile_id INT UNSIGNED NULL,
            reason TEXT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY admin_actions_target_idx (target_member_profile_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}

function logAdminAction(PDO $pdo, ?int $adminUserId, string $action, ?int $targetMemberProfileId, ?string $reason = null): void {
    ensureAuditTable($pdo);
    $stmt = $pdo->prepare('INSERT INTO admin_actions (admin_user_id, action, target_member_profile_id, reason) VALUES (?, ?, ?, ?)');
    $stmt->execute([$adminUserId, $action, $targetMemberProfileId, $reason]);
}

/**
 * Already a member: holds a membership number, or is (or was) active. New applicants get their
 * number only when approved, so this tells a renewal from a first subscription. Imported
 * members carry their register number, so they count as members from day one.
 */
function memberAlreadyJoined(?array $row): bool {
    if (!$row) return false;
    return trim((string)($row['membership_id'] ?? '')) !== ''
        || in_array((string)($row['membership_status'] ?? ''), ['active', 'expired'], true);
}

/**
 * Approving someone who is already a member confirms their renewal payment instead: the
 * date moves on one term from where it stands (time already paid for is kept), the status
 * is active, and no welcome email goes out - they joined long ago. This is what an old member
 * who uploads a renewal slip lands in, and approving them used to welcome them to the
 * Society as if new and reset their date to a year from today.
 */
function confirmRenewalById(PDO $pdo, int $memberId, ?int $adminUserId): array {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM payments WHERE member_profile_id = ? AND status = "pending" AND proof_filename IS NOT NULL');
    $stmt->execute([$memberId]);
    $hasProof = (int)$stmt->fetchColumn() > 0;
    $renewedTo = null;
    if ($hasProof) {
        $pdo->prepare('UPDATE payments SET status = "paid" WHERE member_profile_id = ? AND status = "pending" AND proof_filename IS NOT NULL')
            ->execute([$memberId]);
        requireModule('membershipExtend', 'lib/membership.php');
        membershipRecordPortalYears($pdo, $memberId);
        $renewedTo = membershipExtend($pdo, $memberId);
        logAdminAction($pdo, $adminUserId, 'membership_renewed', $memberId, $renewedTo ? 'Renewed to ' . $renewedTo : 'Renewal confirmed');
    } else {
        // Nothing to confirm: only put a member who was left waiting back to active.
        $pdo->prepare('UPDATE member_profiles SET membership_status = "active", review_reason = NULL, reviewed_at = NOW()
                       WHERE id = ? AND membership_status IN ("under_review", "rejected", "payment_required")')
            ->execute([$memberId]);
        logAdminAction($pdo, $adminUserId, 'membership_restored', $memberId, null);
    }
    $member = mapMember(memberRowByProfileId($pdo, $memberId)) ?? [];
    return $member + ['renewal' => true, 'renewedTo' => $renewedTo, 'welcomeEmailSent' => null, 'welcomeEmailError' => null];
}

function approveMemberById(PDO $pdo, array $config, int $memberId, ?int $adminUserId): array {
    if (memberAlreadyJoined(memberRowByProfileId($pdo, $memberId))) {
        return confirmRenewalById($pdo, $memberId, $adminUserId);
    }
    // A proof upload is stored as pending, not paid: until an admin has looked at it, it is a
    // claim, and treating it as money received let a member download a "PAID" receipt for any
    // image they uploaded. Approving the member is that look, so it confirms their proof.
    if (empty($config['allow_approve_without_payment'])) {
        $stmt = $pdo->prepare('SELECT COUNT(*) AS c FROM payments WHERE member_profile_id = ?
                               AND (status = "paid" OR (status = "pending" AND proof_filename IS NOT NULL))');
        $stmt->execute([$memberId]);
        if (!(int)$stmt->fetch()['c']) {
            throw new RuntimeException('A payment or payment proof is required before approval.');
        }
    }
    $pdo->prepare('UPDATE payments SET status = "paid" WHERE member_profile_id = ? AND status = "pending" AND proof_filename IS NOT NULL')
        ->execute([$memberId]);
    if (function_exists('membershipRecordPortalYears')) membershipRecordPortalYears($pdo, $memberId);
    $membershipId = generateMembershipId($pdo);
    $pdo->prepare('UPDATE member_profiles SET membership_status = "active", membership_id = COALESCE(membership_id, ?), renewal_due = DATE_ADD(CURDATE(), INTERVAL 1 YEAR), review_reason = NULL, reviewed_at = NOW() WHERE id = ?')->execute([$membershipId, $memberId]);
    $row = memberRowByProfileId($pdo, $memberId);
    $member = mapMember($row);
    logAdminAction($pdo, $adminUserId, 'approve', $memberId, null);
    // The outcome is reported back rather than only logged. A silent failure here means an
    // approved member never receives their letter and card, while the admin sees a success
    // and has no reason to look - which is precisely how this went unnoticed.
    $welcomeEmailSent = null;
    $welcomeEmailError = null;
    if ($row && $member) {
        try {
            $welcomeReason = null;
            $welcomeEmailSent = (bool)sendWelcomePacketEmail($config, array_merge($member, ['email' => $row['email']]), $welcomeReason);
            if (!$welcomeEmailSent) $welcomeEmailError = $welcomeReason ?? 'The mail server did not accept the message.';
        } catch (Throwable $mailError) {
            $welcomeEmailSent = false;
            $welcomeEmailError = $mailError->getMessage();
            error_log('Welcome email failed: ' . $mailError->getMessage());
        }
    }
    if ($member) {
        $member['welcomeEmailSent'] = $welcomeEmailSent;
        $member['welcomeEmailError'] = $welcomeEmailError;
    }
    return $member ?? [];
}

function rejectMemberById(PDO $pdo, int $memberId, string $reason, ?int $adminUserId): array {
    if (memberAlreadyJoined(memberRowByProfileId($pdo, $memberId))) {
        // A renewal slip that is not accepted: the slip fails, the membership stands and
        // runs to its date as before.
        $pdo->prepare('UPDATE payments SET status = "failed" WHERE member_profile_id = ? AND status = "pending" AND proof_filename IS NOT NULL')
            ->execute([$memberId]);
        $pdo->prepare('UPDATE member_profiles SET membership_status = "active", review_reason = ?, reviewed_at = NOW()
                       WHERE id = ? AND membership_status IN ("under_review", "payment_required", "rejected")')
            ->execute([$reason, $memberId]);
        logAdminAction($pdo, $adminUserId, 'renewal_payment_rejected', $memberId, $reason);
        return (mapMember(memberRowByProfileId($pdo, $memberId)) ?? []) + ['renewal' => true];
    }
    $pdo->prepare('UPDATE member_profiles SET membership_status = "rejected", review_reason = ?, reviewed_at = NOW() WHERE id = ?')->execute([$reason, $memberId]);
    // The proof they sent was not accepted; mark it so, rather than leave it pending forever.
    $pdo->prepare('UPDATE payments SET status = "failed" WHERE member_profile_id = ? AND status = "pending" AND proof_filename IS NOT NULL')
        ->execute([$memberId]);
    $row = memberRowByProfileId($pdo, $memberId);
    $member = mapMember($row);
    logAdminAction($pdo, $adminUserId, 'reject', $memberId, $reason);
    return $member ?? [];
}

$route = trim($_GET['route'] ?? '', '/');
// The browser helper (portal-state.js api()) URL-encodes the whole route, so a page asking
// for 'ict/tickets&status=open' arrives as one route string with the filters inside it, and
// matched no route at all. Anything after the first '&' is read as query parameters instead.
// So is anything after a '?': callers naturally write 'ict/assets/by-tag?tag=000009', and the
// encoding turned that into a route ending in '?tag=000009' that answered 404 - which the
// tag scanner reported as "not on the asset list" for a tag that was.
if (preg_match('/[?&]/', $route, $sep, PREG_OFFSET_CAPTURE)) {
    $routeQuery = substr($route, $sep[0][1] + 1);
    $route = substr($route, 0, $sep[0][1]);
    parse_str($routeQuery, $routeParams);
    foreach ($routeParams as $key => $value) {
        if (!array_key_exists($key, $_GET)) $_GET[$key] = $value;
    }
    $route = trim($route, '/');
}
$method = $_SERVER['REQUEST_METHOD'];

/**
 * A second lock behind SameSite=Lax. Lax stops other sites' forms, but a sibling subdomain
 * (webmail, cPanel, anything else under resok.org) counts as the same site and would still
 * carry the session cookie. Every page that writes through this API is served from this
 * host, so a browser that says a write came from anywhere else is refused. Servers calling
 * in (M-Pesa) send neither header and are unaffected; so are tools like curl.
 */
function crossSiteWriteBlocked(array $config): bool
{
    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $allowed = array_filter([$host, strtolower((string)parse_url((string)($config['portal_base_url'] ?? ''), PHP_URL_HOST))]);
    $hostOf = static function (string $url): string {
        $p = parse_url($url);
        if (!$p || empty($p['host'])) return '';
        return strtolower($p['host'] . (isset($p['port']) ? ':' . $p['port'] : ''));
    };
    $origin = $_SERVER['HTTP_ORIGIN'] ?? null;
    if ($origin !== null) {
        // "null" is what a sandboxed frame or a file:// page sends: never ours.
        $o = $origin === 'null' ? '' : $hostOf($origin);
        $bare = preg_replace('/:\d+$/', '', $o);
        return !in_array($o, $allowed, true) && !in_array($bare, $allowed, true);
    }
    $site = strtolower((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? ''));
    return $site === 'cross-site' || $site === 'same-site';
}
if (!in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)
    && !in_array($route, ['payments/stk/callback', 'payments/mpesa/callback'], true)
    && crossSiteWriteBlocked($config)) {
    respond(403, ['error' => 'This request came from another website and was refused.']);
}

try {
    requireConfig($config);
    $pdo = db($config);

    if (strpos($route, 'welfare/') === 0 || strpos($route, 'admin/welfare/') === 0) {
        requireModule('welfareHandle', 'lib/welfare.php');
        welfareHandle($pdo, $config, $route, $method);
    }
    if ((strpos($route, 'elections') === 0 || strpos($route, 'admin/elections') === 0) && function_exists('welfareRunScheduled')) {
        auth($config);
        welfareRunScheduled($pdo);
    }

    // Proof of work in front of sign-in, sign-up and the public forms (lib/proof.php).
    if ($route === 'proof/challenge' && $method === 'GET') {
        header('Cache-Control: no-store');
        respond(200, function_exists('proofIssue') && function_exists('proofEnabled') && proofEnabled($config)
            ? proofIssue($config) + ['enabled' => true] : ['enabled' => false]);
    }
    if (function_exists('proofRequire')) proofRequire($pdo, $config, $route, $method);

    if ($route === 'health') {
        respond(200, ['status' => 'OK', 'runtime' => 'php', 'timestamp' => gmdate('c')]);
    }

    // ---------------------------------------------------------------------------------
    // Blog - public reading endpoints. No auth: these serve the public site, and the
    // queries themselves only ever return published (or due-to-publish) articles.
    // ---------------------------------------------------------------------------------
    if ($route === 'blog/articles' && $method === 'GET') {
        requireModule('blogListPublic', 'lib/blog.php');
        blogRequireTables($pdo);
        respond(200, blogListPublic($pdo, $_GET));
    }

    if ($route === 'blog/featured' && $method === 'GET') {
        requireModule('blogFeatured', 'lib/blog.php');
        blogRequireTables($pdo);
        respond(200, blogFeatured($pdo) ?? []);
    }

    if ($route === 'blog/categories' && $method === 'GET') {
        requireModule('blogCategories', 'lib/blog.php');
        blogRequireTables($pdo);
        respond(200, blogCategories($pdo));
    }

    if (preg_match('#^blog/articles/([A-Za-z0-9\-]+)$#', $route, $m) && $method === 'GET') {
        $row = blogBySlug($pdo, $m[1]);
        if (!$row) respond(404, ['error' => 'Article not found']);
        respond(200, [
            'article' => blogPublicArticle($row, true),
            'related' => blogRelated($pdo, (int)$row['id'], $row['category_id'] !== null ? (int)$row['category_id'] : null),
        ]);
    }

    // ---------------------------------------------------------------------------------
    // Blog - editorial endpoints. Permission is enforced inside lib/blog.php by role, so
    // adding a route here cannot accidentally skip the check.
    // ---------------------------------------------------------------------------------
    if ($route === 'blog/admin/articles' && $method === 'GET') {
        requireModule('blogListAdmin', 'lib/blog.php');
        blogRequireTables($pdo);
        respond(200, blogListAdmin($pdo, auth($config), $_GET));
    }

    if ($route === 'blog/admin/articles' && $method === 'POST') {
        requireModule('blogSaveArticle', 'lib/blog.php');
        blogRequireTables($pdo);
        respond(201, blogSaveArticle($pdo, auth($config), input()));
    }

    // Social ingestion queue. Fetching is deliberately separate from importing: the cron
    // fills the queue, an editor decides what becomes an article.
    if ($route === 'blog/admin/social' && $method === 'GET') {
        requireModule('socialIngestAll', 'lib/social-ingest.php');
        blogRequireTables($pdo);
        $user = auth($config);
        blogRequireEdit($user);
        $status = $_GET['status'] ?? 'new';
        $stmt = $pdo->prepare('SELECT i.*, s.platform, s.label AS source_label
                                 FROM blog_social_items i
                                 JOIN blog_social_sources s ON s.id = i.source_id
                                WHERE i.status = ? ORDER BY i.posted_at DESC LIMIT 100');
        $stmt->execute([$status]);
        respond(200, array_map(fn($r) => [
            'id' => (int)$r['id'],
            'platform' => $r['platform'],
            'source' => $r['source_label'],
            'title' => $r['title'],
            'body' => $r['body'],
            'permalink' => $r['permalink'],
            'media' => $r['media_url'],
            'mediaType' => $r['media_type'],
            'postedAt' => $r['posted_at'],
            'status' => $r['status'],
            'articleId' => $r['article_id'] !== null ? (int)$r['article_id'] : null,
        ], $stmt->fetchAll()));
    }

    if ($route === 'blog/admin/social/refresh' && $method === 'POST') {
        requireModule('socialIngestAll', 'lib/social-ingest.php');
        blogRequireTables($pdo);
        $user = auth($config);
        blogRequireEdit($user);
        respond(200, ['sources' => socialIngestAll($pdo)]);
    }

    if (preg_match('#^blog/admin/social/(\d+)/import$#', $route, $m) && $method === 'POST') {
        respond(201, socialImportItem($pdo, auth($config), (int)$m[1], input()));
    }

    if (preg_match('#^blog/admin/social/(\d+)/ignore$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        blogRequireEdit($user);
        $pdo->prepare('UPDATE blog_social_items SET status = "ignored", reviewed_by = ?, reviewed_at = NOW() WHERE id = ?')
            ->execute([(int)$user['userId'], (int)$m[1]]);
        respond(200, ['message' => 'Post ignored']);
    }

    if (preg_match('#^blog/admin/articles/(\d+)$#', $route, $m)) {
        $user = auth($config);
        if ($method === 'GET') {
            blogRequireEdit($user);
            $stmt = $pdo->prepare(BLOG_ARTICLE_SELECT . ' WHERE a.id = ? LIMIT 1');
            $stmt->execute([(int)$m[1]]);
            $row = $stmt->fetch();
            if (!$row) respond(404, ['error' => 'Article not found']);
            respond(200, blogAdminArticle($row));
        }
        if ($method === 'PATCH' || $method === 'PUT') {
            respond(200, blogSaveArticle($pdo, $user, input(), (int)$m[1]));
        }
        if ($method === 'DELETE') {
            blogDeleteArticle($pdo, $user, (int)$m[1]);
            respond(200, ['message' => 'Article deleted']);
        }
    }

    // Threat assessment for the admin dashboard. Admin only - it names weaknesses, which is
    // precisely the list an attacker would want, so it is not exposed to other roles.
    // Who am I, and what may I see? The admin panel asks this to decide whether to show
    // the Threat Assessment link and the Administrators panel at all.
    // Invitations. Any admin may invite members - that is membership work, not privilege
    // granting - but the claim endpoint below is public, because the person using it does
    // not have an account yet. That is the whole point of it.
    if ($route === 'invites' && $method === 'GET') {
        $user = auth($config);
        requireAdmin($user);
        requireModule('inviteList', 'lib/invites.php');
        invitesRequire($pdo);
        respond(200, inviteList($pdo));
    }

    if ($route === 'invites' && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        requireModule('inviteCreate', 'lib/invites.php');
        invitesRequire($pdo);

        $data = input();
        $entries = $data['invites'] ?? null;
        if (!is_array($entries) || !$entries) respond(400, ['error' => 'Provide at least one email address.']);
        if (count($entries) > 200) respond(400, ['error' => 'Send at most 200 invitations at a time.']);

        $sent = [];
        $failed = [];
        foreach ($entries as $entry) {
            $email = is_array($entry) ? (string)($entry['email'] ?? '') : (string)$entry;
            $name = is_array($entry) ? (string)($entry['name'] ?? '') : '';
            try {
                $invite = inviteCreate($pdo, $config, $email, $name, (int)$user['userId']);
                if (inviteSend($pdo, $config, $invite)) {
                    $sent[] = $invite['email'];
                } else {
                    $failed[] = ['email' => $invite['email'], 'reason' => 'The email could not be sent.'];
                }
            } catch (Throwable $e) {
                // One bad address must not stop the batch; it is reported back instead.
                $failed[] = ['email' => trim($email), 'reason' => $e->getMessage()];
            }
        }
        logAdminAction($pdo, (int)$user['userId'], 'invites_sent', null, count($sent) . ' sent, ' . count($failed) . ' failed');
        respond(200, ['sent' => $sent, 'failed' => $failed]);
    }

    if (preg_match('#^invites/(\d+)/(resend|revoke)$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        requireModule('inviteSend', 'lib/invites.php');
        invitesRequire($pdo);

        $stmt = $pdo->prepare('SELECT * FROM member_invites WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$m[1]]);
        $invite = $stmt->fetch();
        if (!$invite) respond(404, ['error' => 'Invitation not found.']);

        if ($m[2] === 'revoke') {
            $pdo->prepare('UPDATE member_invites SET revoked_at = NOW() WHERE id = ?')->execute([(int)$invite['id']]);
            respond(200, ['message' => 'Invitation revoked.']);
        }
        // Resending issues a fresh token, so an old forwarded link stops working.
        $refreshed = inviteCreate($pdo, $config, (string)$invite['email'], $invite['name'], (int)$user['userId']);
        respond(200, ['sent' => inviteSend($pdo, $config, $refreshed)]);
    }

    // Public: the holder of a valid invitation has no account yet, so this cannot require
    // one. It answers with the invited email and nothing else, and only for a token that is
    // still claimable - so it reveals nothing about addresses that were never invited.
    if (preg_match('#^invites/claim/([a-f0-9]{64})$#', $route, $m) && $method === 'GET') {
        requireModule('inviteByToken', 'lib/invites.php');
        if (!invitesEnsureTable($pdo)) respond(404, ['error' => 'That invitation link is not valid.']);
        $invite = inviteByToken($pdo, $m[1]);
        if (!$invite) respond(404, ['error' => 'That invitation link has expired or has already been used.']);
        respond(200, ['email' => $invite['email'], 'name' => $invite['name']]);
    }

    // Society analytics, for super administrators only. Aggregates exclusively: no row here
    // identifies a person. Each block is isolated because the schema ships in pieces and a
    // server may be missing one - a single absent table should cost one card, not the page.
    if ($route === 'admin/analytics' && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);

        $out = ['generatedAt' => date('c'), 'unavailable' => []];
        $section = function (string $name, callable $work) use ($pdo, &$out): void {
            try {
                $out[$name] = $work($pdo);
            } catch (Throwable $sectionError) {
                $out[$name] = null;
                $out['unavailable'][] = $name;
                error_log('Analytics section "' . $name . '" failed: ' . $sectionError->getMessage());
            }
        };

        $section('members', function (PDO $pdo): array {
            $byStatus = [];
            foreach ($pdo->query('SELECT membership_status AS s, COUNT(*) AS c FROM member_profiles GROUP BY membership_status') as $row) {
                $byStatus[(string)$row['s']] = (int)$row['c'];
            }
            $months = $pdo->query(
                'SELECT DATE_FORMAT(created_at, "%Y-%m") AS m, COUNT(*) AS c
                   FROM member_profiles
                  WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                  GROUP BY m ORDER BY m'
            )->fetchAll();
            // Renewals ahead, so the Secretariat can see the workload before it arrives rather
            // than after the reminders have gone out.
            $due = $pdo->query(
                'SELECT
                    SUM(renewal_due BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) AS d30,
                    SUM(renewal_due BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)) AS d60,
                    SUM(renewal_due BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)) AS d90,
                    SUM(renewal_due < CURDATE()) AS overdue
                   FROM member_profiles WHERE membership_status = "active"'
            )->fetch();
            return [
                'total' => array_sum($byStatus),
                'byStatus' => $byStatus,
                'newByMonth' => array_map(fn($r) => ['month' => $r['m'], 'count' => (int)$r['c']], $months),
                'renewalsDue' => [
                    'in30' => (int)($due['d30'] ?? 0),
                    'in60' => (int)($due['d60'] ?? 0),
                    'in90' => (int)($due['d90'] ?? 0),
                    'overdue' => (int)($due['overdue'] ?? 0),
                ],
            ];
        });

        $section('payments', function (PDO $pdo): array {
            $rows = $pdo->query(
                'SELECT year, COUNT(*) AS members, COALESCE(SUM(amount), 0) AS total
                   FROM member_payment_years GROUP BY year ORDER BY year'
            )->fetchAll();
            return array_map(fn($r) => [
                'year' => (int)$r['year'],
                'members' => (int)$r['members'],
                'total' => (float)$r['total'],
            ], $rows);
        });

        $section('readership', function (PDO $pdo): array {
            // dimension = 'total' is the undifferentiated daily row; the others break the same
            // reads down by country, source and so on, and would double-count if summed here.
            $daily = $pdo->query(
                'SELECT stat_date AS d, SUM(`reads`) AS r, SUM(unique_readers) AS u, SUM(completions) AS c
                   FROM blog_daily_stats
                  WHERE dimension = "total" AND stat_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                  GROUP BY stat_date ORDER BY stat_date'
            )->fetchAll();
            $top = $pdo->query(
                'SELECT a.title AS t, SUM(s.`reads`) AS r
                   FROM blog_daily_stats s JOIN blog_articles a ON a.id = s.article_id
                  WHERE s.dimension = "total" AND s.stat_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                  GROUP BY a.id, a.title ORDER BY r DESC LIMIT 5'
            )->fetchAll();
            return [
                'daily' => array_map(fn($r) => [
                    'date' => $r['d'], 'reads' => (int)$r['r'],
                    'readers' => (int)$r['u'], 'completions' => (int)$r['c'],
                ], $daily),
                'totals' => [
                    'reads' => array_sum(array_map(fn($r) => (int)$r['r'], $daily)),
                    'readers' => array_sum(array_map(fn($r) => (int)$r['u'], $daily)),
                    'completions' => array_sum(array_map(fn($r) => (int)$r['c'], $daily)),
                ],
                'topArticles' => array_map(fn($r) => ['title' => $r['t'], 'reads' => (int)$r['r']], $top),
            ];
        });

        $section('academy', function (PDO $pdo): array {
            $row = $pdo->query(
                'SELECT COUNT(*) AS enrolments,
                        SUM(completed_at IS NOT NULL) AS completions,
                        SUM(last_active_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) AS activeLearners,
                        COUNT(DISTINCT user_id) AS learners
                   FROM academy_enrolments'
            )->fetch();
            return [
                'enrolments' => (int)($row['enrolments'] ?? 0),
                'completions' => (int)($row['completions'] ?? 0),
                'activeLearners' => (int)($row['activeLearners'] ?? 0),
                'learners' => (int)($row['learners'] ?? 0),
            ];
        });

        $section('elections', function (PDO $pdo): array {
            $rows = $pdo->query(
                'SELECT e.id, e.title, e.status,
                        (SELECT COUNT(*) FROM election_roll r WHERE r.election_id = e.id) AS roll,
                        (SELECT COUNT(DISTINCT b.roll_id) FROM election_ballots b WHERE b.election_id = e.id) AS voted
                   FROM elections e ORDER BY e.id DESC LIMIT 5'
            )->fetchAll();
            return array_map(function ($r) {
                $roll = (int)$r['roll'];
                $voted = (int)$r['voted'];
                return [
                    'title' => $r['title'],
                    'status' => $r['status'],
                    'roll' => $roll,
                    'voted' => $voted,
                    // Turnout is derived here rather than stored, like everywhere else.
                    'turnout' => $roll > 0 ? round($voted / $roll * 100, 1) : null,
                ];
            }, $rows);
        });

        $section('events', function (PDO $pdo): array {
            $row = $pdo->query(
                'SELECT COUNT(*) AS registrations,
                        COUNT(DISTINCT member_profile_id) AS members,
                        COALESCE(SUM(cpd_points), 0) AS cpdPoints
                   FROM event_registrations'
            )->fetch();
            return [
                'registrations' => (int)($row['registrations'] ?? 0),
                'members' => (int)($row['members'] ?? 0),
                'cpdPoints' => (int)($row['cpdPoints'] ?? 0),
            ];
        });

        respond(200, $out);
    }

    if ($route === 'admin/whoami' && $method === 'GET') {
        $user = auth($config);
        requireAdmin($user);
        respond(200, [
            'email' => $user['email'] ?? '',
            'role' => $user['role'] ?? '',
            'isSuperAdmin' => isSuperAdmin($user, $config),
            'superAdminsConfigured' => !empty($config['super_admins']),
        ]);
    }

    // Administrator management - super administrators only, listing included. An ordinary
    // admin works on membership; who holds which role is not part of that job.
    // Find an account by email so it can be promoted. Super administrator only, and it
    // answers with an id or nothing - never with a list, so it cannot be walked to enumerate
    // who holds an account here.
    // Create an administrator outright, rather than asking them to self-register first.
    // Super administrator only, for the same reason promotion is: an admin who could mint
    // admins could hand out their own level of access.
    if ($route === 'admins' && $method === 'POST') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        $data = input();

        $email = strtolower(trim((string)($data['email'] ?? '')));
        $name = trim((string)($data['name'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respond(400, ['error' => 'Enter a valid email address.']);

        $stmt = $pdo->prepare('SELECT id, role FROM users WHERE LOWER(email) = ? LIMIT 1');
        $stmt->execute([$email]);
        if ($existing = $stmt->fetch()) {
            respond(409, [
                'error' => $existing['role'] === 'admin'
                    ? 'That email is already an administrator.'
                    : 'That email already has an account. Use "Make admin" instead of creating a new one.',
            ]);
        }

        // Generated rather than chosen by the person creating it: an issued password picked
        // by a colleague tends to be guessable and tends to get reused. Groups of four are
        // for reading aloud or typing from a note, which is how this actually gets handed
        // over. The alphabet omits O/0 and I/l, which is where transcription goes wrong.
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
        $password = '';
        for ($i = 0; $i < 16; $i++) {
            if ($i > 0 && $i % 4 === 0) $password .= '-';
            $password .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
        // Guarantee the mix the registration rule requires, so this password stays valid if
        // it is ever put through that validator.
        $password .= 'A' . 'a' . random_int(0, 9);

        $pdo->prepare('INSERT INTO users (email, password_hash, email_verified, role) VALUES (?, ?, 1, "admin")')
            ->execute([$email, password_hash($password, PASSWORD_DEFAULT)]);
        $newId = (int)$pdo->lastInsertId();

        // Verified on creation: a super administrator vouching for the address is a stronger
        // signal than an emailed link, and an unverified admin could not log in at all.
        logAdminAction($pdo, (int)$user['userId'], 'admin_created', null, 'user #' . $newId . ' (' . $email . ')');
        securityLog($pdo, $config, 'admin_created', 'warning', 'admins', $email, (int)$user['userId']);

        // Best effort, and never fatal: the password is handed over by the super admin, so
        // this only tells the person an account exists and where to sign in.
        try {
            $portal = rtrim((string)($config['portal_base_url'] ?? ''), '/') ?: 'https://www.resok.org/resok-portal/public';
            if (class_exists('SimpleMailer')) {
                (new SimpleMailer($config))->send($email, 'Your ReSoK administrator account',
                    "An administrator account has been created for you on the ReSoK members' portal.

"
                    . "Sign in at {$portal}/login

"
                    . "Your password will be given to you separately - it is deliberately not in this email. "
                    . "Please change it after your first sign-in, and turn on two-factor authentication from "
                    . "your profile page.

Respiratory Society of Kenya");
            }
        } catch (Throwable $mailError) {
            error_log('Admin welcome email failed: ' . $mailError->getMessage());
        }

        respond(201, [
            'id' => $newId,
            'email' => $email,
            'name' => $name ?: null,
            'role' => 'admin',
            'password' => $password,
            'notice' => 'This password is shown once. Give it to them directly, and ask them to change it and turn on two-factor.',
        ]);
    }

    if ($route === 'admins/lookup' && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        $email = strtolower(trim((string)($_GET['email'] ?? '')));
        if ($email === '') respond(400, ['error' => 'An email is required.']);
        $stmt = $pdo->prepare("SELECT u.id, u.email, u.role,
                                      TRIM(CONCAT(COALESCE(mp.first_name,''), ' ', COALESCE(mp.surname,''))) AS name
                                 FROM users u
                                 LEFT JOIN member_profiles mp ON mp.user_id = u.id
                                WHERE LOWER(u.email) = ? LIMIT 1");
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        if (!$row) respond(404, ['error' => 'No account is registered with that email.']);
        respond(200, [
            'id' => (int)$row['id'],
            'email' => $row['email'],
            'name' => trim((string)$row['name']) ?: null,
            'role' => $row['role'],
        ]);
    }

    if ($route === 'admins' && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        $rows = $pdo->query("SELECT u.id, u.email, u.role, u.created_at,
                                    TRIM(CONCAT(COALESCE(mp.first_name,''), ' ', COALESCE(mp.surname,''))) AS name
                               FROM users u
                               LEFT JOIN member_profiles mp ON mp.user_id = u.id
                              WHERE u.role = 'admin' ORDER BY u.id")->fetchAll();
        respond(200, array_map(fn($r) => [
            'id' => (int)$r['id'],
            'email' => $r['email'],
            'name' => trim((string)$r['name']) ?: null,
            'role' => $r['role'],
            'isSuperAdmin' => isSuperAdmin(['role' => $r['role'], 'email' => $r['email']], $config),
            'createdAt' => $r['created_at'],
        ], $rows));
    }

    // Promote a member to admin, or demote one back. Super administrator only: an admin who
    // could appoint other admins could hand out their own level of access, which makes the
    // distinction this route exists to enforce meaningless.
    if (preg_match('#^admins/(\d+)/role$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireSuperAdmin($user, $config);

        $targetId = (int)$m[1];
        $role = (string)(input()['role'] ?? '');
        if (!in_array($role, ['member', 'admin'], true)) {
            respond(400, ['error' => 'Role must be member or admin.']);
        }
        if ($targetId === (int)$user['userId']) {
            // Without this a super admin could demote themselves and leave the site with no
            // one able to promote anybody back.
            respond(400, ['error' => 'You cannot change your own role.']);
        }

        $stmt = $pdo->prepare('SELECT id, email, role FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$targetId]);
        $target = $stmt->fetch();
        if (!$target) respond(404, ['error' => 'That account does not exist.']);

        if ($role === 'member' && isSuperAdmin(['role' => $target['role'], 'email' => $target['email']], $config)) {
            respond(400, ['error' => 'That account is named as a super administrator in the server configuration. Remove it there first.']);
        }

        $pdo->prepare('UPDATE users SET role = ? WHERE id = ?')->execute([$role, $targetId]);
        // The role is read live on every request anyway; this also ends their open sessions,
        // so a changed account starts again from a fresh login (and two-factor, if now staff).
        sessionRevokeAll($pdo, $targetId);
        // Target is null: that column holds a member_profile id, and this acts on a user
        // account, which is a different key entirely. The detail carries who was changed.
        logAdminAction($pdo, (int)$user['userId'], 'role_change', null,
            'user #' . $targetId . ' (' . $target['email'] . ') set to ' . $role);
        securityLog($pdo, $config, 'admin_role_changed', 'warning', 'admins',
            $target['email'] . ' set to ' . $role, (int)$user['userId']);
        respond(200, ['id' => $targetId, 'email' => $target['email'], 'role' => $role]);
    }

    // Encrypts rows written before a key existed. Batched and idempotent, so it can be run
    // repeatedly and interrupted without leaving the table half-converted in a way that
    // needs untangling - rows already carrying the marker are skipped.
    if ($route === 'security/encrypt-existing' && $method === 'POST') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('cryptoMigrateColumn', 'lib/crypto.php');

        if (!cryptoAvailable($config)) {
            respond(400, ['error' => 'No data_encryption_key is configured, so there is nothing to encrypt to.']);
        }
        try {
            $ids = cryptoMigrateColumn($pdo, $config, 'member_profiles', 'id', 'id_number');
            $secrets = cryptoMigrateColumn($pdo, $config, 'users', 'id', 'mfa_secret');
        } catch (Throwable $e) {
            respond(500, ['error' => $e->getMessage()]);
        }
        securityLog($pdo, $config, 'encryption_migration', 'info', 'security',
            $ids['encrypted'] . ' id numbers, ' . $secrets['encrypted'] . ' secrets', (int)$user['userId']);
        respond(200, [
            'idNumbers' => $ids,
            'mfaSecrets' => $secrets,
            'message' => 'Run again if either scanned count reached the batch limit of 500.',
        ]);
    }

    if ($route === 'security/assessment' && $method === 'GET') {
        requireModule('securityAssessment', 'lib/security-assessment.php');
        $user = auth($config);
        requireSuperAdmin($user, $config);
        respond(200, securityAssessment($pdo, $config));
    }

    if ($route === 'payment-instructions' && $method === 'GET') {
        // Methods shown to members as planned but not yet accepted. Announcing them is a
        // commitment, so keep this list to things actually being pursued - and move an entry
        // out of here only when its flow genuinely works end to end, never just because the
        // integration exists. M-Pesa Express is not listed: the payment page shows its own
        // STK form, greyed out as "Coming soon" until stkPushLive() is true.
        // Each tile renders, in order of preference: `logo` (a file under assets/img/payments/),
        // then `icon` (a Font Awesome brand glyph tinted with `color`), then `wordmark` (the
        // name set in the brand's colour). Drop an official SVG from a brand's press kit into
        // assets/img/payments/ and add `logo` to switch that tile to the real mark - which is
        // the right way to show a trademark, rather than approximating one in CSS.
        $comingSoon = [];
        $comingSoon[] = ['name' => 'Visa', 'note' => 'Debit and credit cards', 'icon' => 'fab fa-cc-visa', 'color' => '#1A1F71'];
        $comingSoon[] = ['name' => 'Mastercard', 'note' => 'Debit and credit cards', 'icon' => 'fab fa-cc-mastercard', 'color' => '#EB001B'];
        $comingSoon[] = ['name' => 'Apple Pay', 'note' => 'Pay from iPhone, iPad, or Mac', 'icon' => 'fab fa-cc-apple-pay', 'color' => '#000000'];
        $comingSoon[] = ['name' => 'Pesapal', 'note' => 'Cards, mobile money, and bank options', 'wordmark' => 'Pesapal', 'color' => '#253141'];
        $comingSoon[] = ['name' => 'Bank transfer', 'note' => 'Interbank transfer and cheque payment', 'icon' => 'fas fa-building-columns', 'color' => '#475467'];

        respond(200, [
            'method' => 'M-Pesa Paybill',
            'paybillNumber' => (string)($config['paybill_number'] ?? ''),
            'accountNumber' => (string)($config['paybill_account'] ?? '2038334878'),
            'amount' => (int)($config['membership_fee'] ?? 5000),
            'currency' => 'KES',
            // M-Pesa only for now. Cheque/interbank was offered here but nothing supported
            // it: the confirmation form asks for an M-Pesa code and a phone number, both
            // required, and the code is validated as ^[A-Z0-9-]{6,24}$, which a bank
            // reference need not match. Adding a mode back means adapting that form first.
            'paymentModes' => ['M-PESA Paybill'],
            'categories' => $config['membership_categories'] ?? [],
            // Whether the payment page offers "Pay Now". Off until stk_push_enabled,
            // mpesa_enabled and the credentials are all set - see stkPushLive().
            'stkEnabled' => function_exists('stkPushLive') && stkPushLive($config),
            'comingSoon' => $comingSoon
        ]);
    }

    if (preg_match('#^profile-images/([^/]+)$#', $route, $m) && $method === 'GET') {
        // A member's photograph is personal data. This route previously served it to anyone
        // who knew the filename, which is not access control - it is a URL that happens to
        // be hard to guess, built around a predictable timestamp. A session is now required,
        // and a member may only fetch their own; admins may fetch any, because the review
        // queue has to display them.
        $viewer = auth($config);
        $filename = basename(rawurldecode($m[1]));

        // Uploads store the path as 'profile-images/<file>', and this used to look up the bare
        // file name - so no member ever matched as the owner of their own photo, and only
        // admins could see any. Both forms are accepted in case an older row holds the bare name.
        $owner = $pdo->prepare('SELECT user_id FROM member_profiles WHERE profile_image IN (?, ?) LIMIT 1');
        $owner->execute(['profile-images/' . $filename, $filename]);
        $ownerRow = $owner->fetch();
        $isOwner = $ownerRow && (int)$ownerRow['user_id'] === (int)$viewer['userId'];
        if (!$isOwner && ($viewer['role'] ?? '') !== 'admin') {
            // Deliberately 404 rather than 403: a 403 confirms the file exists, which tells
            // someone probing filenames that their guess was correct.
            respond(404, ['error' => 'Profile photo not found']);
        }

        $file = rtrim($config['upload_dir'], '/\\') . '/profile-images/' . $filename;
        if (!is_file($file)) respond(404, ['error' => 'Profile photo not found']);

        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $mimeTypes = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'webp' => 'image/webp'
        ];
        if (!isset($mimeTypes[$extension])) respond(400, ['error' => 'Unsupported profile photo type']);

        header_remove('Content-Type');
        header('Content-Type: ' . $mimeTypes[$extension]);
        header('Content-Length: ' . filesize($file));
        // private: the browser may keep it, a shared cache may not. The host runs one in front
        // of the site, and 'public' let it hold a member's photo for anyone with the URL.
        header('Cache-Control: private, max-age=86400');
        header('Vary: Cookie');
        readfile($file);
        exit;
    }

    if ($route === 'setup/admin') {
        if ($method !== 'POST') {
            respond(405, ['error' => 'Use POST to create or update the admin user.']);
        }
        $data = input();
        $setupKey = $config['setup_key'] ?? '';
        $providedKey = $_SERVER['HTTP_X_SETUP_KEY'] ?? ($data['key'] ?? '');
        if (!$setupKey || !hash_equals((string)$setupKey, (string)$providedKey)) {
            respond(403, ['error' => 'Admin setup is disabled']);
        }
        $email = trim((string)($data['email'] ?? ''));
        $password = (string)($data['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respond(400, ['error' => 'Valid email is required']);
        if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{12,64}$/', $password)) {
            respond(400, ['error' => 'Password must be 12-64 characters and include uppercase, lowercase, and a number']);
        }
        $stmt = $pdo->prepare(
            'INSERT INTO users (email, password_hash, email_verified, role)
             VALUES (?, ?, TRUE, "admin")
             ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), email_verified = TRUE, role = "admin"'
        );
        $stmt->execute([$email, password_hash($password, PASSWORD_DEFAULT)]);
        respond(200, ['message' => 'Admin user is ready. Remove setup_key from config.php now.']);
    }

    if ($route === 'auth/register' && $method === 'POST') {
        $data = input();
        requireFields($data, ['email', 'password', 'firstName', 'surname', 'mobile', 'country', 'county', 'division', 'profession', 'specialization', 'institution', 'physicalAddress', 'payerType', 'category', 'idNumber']);
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) respond(400, ['error' => 'Please enter a valid email address']);
        // Answers as though it worked, so a script learns nothing about which signal caught
        // it. A real member never reaches this: the honeypot is invisible and nobody
        // completes fifteen fields in three seconds.
        botScreenOrFakeSuccess($pdo, $config, $data, 'register', [
            'message' => 'Registration successful! Please check your email to verify your account.',
        ]);

        // Fifteen fields were accepted and four were checked. These are not the security
        // boundary - queries are bound and output escaped - but unbounded input is how a
        // name column ends up holding a kilobyte of pasted text.
        validateInput($data, [
            'firstName'       => ['First name', 'name'],
            'surname'         => ['Surname', 'name'],
            'middleName'      => ['Middle name', 'name', false],
            'title'           => ['Title', 'text', false, ['max' => 20]],
            'mobile'          => ['Mobile number', 'phone'],
            'country'         => ['Country', 'text', true, ['max' => 60]],
            'county'          => ['County', 'text', true, ['max' => 60]],
            'division'        => ['Division', 'text', true, ['max' => 80]],
            'profession'      => ['Profession', 'text', true, ['max' => 100]],
            'specialization'  => ['Specialization', 'text', true, ['max' => 120]],
            'institution'     => ['Institution', 'text', true, ['max' => 160]],
            'physicalAddress' => ['Physical address', 'address'],
            'category'        => ['Membership category', 'text', true, ['max' => 80]],
            'idNumber'        => ['ID number', 'id'],
        ]);
        if (!preg_match('/^\+[1-9]\d{7,14}$/', $data['mobile'])) respond(400, ['error' => 'Please enter a valid mobile number with country code']);
        if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{8,64}$/', $data['password'])) respond(400, ['error' => 'Password must be 8-64 characters and include uppercase, lowercase, and a number']);

        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$data['email']]);
        throttleCheck($pdo, $config, 'register', (string)($data['email'] ?? ''));
        if ($stmt->fetch()) {
            throttleFailure($pdo, $config, 'register', (string)($data['email'] ?? ''));
            respond(400, ['error' => 'Email already registered']);
        }

        $verified = empty($config['require_email_verification']) ? 1 : 0;
        $verificationToken = $verified ? null : bin2hex(random_bytes(32));
        $pdo->beginTransaction();
        $stmt = $pdo->prepare('INSERT INTO users (email, password_hash, email_verified, role, verification_token) VALUES (?, ?, ?, "member", ?)');
        $stmt->execute([$data['email'], password_hash($data['password'], PASSWORD_DEFAULT), $verified, $verificationToken]);
        $userId = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare(
            'INSERT INTO member_profiles (user_id, title, first_name, middle_name, surname, country, county, division, profession, specialization, institution, physical_address, payer_type, category, id_type, id_number, mobile, membership_status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "payment_required")'
        );
        $stmt->execute([
            $userId,
            $data['title'] ?? null,
            $data['firstName'],
            $data['middleName'] ?? null,
            $data['surname'],
            $data['country'],
            $data['county'],
            $data['division'],
            $data['profession'],
            $data['specialization'],
            $data['institution'],
            $data['physicalAddress'],
            $data['payerType'],
            $data['category'],
            $data['idType'] ?? 'ID',
            cryptoEncrypt($config, (string)$data['idNumber']),
            $data['mobile']
        ]);
        $pdo->commit();

        if (!$verified && $verificationToken) {
            try {
                if (!sendVerificationEmail($config, (string)$data['email'], $verificationToken, (string)$data['firstName'], (string)($data['title'] ?? ''), (string)$data['surname'])) {
                    error_log('Verification email to ' . $data['email'] . ' returned false - see SMTP log lines above for the specific stage that failed.');
                }
            } catch (Throwable $mailError) {
                error_log('Verification email threw: ' . $mailError->getMessage());
            }
        }

        // An invited member who completed the form: mark their invitation used so it cannot
        // be claimed twice and the admin list shows who has actually joined. Guarded and
        // never fatal - the account exists at this point, and losing the bookkeeping must
        // not undo a registration that succeeded.
        if (!empty($data['inviteToken']) && function_exists('inviteMarkClaimed')) {
            inviteMarkClaimed($pdo, (string)$data['inviteToken'], $userId, (string)$data['email']);
        }

        $payload = ['message' => $verified ? 'Registration successful.' : 'Registration successful! Please check your email to verify your account before logging in.', 'userId' => $userId, 'requiresVerification' => !$verified];
        if ($verified) {
            $registerToken = token(['userId' => $userId, 'email' => $data['email'], 'role' => 'member'], $config['jwt_secret']);
            issueAuthCookie($registerToken);
            $payload['token'] = $registerToken;
            $payload['user'] = ['id' => $userId, 'email' => $data['email'], 'role' => 'member', 'membershipStatus' => 'payment_required', 'membershipId' => null, 'cpdPoints' => 0];
        }
        respond(201, $payload);
    }

    /**
     * An Academy account for someone who is not applying for membership.
     *
     * Same users table, so the same login, password reset, two-factor and rate limiting as
     * everyone else - but no member_profiles row. That is deliberate: a learner is not an
     * applicant, so they must not appear in the membership list, on renewal reminders or on an
     * electoral roll, and must not be asked for the fifteen fields a membership application
     * needs. Being a learner is read from that absence rather than stored as a role: the role
     * enum is declared in three schema files that must agree, and when they once did not, it
     * silently wiped every role that was missing from one of them.
     */
    if ($route === 'auth/register-learner' && $method === 'POST') {
        $data = input();
        requireFields($data, ['email', 'password', 'firstName', 'surname', 'country']);
        $email = strtolower(trim((string)$data['email']));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respond(400, ['error' => 'Please enter a valid email address']);
        botScreenOrFakeSuccess($pdo, $config, $data, 'register', [
            'message' => 'Account created. Please check your email to confirm your address.',
            'requiresVerification' => true,
        ]);
        validateInput($data, [
            'firstName'  => ['First name', 'name'],
            'surname'    => ['Surname', 'name'],
            'country'    => ['Country', 'text', true, ['max' => 60]],
            'profession' => ['Profession', 'text', false, ['max' => 100]],
        ]);
        if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{8,64}$/', (string)$data['password'])) {
            respond(400, ['error' => 'Password must be 8-64 characters and include uppercase, lowercase, and a number']);
        }

        throttleCheck($pdo, $config, 'register', $email);
        $stmt = $pdo->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            throttleFailure($pdo, $config, 'register', $email);
            respond(400, ['error' => 'An account with this email already exists. Sign in instead, or use "Forgot password" if you cannot remember it.']);
        }

        $firstName = trim((string)preg_replace('/\s+/u', ' ', (string)$data['firstName']));
        $surname = trim((string)preg_replace('/\s+/u', ' ', (string)$data['surname']));
        $fullName = $firstName . ' ' . $surname;
        $profession = trim((string)($data['profession'] ?? ''));
        $verified = empty($config['require_email_verification']) ? 1 : 0;
        $verificationToken = $verified ? null : bin2hex(random_bytes(32));

        $pdo->beginTransaction();
        try {
            $pdo->prepare('INSERT INTO users (email, password_hash, email_verified, role, verification_token) VALUES (?, ?, ?, "member", ?)')
                ->execute([$email, password_hash((string)$data['password'], PASSWORD_DEFAULT), $verified, $verificationToken]);
            $userId = (int)$pdo->lastInsertId();
            // The certificate name starts as the name they signed up with; they confirm it
            // before a certificate is issued.
            $pdo->prepare('INSERT INTO academy_learners (user_id, display_name, certificate_name, country, profession) VALUES (?, ?, ?, ?, ?)')
                ->execute([$userId, $fullName, $fullName, trim((string)$data['country']), $profession !== '' ? $profession : null]);
            $pdo->commit();
        } catch (Throwable $registerError) {
            $pdo->rollBack();
            throw $registerError;
        }

        if ($verificationToken) {
            try {
                if (!sendLearnerVerificationEmail($config, $email, $verificationToken, $firstName)) {
                    error_log('Learner verification email to ' . $email . ' returned false - see the SMTP log lines above.');
                }
            } catch (Throwable $mailError) {
                error_log('Learner verification email threw: ' . $mailError->getMessage());
            }
        }
        securityLog($pdo, $config, 'learner_registered', 'info', 'register', null, $userId);

        $payload = [
            'message' => $verified ? 'Your account is ready.' : 'Account created. Please check your email to confirm your address.',
            'requiresVerification' => !$verified,
        ];
        if ($verified) {
            $learnerToken = token(['userId' => $userId, 'email' => $email, 'role' => 'member'], $config['jwt_secret']);
            issueAuthCookie($learnerToken);
            $payload['user'] = ['id' => $userId, 'email' => $email, 'role' => 'member', 'isLearner' => true,
                                'membershipStatus' => null, 'membershipId' => null, 'cpdPoints' => 0];
        }
        respond(201, $payload);
    }

    if ($route === 'auth/logout' && $method === 'POST') {
        // Ends this session on the server, not only in this browser, so a copy of the cookie
        // taken from this device stops working too. Other devices stay signed in.
        $current = authOptionalToken($config);
        if ($current !== null && !empty($current['jti'])) {
            sessionRevokeToken($pdo, (string)$current['jti'], (int)($current['exp'] ?? (time() + RESOK_SESSION_MAX_LIFETIME)));
        }
        clearAuthCookie();
        if (function_exists('viewAsClearCookie')) viewAsClearCookie();
        respond(200, ['message' => 'Logged out']);
    }

    if (preg_match('#^auth/verify/([A-Za-z0-9]+)$#', $route, $m) && $method === 'GET') {
        $loginUrl = rtrim((string)($config['portal_base_url'] ?? ''), '/') . '/login';
        $stmt = $pdo->prepare('SELECT u.id, (SELECT COUNT(*) FROM member_profiles mp WHERE mp.user_id = u.id) AS has_profile
                               FROM users u WHERE u.verification_token = ? LIMIT 1');
        $stmt->execute([$m[1]]);
        $user = $stmt->fetch();
        if (!$user) {
            respondHtmlPage(400, 'Invalid or Expired Link', 'This verification link is invalid or has already been used. If you still need to verify your account, try registering again or contact support.', true, 'Go to Login', $loginUrl);
        }
        $pdo->prepare('UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?')->execute([(int)$user['id']]);
        if ((int)$user['has_profile'] === 0) {
            // An author who registered from the abstracts page goes back there. Checked
            // against both tables, because a learner who later writes an abstract has both
            // and was a learner first.
            try {
                $kind = $pdo->prepare('SELECT (SELECT COUNT(*) FROM abs_profiles WHERE user_id = ?) AS author,
                                              (SELECT COUNT(*) FROM academy_learners WHERE user_id = ?) AS learner');
                $kind->execute([(int)$user['id'], (int)$user['id']]);
                $k = $kind->fetch();
                if ((int)$k['author'] > 0 && (int)$k['learner'] === 0) {
                    respondHtmlPage(200, 'Email Verified', 'Your ReSoK account is ready. Sign in to start your abstract submission.', false, 'Sign In', $loginUrl . '?next=' . rawurlencode('/resok-portal/public/abstracts'));
                }
            } catch (Throwable $kindError) {
                // Either table missing just means this is not an author; carry on as before.
            }
            // An Academy learner has no membership application to continue.
            respondHtmlPage(200, 'Email Verified', 'Your ReSoK Virtual Academy account is ready. Sign in to start learning.', false, 'Sign In', $loginUrl . '?next=' . rawurlencode('/resok-portal/public/academy'));
        }
        respondHtmlPage(200, 'Email Verified', 'Your ReSoK account is now active. You can log in and continue your membership application.', false, 'Log In Now', $loginUrl);
    }

    if ($route === 'auth/login' && $method === 'POST') {
        // Only through api/login.php on the live server, where Cloudflare rate-limits that path.
        // The laptop's test suites still call it here.
        if (!defined('RESOK_LOGIN_ENTRY') && !(function_exists('geoLocalRequest') && geoLocalRequest())) {
            respond(404, ['error' => 'Sign in at the login page.']);
        }
        $data = input();
        $stmt = $pdo->prepare(
            'SELECT u.id, u.email, u.password_hash, u.email_verified, u.role, mp.membership_status, mp.membership_id, mp.cpd_points
             FROM users u LEFT JOIN member_profiles mp ON mp.user_id = u.id WHERE u.email = ? LIMIT 1'
        );
        $loginEmail = (string)($data['email'] ?? '');
        // Screened before the password is even looked at, so an automated run costs nothing
        // and reveals nothing. Answers with the same message a wrong password gets.
        if (botScreen($data, 0) !== null) {   // honeypot only - see input-guard.php
            securityLog($pdo, $config, 'bot_blocked', 'info', 'login', 'Login screened');
            respond(401, ['error' => 'Invalid credentials']);
        }
        authThrottleCheck($pdo, $config, $loginEmail);
        $stmt->execute([$data['email'] ?? '']);
        $user = $stmt->fetch();
        // Staff and admin accounts lock after three wrong passwords (lib/staff-geo.php).
        if ($user && function_exists('geoLockCheck')) geoLockCheck($pdo, $config, $user);
        if (!$user || !password_verify($data['password'] ?? '', $user['password_hash'])) {
            authThrottleFailure($pdo, $config, $loginEmail);
            if ($user && function_exists('geoLockFailure')) geoLockFailure($pdo, $config, $user);
            respond(401, ['error' => 'Invalid credentials']);
        }
        if (function_exists('geoLockClear')) geoLockClear($pdo, (int)$user['id']);
        if (!$user['email_verified']) respond(403, ['error' => 'Please verify your email before logging in']);
        authThrottleSuccess($pdo, $config, $loginEmail);

        completeLogin($pdo, $config, $user);
    }

    // Which sign-in options the pages should offer. Public: the Google client ID is not a
    // secret, it is printed into Google's button on every page that shows it.
    if ($route === 'auth/providers' && $method === 'GET') {
        respond(200, ['google' => function_exists('googleSignInEnabled') && googleSignInEnabled($config) ? googleClientId($config) : null]);
    }

    // "Continue with Google" (lib/google-signin.php). An existing account is signed in -
    // matched by the email address Google has verified, so this is no weaker than the
    // password-reset email, and the account's second factor still applies. With purpose
    // "abstracts", someone with no account gets an author account (ACC-1), like the form on
    // the abstracts page; anywhere else they are told to register first.
    if ($route === 'auth/google' && $method === 'POST') {
        if (!function_exists('googleSignInEnabled') || !googleSignInEnabled($config)) {
            respond(404, ['error' => 'Google sign-in is not available.']);
        }
        $data = input();
        $ip = function_exists('clientIp') ? clientIp() : (string)($_SERVER['REMOTE_ADDR'] ?? '');
        throttleCheck($pdo, $config, 'google_login', $ip);
        $claims = googleVerifyIdToken($config, (string)($data['credential'] ?? ''), $why);
        if (!$claims) {
            throttleFailure($pdo, $config, 'google_login', $ip);
            securityLog($pdo, $config, 'google_login_rejected', 'warning', 'login', 'Google token rejected: ' . $why);
            respond(401, ['error' => 'Google sign-in did not work. Please try again, or sign in with your password.']);
        }
        throttleSuccess($pdo, $config, 'google_login', $ip);
        $email = $claims['email'];
        $find = $pdo->prepare('SELECT u.id, u.email, u.email_verified, u.role, mp.membership_status, mp.membership_id, mp.cpd_points
                               FROM users u LEFT JOIN member_profiles mp ON mp.user_id = u.id WHERE LOWER(u.email) = ? LIMIT 1');
        $find->execute([$email]);
        $user = $find->fetch();

        if (!$user) {
            if (($data['purpose'] ?? '') !== 'abstracts' || !function_exists('absProfileSave')) {
                respond(404, ['error' => "There is no ReSoK account for {$email}. Members register through the membership form; "
                    . 'to submit an abstract, use "Continue with Google" on the abstract submission page.', 'noAccount' => true]);
            }
            abstractsEnsureTables($pdo);
            $pdo->beginTransaction();
            try {
                // No usable password: random, and never shown. "Forgot password" sets one if
                // they ever want to sign in without Google.
                $pdo->prepare('INSERT INTO users (email, password_hash, email_verified, role, verification_token) VALUES (?, ?, 1, "member", NULL)')
                    ->execute([$email, password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT)]);
                $userId = (int)$pdo->lastInsertId();
                // The name from Google; affiliation and country are asked for on the abstracts page.
                $first = mb_substr($claims['given_name'] !== '' ? $claims['given_name'] : $claims['name'], 0, 80);
                $pdo->prepare("INSERT INTO abs_profiles (user_id, first_name, last_name, affiliation, country) VALUES (?, ?, ?, '', '')")
                    ->execute([$userId, $first, mb_substr($claims['family_name'], 0, 80)]);
                $pdo->commit();
            } catch (Throwable $googleError) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $googleError;
            }
            securityLog($pdo, $config, 'author_registered', 'info', 'register', 'Signed up with Google', $userId);
            $find->execute([$email]);
            $user = $find->fetch();
        } elseif (!(int)$user['email_verified']) {
            // Google has just proved they own the address, which is all verification asks.
            $pdo->prepare('UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?')->execute([(int)$user['id']]);
        }
        securityLog($pdo, $config, 'google_login', 'info', 'login', null, (int)$user['id']);
        completeLogin($pdo, $config, $user);
    }

    // Second factor: exchange a challenge token plus a code for a session.
    if ($route === 'auth/mfa/verify' && $method === 'POST') {
        requireModule('mfaVerifyChallenge', 'lib/mfa.php');
        $data = input();
        $userId = mfaVerifyChallenge($config, (string)($data['challenge'] ?? ''));
        if (!$userId) respond(401, ['error' => 'That sign-in attempt expired. Please log in again.']);

        // The code is guessable in six digits, so it is rate limited harder than a password.
        throttleCheck($pdo, $config, 'login', 'mfa:' . $userId);
        if (!mfaEnsureColumns($pdo)) respond(503, ['error' => 'Two-factor authentication is unavailable on this server: its columns are missing and could not be created. Import resok-portal/server/schema-security.sql.']);
        $stmt = $pdo->prepare('SELECT u.id, u.email, u.role, u.mfa_secret, u.mfa_recovery, mp.membership_status, mp.membership_id, mp.cpd_points
                                 FROM users u LEFT JOIN member_profiles mp ON mp.user_id = u.id WHERE u.id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        if (!$user) respond(401, ['error' => 'That sign-in attempt is no longer valid.']);

        $code = (string)($data['code'] ?? '');
        $ok = mfaVerifyCode((string)cryptoDecrypt($config, $user['mfa_secret']), $code);
        $usedRecovery = false;
        if (!$ok && strlen(trim($code)) >= 8) {
            $ok = mfaConsumeRecoveryCode($pdo, (int)$user['id'], (string)$user['mfa_recovery'], $code);
            $usedRecovery = $ok;
        }
        if (!$ok) {
            throttleFailure($pdo, $config, 'login', 'mfa:' . $userId);
            securityLog($pdo, $config, 'mfa_failed', 'warning', 'login', null, (int)$user['id']);
            respond(401, ['error' => 'That code was not correct.']);
        }
        throttleSuccess($pdo, $config, 'login', 'mfa:' . $userId);
        securityLog($pdo, $config, $usedRecovery ? 'mfa_recovery_used' : 'mfa_success',
            $usedRecovery ? 'warning' : 'info', 'login', null, (int)$user['id']);

        mfaGrantSession($pdo, $config, (int)$user['id'], ['usedRecoveryCode' => $usedRecovery]);
    }

    // ----- Passkeys: face or fingerprint as the second factor (lib/passkey.php) -----

    // Sign-in, step 1: the password step's challenge token in, the device's challenge out.
    if ($route === 'auth/passkey/login/options' && $method === 'POST') {
        requireModule('passkeyIssueChallenge', 'lib/passkey.php');
        requireModule('mfaVerifyChallenge', 'lib/mfa.php');
        $userId = mfaVerifyChallenge($config, (string)(input()['challenge'] ?? ''));
        if (!$userId) respond(401, ['error' => 'That sign-in attempt expired. Please log in again.']);
        if (!passkeyEnsureTables($pdo)) respond(503, ['error' => 'Passkeys are unavailable on this server.']);
        throttleCheck($pdo, $config, 'login', 'mfa:' . $userId);
        $creds = $pdo->prepare('SELECT credential_id FROM user_passkeys WHERE user_id = ?');
        $creds->execute([$userId]);
        $ids = $creds->fetchAll(PDO::FETCH_COLUMN);
        if (!$ids) respond(400, ['error' => 'This account has no face or fingerprint sign-in. Use the code from your app.']);
        respond(200, ['publicKey' => [
            'challenge' => passkeyIssueChallenge($pdo, $userId, 'login'),
            'rpId' => passkeyRpId($config),
            'allowCredentials' => array_map(static fn($id) => ['type' => 'public-key', 'id' => $id], $ids),
            'userVerification' => 'required',
            'timeout' => 60000,
        ]]);
    }

    // Sign-in, step 2: the device's signed answer in, a session out.
    if ($route === 'auth/passkey/login/verify' && $method === 'POST') {
        requireModule('passkeyVerifyAssertion', 'lib/passkey.php');
        requireModule('mfaVerifyChallenge', 'lib/mfa.php');
        $data = input();
        $userId = mfaVerifyChallenge($config, (string)($data['challenge'] ?? ''));
        if (!$userId) respond(401, ['error' => 'That sign-in attempt expired. Please log in again.']);
        if (!passkeyEnsureTables($pdo)) respond(503, ['error' => 'Passkeys are unavailable on this server.']);
        throttleCheck($pdo, $config, 'login', 'mfa:' . $userId);
        $why = null;
        $name = passkeyVerifyAssertion($pdo, $config, $userId, is_array($data['credential'] ?? null) ? $data['credential'] : [], $why);
        if ($name === null) {
            throttleFailure($pdo, $config, 'login', 'mfa:' . $userId);
            securityLog($pdo, $config, 'passkey_failed', 'warning', 'login', (string)$why, $userId);
            respond(401, ['error' => 'Your face or fingerprint sign-in was not accepted. Try again, or use the code from your app.']);
        }
        throttleSuccess($pdo, $config, 'login', 'mfa:' . $userId);
        securityLog($pdo, $config, 'passkey_success', 'info', 'login', $name, $userId);
        mfaGrantSession($pdo, $config, $userId, ['usedPasskey' => true]);
    }

    if (strpos($route, 'auth/passkey') === 0) {
        requireModule('passkeyRegister', 'lib/passkey.php');
        requireModule('mfaVerifyCode', 'lib/mfa.php');
        $user = auth($config);
        $userId = (int)$user['userId'];
        if (!passkeyEnsureTables($pdo) || !mfaEnsureColumns($pdo)) respond(503, ['error' => 'Passkeys are unavailable on this server.']);
        $account = $pdo->prepare('SELECT email, password_hash, mfa_enabled, mfa_secret FROM users WHERE id = ? LIMIT 1');
        $account->execute([$userId]);
        $acct = $account->fetch() ?: [];

        if ($route === 'auth/passkey/list' && $method === 'GET') {
            respond(200, ['passkeys' => passkeyList($pdo, $userId), 'available' => (int)($acct['mfa_enabled'] ?? 0) === 1]);
        }

        // Adding one: two-factor must already be on, and a current app code proves that the
        // person at the keyboard holds the account's existing second factor - a stolen
        // session alone cannot add a face of its own.
        if ($route === 'auth/passkey/register/options' && $method === 'POST') {
            if ((int)($acct['mfa_enabled'] ?? 0) !== 1) respond(400, ['error' => 'Turn on two-factor with an authenticator app first. A face or fingerprint is added on top of it.']);
            throttleCheck($pdo, $config, 'login', 'mfa:' . $userId);
            // The app's current code, or one recovery code (used up, as at sign-in): either
            // proves the person holds the account's existing second factor.
            $code = (string)(input()['code'] ?? '');
            $ok = mfaVerifyCode((string)cryptoDecrypt($config, (string)$acct['mfa_secret']), $code);
            if (!$ok && strlen(trim($code)) >= 8) {
                $rec = $pdo->prepare('SELECT mfa_recovery FROM users WHERE id = ?');
                $rec->execute([$userId]);
                $ok = mfaConsumeRecoveryCode($pdo, $userId, (string)$rec->fetchColumn(), $code);
                if ($ok) securityLog($pdo, $config, 'mfa_recovery_used', 'warning', 'mfa', 'to add a passkey', $userId);
            }
            if (!$ok) {
                throttleFailure($pdo, $config, 'login', 'mfa:' . $userId);
                securityLog($pdo, $config, 'passkey_add_refused', 'warning', 'mfa', 'Wrong code', $userId);
                respond(401, ['error' => 'That code was not correct. Enter the current code from your authenticator app, or one of your recovery codes.']);
            }
            $existing = $pdo->prepare('SELECT credential_id FROM user_passkeys WHERE user_id = ?');
            $existing->execute([$userId]);
            respond(200, ['publicKey' => [
                'challenge' => passkeyIssueChallenge($pdo, $userId, 'register'),
                'rp' => ['id' => passkeyRpId($config), 'name' => 'ReSoK Portal'],
                'user' => ['id' => b64url(hash('sha256', 'resok-user|' . $userId, true)), 'name' => (string)$acct['email'], 'displayName' => (string)$acct['email']],
                'pubKeyCredParams' => [['type' => 'public-key', 'alg' => PASSKEY_ALG_ES256], ['type' => 'public-key', 'alg' => PASSKEY_ALG_RS256]],
                'authenticatorSelection' => ['userVerification' => 'required', 'residentKey' => 'preferred'],
                'excludeCredentials' => array_map(static fn($id) => ['type' => 'public-key', 'id' => $id], $existing->fetchAll(PDO::FETCH_COLUMN)),
                'attestation' => 'none',
                'timeout' => 120000,
            ]]);
        }
        if ($route === 'auth/passkey/register/verify' && $method === 'POST') {
            $data = input();
            $name = trim((string)preg_replace('/\s+/', ' ', (string)($data['name'] ?? '')));
            $name = mb_substr($name !== '' ? $name : 'This device', 0, 80);
            [$added, $error] = passkeyRegister($pdo, $config, $userId, is_array($data['credential'] ?? null) ? $data['credential'] : [], $name);
            if ($error) {
                securityLog($pdo, $config, 'passkey_add_failed', 'info', 'mfa', $error, $userId);
                respond(400, ['error' => $error]);
            }
            securityLog($pdo, $config, 'passkey_added', 'warning', 'mfa', $name, $userId);
            respond(200, ['added' => $added, 'passkeys' => passkeyList($pdo, $userId)]);
        }
        // Removing one needs the password, as turning two-factor off does.
        if (preg_match('#^auth/passkey/(\d+)/delete$#', $route, $m) && $method === 'POST') {
            if (!password_verify((string)(input()['password'] ?? ''), (string)($acct['password_hash'] ?? ''))) {
                securityLog($pdo, $config, 'passkey_remove_refused', 'warning', 'mfa', 'Wrong password', $userId);
                respond(401, ['error' => 'That password was not correct.']);
            }
            $del = $pdo->prepare('DELETE FROM user_passkeys WHERE id = ? AND user_id = ?');
            $del->execute([(int)$m[1], $userId]);
            if ($del->rowCount() === 0) respond(404, ['error' => 'No such passkey on your account.']);
            securityLog($pdo, $config, 'passkey_removed', 'warning', 'mfa', 'passkey #' . (int)$m[1], $userId);
            respond(200, ['passkeys' => passkeyList($pdo, $userId)]);
        }
        respond(404, ['error' => 'Route not found']);
    }

    // Enrolment. The secret is generated but not activated until a code proves the app
    // holds it - otherwise a mistyped setup locks the member out of their own account.
    if ($route === 'auth/mfa/setup' && $method === 'POST') {
        requireModule('mfaGenerateSecret', 'lib/mfa.php');
        $user = auth($config);
        if (!mfaEnsureColumns($pdo)) respond(503, ['error' => 'Two-factor authentication is unavailable on this server: its columns are missing and could not be created. Import resok-portal/server/schema-security.sql.']);
        $userId = (int)$user['userId'];
        $stmt = $pdo->prepare('SELECT mfa_enabled, mfa_secret FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $current = $stmt->fetch() ?: [];

        // Setup used to set mfa_enabled = 0 unconditionally, so any session - a stolen one
        // included - could switch two-factor off without the password that the disable
        // route demands. Once it is on, the only way to start over is that route.
        if ((int)($current['mfa_enabled'] ?? 0) === 1) {
            respond(409, ['error' => 'Two-factor authentication is already on. To set it up again, turn it off first with your password.']);
        }

        // A second press of "Start" (or a reload) used to replace the secret, so the app the
        // member had already scanned showed codes that could never match - which locked an
        // administrator out on 8 Oct 2026. A pending secret is now reused until enrolment
        // completes, so every scan of this setup shows the same codes.
        $secret = null;
        if (!empty($current['mfa_secret'])) {
            $pending = cryptoDecrypt($config, (string)$current['mfa_secret']);
            if (is_string($pending) && preg_match('/^[A-Z2-7]{16,}$/', $pending)) $secret = $pending;
        }
        if ($secret === null) {
            $secret = mfaGenerateSecret();
            $pdo->prepare('UPDATE users SET mfa_secret = ? WHERE id = ? AND mfa_enabled = 0')
                ->execute([cryptoEncrypt($config, $secret), $userId]);

            // Read it back before showing it. An encrypted secret is ~90 characters, and a
            // column too narrow for it is truncated by MySQL without an error - after which no
            // code can ever match. Better to refuse here than to let someone enrol into that.
            $check = $pdo->prepare('SELECT mfa_secret FROM users WHERE id = ? LIMIT 1');
            $check->execute([$userId]);
            if (cryptoDecrypt($config, (string)($check->fetch()['mfa_secret'] ?? '')) !== $secret) {
                $pdo->prepare('UPDATE users SET mfa_secret = NULL WHERE id = ? AND mfa_enabled = 0')->execute([$userId]);
                securityLog($pdo, $config, 'mfa_secret_store_failed', 'critical', 'mfa', 'Secret did not survive storage - check users.mfa_secret width', $userId);
                respond(500, ['error' => 'Two-factor could not be set up because the server could not store it correctly. Nothing has changed on your account. Please tell the ICT team: the users.mfa_secret column needs widening (schema-security.sql).']);
            }
        }
        respond(200, [
            'secret' => $secret,
            'uri' => mfaProvisioningUri($secret, (string)$user['email']),
        ]);
    }

    if ($route === 'auth/mfa/enable' && $method === 'POST') {
        requireModule('mfaGenerateSecret', 'lib/mfa.php');
        $user = auth($config);
        if (!mfaEnsureColumns($pdo)) respond(503, ['error' => 'Two-factor authentication is unavailable on this server: its columns are missing and could not be created. Import resok-portal/server/schema-security.sql.']);
        $stmt = $pdo->prepare('SELECT mfa_secret FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$user['userId']]);
        $row = $stmt->fetch();
        if (!$row || empty($row['mfa_secret'])) respond(400, ['error' => 'Start the setup again.']);
        if (!mfaVerifyCode((string)cryptoDecrypt($config, $row['mfa_secret']), (string)(input()['code'] ?? ''))) {
            securityLog($pdo, $config, 'mfa_enrol_failed', 'info', 'mfa', null, (int)$user['userId']);
            respond(400, ['error' => 'That code was not correct. Check your app and try again.']);
        }
        $recovery = mfaGenerateRecoveryCodes();
        $pdo->prepare('UPDATE users SET mfa_enabled = 1, mfa_enrolled_at = NOW(), mfa_recovery = ? WHERE id = ?')
            ->execute([$recovery['hashed'], (int)$user['userId']]);
        securityLog($pdo, $config, 'mfa_enabled', 'info', 'mfa', null, (int)$user['userId']);
        respond(200, ['enabled' => true, 'recoveryCodes' => $recovery['plain']]);
    }

    // Turning it off requires the password again: a hijacked session must not be able to
    // quietly remove the control that would have stopped it.
    if ($route === 'auth/mfa/disable' && $method === 'POST') {
        requireModule('mfaGenerateSecret', 'lib/mfa.php');
        $user = auth($config);
        if (!mfaEnsureColumns($pdo)) respond(503, ['error' => 'Two-factor authentication is unavailable on this server: its columns are missing and could not be created. Import resok-portal/server/schema-security.sql.']);
        $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$user['userId']]);
        $row = $stmt->fetch();
        if (!$row || !password_verify((string)(input()['password'] ?? ''), (string)$row['password_hash'])) {
            securityLog($pdo, $config, 'mfa_disable_refused', 'warning', 'mfa', 'Wrong password', (int)$user['userId']);
            respond(401, ['error' => 'That password was not correct.']);
        }
        $pdo->prepare('UPDATE users SET mfa_enabled = 0, mfa_secret = NULL, mfa_recovery = NULL WHERE id = ?')
            ->execute([(int)$user['userId']]);
        // A passkey is a second factor on top of the app; with two-factor off it goes too.
        if (function_exists('passkeyEnsureTables') && passkeyEnsureTables($pdo)) {
            $pdo->prepare('DELETE FROM user_passkeys WHERE user_id = ?')->execute([(int)$user['userId']]);
        }
        securityLog($pdo, $config, 'mfa_disabled', 'warning', 'mfa', null, (int)$user['userId']);
        respond(200, ['enabled' => false]);
    }

    if ($route === 'auth/mfa/status' && $method === 'GET') {
        requireModule('mfaGenerateSecret', 'lib/mfa.php');
        $user = auth($config);
        // Reported as simply "off" when the columns are absent, rather than failing. This
        // is what the security page calls on load; a page whose job is to report state
        // should say "unavailable", not break.
        if (!mfaEnsureColumns($pdo)) {
            respond(200, [
                'enabled' => false, 'enrolledAt' => null, 'recoveryRemaining' => 0,
                'available' => false,
                'requiredForRole' => mfaRequiredForRole((string)($user['role'] ?? 'member')),
            ]);
        }
        $stmt = $pdo->prepare('SELECT mfa_enabled, mfa_enrolled_at, mfa_recovery FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$user['userId']]);
        $row = $stmt->fetch() ?: [];
        $remaining = json_decode((string)($row['mfa_recovery'] ?? '[]'), true);
        respond(200, [
            'enabled' => (bool)(int)($row['mfa_enabled'] ?? 0),
            'enrolledAt' => $row['mfa_enrolled_at'] ?? null,
            'recoveryRemaining' => is_array($remaining) ? count($remaining) : 0,
            // Stated in both branches. The unavailable branch above says available:false, so
            // a caller that only ever saw this one had to infer the good case from a missing
            // key - which reads as false in JavaScript exactly when it should read as true.
            'available' => true,
            'requiredForRole' => mfaRequiredForRole((string)($user['role'] ?? 'member')),
        ]);
    }

    // Resend a verification email. Without this, a member whose verification landed in spam
    // is permanently stuck: they cannot sign in because they are unverified, and they cannot
    // register again because the address is taken.
    if ($route === 'auth/resend-verification' && $method === 'POST') {
        $data = input();
        $email = strtolower(trim((string)($data['email'] ?? '')));
        if ($email === '') respond(400, ['error' => 'An email address is required.']);

        // Costs an email every time, so it is throttled like the reset endpoint, and the
        // reply is identical either way - this must not become a way to test which addresses
        // are registered.
        throttleCheck($pdo, $config, 'password-reset', $email);
        throttleFailure($pdo, $config, 'password-reset', $email);

        $stmt = $pdo->prepare('SELECT id, email_verified FROM users WHERE LOWER(email) = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && !(int)$user['email_verified']) {
            // A fresh token each time, so an older link stops working.
            $token = bin2hex(random_bytes(32));
            $pdo->prepare('UPDATE users SET verification_token = ? WHERE id = ?')->execute([$token, (int)$user['id']]);
            try {
                // The member's name and title, so the resent email greets them as the first did.
                $who = $pdo->prepare('SELECT title, first_name, surname FROM member_profiles WHERE user_id = ? LIMIT 1');
                $who->execute([(int)$user['id']]);
                $who = $who->fetch() ?: [];
                if (function_exists('sendVerificationEmail')) sendVerificationEmail($config, $email, $token,
                    (string)($who['first_name'] ?? ''), (string)($who['title'] ?? ''), (string)($who['surname'] ?? ''));
            } catch (Throwable $e) {
                error_log('Resend verification failed: ' . $e->getMessage());
            }
            securityLog($pdo, $config, 'verification_resent', 'info', 'register', null, (int)$user['id']);
        }

        respond(200, ['message' => 'If that address needs verifying, a new link is on its way.']);
    }

    if ($route === 'auth/forgot-password' && $method === 'POST') {
        $data = input();
        if (empty($data['email'])) respond(400, ['error' => 'Email is required']);
        botScreenOrFakeSuccess($pdo, $config, $data, 'password-reset', [
            'message' => 'If the email exists, a reset link has been queued.',
        ], 0);   // honeypot only - one field, often autofilled

        // Every request here sends mail, so each one consumes budget whether or not the
        // address exists - this endpoint is the classic way to mailbomb someone, and the
        // reply is deliberately identical either way so it cannot be used to test emails.
        throttleCheck($pdo, $config, 'password-reset', (string)$data['email']);
        throttleFailure($pdo, $config, 'password-reset', (string)$data['email']);
        // Trimmed: a phone keyboard or autofill often adds a trailing space, and an address
        // that matches nothing gets the same "queued" reply as one that does - so the reset
        // simply never came, with nothing to say why.
        $resetEmail = trim((string)$data['email']);
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$resetEmail]);
        $user = $stmt->fetch();
        if ($user) {
            $resetToken = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600);
            $pdo->prepare('UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?')->execute([$resetToken, $expires, (int)$user['id']]);
            $baseUrl = rtrim((string)($config['portal_base_url'] ?? ''), '/');
            if ($baseUrl !== '') {
                $resetUrl = $baseUrl . '/forgot-password?token=' . rawurlencode($resetToken);
                requireModule('sendPasswordResetEmail', 'lib/portal-mail.php');
                $mailError = null;
                if (!sendPasswordResetEmail($config, $resetEmail, $resetUrl, $mailError)) {
                    // The visitor still gets the neutral reply - it must not reveal whether
                    // the address has an account - so the failure is recorded where an admin
                    // will see it: the security log, shown on the Security page.
                    error_log('Password reset email could not be sent: ' . $mailError);
                    securityLog($pdo, $config, 'password_reset_mail_failed', 'warning', 'password-reset',
                        substr('Reset email not sent: ' . (string)$mailError, 0, 300), (int)$user['id']);
                }
            } else {
                error_log('Password reset token generated, but portal_base_url is not configured.');
                securityLog($pdo, $config, 'password_reset_mail_failed', 'warning', 'password-reset',
                    'Reset email not sent: portal_base_url is not configured', (int)$user['id']);
            }
        }
        securityLog($pdo, $config, 'password_reset_requested', 'info', 'password-reset');
        respond(200, ['message' => 'If the email exists, a reset link has been queued.']);
    }

    if ($route === 'auth/reset-password' && $method === 'POST') {
        $data = input();
        if (empty($data['token']) || empty($data['password'])) respond(400, ['error' => 'Token and password are required']);
        if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{8,64}$/', $data['password'])) respond(400, ['error' => 'Password must be 8-64 characters and include uppercase, lowercase, and a number']);
        $stmt = $pdo->prepare('SELECT id, email, role FROM users WHERE reset_token = ? AND reset_expires > NOW() LIMIT 1');
        $stmt->execute([$data['token']]);
        $user = $stmt->fetch();
        if (!$user) respond(400, ['error' => 'Invalid or expired reset link']);
        // Staff and admin accounts need a longer password that is not in a public breach list.
        if (function_exists('geoStaffPasswordProblem')
            && ($problem = geoStaffPasswordProblem($pdo, (int)$user['id'], (string)$user['role'], (string)$user['email'], (string)$data['password'])) !== null) {
            respond(400, ['error' => $problem]);
        }
        // Completing a reset marks the address verified, because completing a reset is
        // exactly what verification tests: the link went to that mailbox and somebody who
        // could open it came back with the token. Without this the endpoint ends by saying
        // "you can now log in" to accounts that login then refuses for being unverified -
        // which is every account created for an existing member rather than by someone
        // signing up, since only the sign-up flow sends a verification mail.
        $pdo->prepare('UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL,
                       email_verified = 1 WHERE id = ?')
            ->execute([password_hash($data['password'], PASSWORD_DEFAULT), (int)$user['id']]);
        // A reset proves the mailbox, so it also lifts a three-wrong-passwords lock.
        if (function_exists('geoLockClear')) geoLockClear($pdo, (int)$user['id']);
        // Whoever knew the old password may already hold a session. A reset ends all of them.
        if (sessionRevokeAll($pdo, (int)$user['id'])) {
            securityLog($pdo, $config, 'sessions_revoked', 'info', 'password-reset', 'All sessions ended by a password reset', (int)$user['id']);
        }
        respond(200, ['message' => 'Password updated. You can now log in.']);
    }

    // A staff member refused for where they are asks for an exception (lib/staff-geo.php).
    if ($route === 'auth/geo-request' && $method === 'POST' && function_exists('geoPublicRequest')) {
        throttleCheck($pdo, $config, 'password-reset', 'geo-request');
        geoPublicRequest($pdo, $config);
    }

    // A super administrator seeing the portal as one member (lib/view-as.php).
    if (strncmp($route, 'view-as/', 8) === 0 && function_exists('viewAsHandle')) {
        viewAsHandle($pdo, $config, $route, $method);
    }

    if ($route === 'members/me') {
        $user = auth($config);
        if ($method === 'GET') respond(200, mapMember(memberRow($pdo, (int)$user['userId'])) ?? []);
        if ($method === 'PATCH') {
            $data = input();
            $allowed = ['title' => 'title', 'firstName' => 'first_name', 'middleName' => 'middle_name', 'surname' => 'surname', 'country' => 'country', 'county' => 'county', 'division' => 'division', 'profession' => 'profession', 'specialization' => 'specialization', 'institution' => 'institution', 'physicalAddress' => 'physical_address', 'payerType' => 'payer_type', 'category' => 'category', 'idType' => 'id_type', 'idNumber' => 'id_number', 'mobile' => 'mobile'];
            $sets = [];
            $values = [];
            foreach ($allowed as $key => $column) {
                if (array_key_exists($key, $data)) {
                    $sets[] = "$column = ?";
                    // The ID number is encrypted at rest, so an edit must be written
                    // in the same form or the column would end up half plaintext.
                    $values[] = $column === 'id_number'
                        ? cryptoEncrypt($config, (string)($data[$key] ?: ''))
                        : ($data[$key] ?: null);
                }
            }
            if (!$sets) respond(400, ['error' => 'No profile fields provided']);
            $values[] = (int)$user['userId'];
            $pdo->prepare('UPDATE member_profiles SET ' . implode(', ', $sets) . ' WHERE user_id = ?')->execute($values);
            if (function_exists('viewAsLogEdit')) viewAsLogEdit($pdo, $user, 'Profile edited for the member: ' . implode(', ', array_keys(array_intersect_key($allowed, $data))));
            respond(200, mapMember(memberRow($pdo, (int)$user['userId'])) ?? []);
        }
    }

    /**
     * The public listing. No login - this is what the marketing site renders, and the whole
     * point is that a doctor who is not yet a member can find a CME and come to it.
     *
     * Returns upcoming by default; ?include=past adds the finished ones for an archive view.
     */
    // ----- Database schema ----------------------------------------------------------------

    /**
     * What has been applied and what has not. Super administrator only: this reveals the
     * shape of the database, and it is the screen that can change it.
     */
    if ($route === 'admin/migrations' && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('migrateStatus', 'lib/migrate.php');
        respond(200, ['migrations' => migrateStatus($pdo)]);
    }

    /**
     * Applies one file by name, or every pending schema file when none is named.
     *
     * The filename is checked against the directory listing rather than trusted, so this
     * cannot be pointed at anything that is not already one of these files. Nothing about
     * the SQL itself comes from the request.
     */
    if ($route === 'admin/migrations' && $method === 'POST') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('migrateApply', 'lib/migrate.php');

        $file = trim((string)(input()['file'] ?? ''));
        $results = $file !== ''
            ? [migrateApply($pdo, $file, (int)$user['userId'])]
            : migrateApplyPending($pdo, (int)$user['userId']);

        $failed = array_values(array_filter($results, fn($r) => $r['errors'] !== []));
        $applied = count($results) - count($failed);

        logAdminAction($pdo, (int)$user['userId'], 'schema_applied', null,
                       $applied . ' file(s), ' . count($failed) . ' with errors');
        securityLog($pdo, $config, 'schema_applied', 'warning', 'admin',
                    $applied . ' file(s)', (int)$user['userId']);

        respond($failed ? 207 : 200, [
            'results'   => $results,
            'applied'   => $applied,
            'failed'    => count($failed),
            'migrations'=> migrateStatus($pdo),
        ]);
    }

    // ----- ICT: helpdesk ---------------------------------------------------------------------

    /**
     * Raising a ticket needs no ICT permission at all - anyone signed in can report a
     * problem. That is the whole point: a helpdesk harder to use than a WhatsApp message
     * gets a WhatsApp message instead, and then shows an empty queue while the real requests
     * arrive somewhere nobody can measure.
     */
    if ($route === 'ict/tickets' && $method === 'POST') {
        $user = auth($config);
        requireModule('ictTicketCreate', 'lib/ict-tickets.php');

        // Rate limited on the same machinery as everything else, so a script cannot flood
        // the queue - but generously, because a bad morning genuinely produces three tickets.
        throttleCheck($pdo, $config, 'ticket', (string)($user['email'] ?? ''));

        [$ticket, $errors] = ictTicketCreate($pdo, input(), $user);
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? reset($errors), 'fields' => $errors]);
        }
        throttleSuccess($pdo, $config, 'ticket', (string)($user['email'] ?? ''));
        ictAudit($pdo, (int)$user['userId'], 'ticket_raised', 'ticket', (string)$ticket['id'],
                 $ticket['reference'] . ': ' . $ticket['subject']);
        respond(201, ['ticket' => $ticket]);
    }

    /** Who a ticket can be assigned to. Declared before the numeric route below, because
     *  "assignees" would otherwise be read as a ticket id. */
    if ($route === 'ict/tickets/assignees' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictTicketsList', 'lib/ict-tickets.php');
        ictRequire($pdo, $user, $config, 'tickets.manage');

        $rows = $pdo->query("SELECT u.id, u.email FROM users u
                              WHERE u.role IN ('ict','admin')
                                 OR u.id IN (SELECT user_id FROM ict_capabilities
                                              WHERE capability = 'tickets.manage')
                              ORDER BY u.email")->fetchAll();
        respond(200, ['assignees' => array_map(fn($r) => [
            'id' => (int)$r['id'], 'email' => $r['email'],
        ], $rows)]);
    }

    /**
     * The queue for ICT staff, or your own tickets if you are not one. Both are the same
     * route deliberately - a member should not have to know a different address to see what
     * they reported.
     */
    if ($route === 'ict/tickets' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictTicketsList', 'lib/ict-tickets.php');

        $isStaff = ictCan($pdo, $user, $config, 'tickets.view');
        $filters = [
            'status' => (string)($_GET['status'] ?? ''),
            'search' => trim((string)($_GET['search'] ?? '')),
        ];
        // ?reported=1: only what this person reported, even for ICT staff who see every
        // ticket - the staff portal's "What you have reported" means exactly that.
        if (!$isStaff || !empty($_GET['reported'])) {
            $filters['requester'] = (int)$user['userId'];
        } elseif (!empty($_GET['mine'])) {
            $filters['assignee'] = (int)$user['userId'];
        }

        respond(200, [
            'tickets'    => ictTicketsList($pdo, $filters),
            'summary'    => $isStaff ? ictTicketsSummary($pdo) : null,
            'isStaff'    => $isStaff,
            'categories' => ICT_TICKET_CATEGORIES,
            'priorities' => ICT_TICKET_PRIORITIES,
            'statuses'   => ICT_TICKET_STATUSES,
        ]);
    }

    if (preg_match('#^ict/tickets/(\d+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('ictTicketFind', 'lib/ict-tickets.php');

        $isStaff = ictCan($pdo, $user, $config, 'tickets.view');
        $ticket = ictTicketFind($pdo, (int)$m[1], $isStaff);
        if (!$ticket) respond(404, ['error' => 'No such ticket.']);

        // Someone who is neither staff nor the person who raised it has no business reading
        // it - a ticket can describe an account problem or a security incident.
        if (!$isStaff && $ticket['requesterEmail'] !== null
            && strcasecmp($ticket['requesterEmail'], (string)$user['email']) !== 0) {
            respond(403, ['error' => 'That ticket is not yours.']);
        }
        respond(200, ['ticket' => $ticket, 'isStaff' => $isStaff]);
    }

    /**
     * Working a ticket. Staff may change anything; the requester may only add a comment,
     * because chasing your own ticket is legitimate and raising its priority is not.
     */
    if (preg_match('#^ict/tickets/(\d+)$#', $route, $m) && in_array($method, ['PATCH', 'PUT'], true)) {
        $user = auth($config);
        requireModule('ictTicketUpdate', 'lib/ict-tickets.php');

        $existing = ictTicketFind($pdo, (int)$m[1]);
        if (!$existing) respond(404, ['error' => 'No such ticket.']);

        $data = input();
        if (!ictCan($pdo, $user, $config, 'tickets.manage')) {
            $isOwner = $existing['requesterEmail'] !== null
                && strcasecmp($existing['requesterEmail'], (string)$user['email']) === 0;
            if (!$isOwner) {
                respond(403, ['error' => 'You do not have the ICT permission needed for this.',
                              'capability' => 'tickets.manage']);
            }
            // Everything except a comment is dropped rather than refused, so adding a note
            // still works and nothing silently takes effect that should not.
            $data = ['comment' => (string)($data['comment'] ?? '')];
            if (trim($data['comment']) === '') {
                respond(400, ['error' => 'Add a comment to update your ticket.']);
            }
        }

        [$ticket, $error] = ictTicketUpdate($pdo, (int)$m[1], $data, $user);
        if ($error) respond(400, ['error' => $error]);
        ictAudit($pdo, (int)$user['userId'], 'ticket_updated', 'ticket', (string)$ticket['id'],
                 $ticket['reference'] . ': ' . $ticket['status']);
        // The person who reported it hears about changes made by someone else.
        if (function_exists('staffNotifyByEmail') && strcasecmp((string)($ticket['requesterEmail'] ?? ''), (string)($user['email'] ?? '')) !== 0) {
            staffNotifyByEmail($pdo, $ticket['requesterEmail'] ?? null, 'ticket',
                'Your ICT ticket ' . $ticket['reference'] . ' was updated: ' . str_replace('_', ' ', (string)$ticket['status']), 'staff#helpdesk');
        }
        respond(200, ['ticket' => $ticket]);
    }

    // ----- ICT: software and licences --------------------------------------------------------

    if ($route === 'ict/licenses' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictLicensesList', 'lib/ict-licenses.php');
        ictRequire($pdo, $user, $config, 'licenses.view');
        respond(200, [
            'licenses' => ictLicensesList($pdo),
            'summary'  => ictLicensesSummary($pdo),
            'kinds'    => ICT_LICENSE_KINDS,
        ]);
    }

    if ($route === 'ict/licenses' && $method === 'POST') {
        $user = auth($config);
        requireModule('ictLicenseCreate', 'lib/ict-licenses.php');
        ictRequire($pdo, $user, $config, 'licenses.manage');

        [$licence, $errors] = ictLicenseCreate($pdo, input(), (int)$user['userId']);
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        ictAudit($pdo, (int)$user['userId'], 'license_added', 'license', (string)$licence['id'],
                 $licence['name'], null, ['name' => $licence['name'], 'seats' => $licence['seatsTotal']]);
        respond(201, ['license' => $licence]);
    }

    if (preg_match('#^ict/licenses/(\d+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('ictLicenseFind', 'lib/ict-licenses.php');
        ictRequire($pdo, $user, $config, 'licenses.view');
        $licence = ictLicenseFind($pdo, (int)$m[1]);
        if (!$licence) respond(404, ['error' => 'No such licence.']);
        respond(200, ['license' => $licence]);
    }

    if (preg_match('#^ict/licenses/(\d+)$#', $route, $m) && in_array($method, ['PATCH', 'PUT'], true)) {
        $user = auth($config);
        requireModule('ictLicenseUpdate', 'lib/ict-licenses.php');
        ictRequire($pdo, $user, $config, 'licenses.manage');

        editConflictGuard($pdo, 'ict_licenses', (int)$m[1], input());
        [$licence, $errors, $before] = ictLicenseUpdate($pdo, (int)$m[1], input());
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        [$was, $now] = ictDiff($before ?: [], $licence);
        $flat = fn(array $a) => array_filter($a, fn($v) => !is_array($v));
        ictAudit($pdo, (int)$user['userId'], 'license_updated', 'license', (string)$licence['id'],
                 $licence['name'], $flat($was), $flat($now));
        respond(200, ['license' => $licence]);
    }

    if (preg_match('#^ict/licenses/(\d+)/seats$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('ictLicenseAssignSeat', 'lib/ict-licenses.php');
        ictRequire($pdo, $user, $config, 'licenses.manage');

        [$licence, $error] = ictLicenseAssignSeat($pdo, (int)$m[1], input(), (int)$user['userId']);
        if ($error) respond(400, ['error' => $error]);
        ictAudit($pdo, (int)$user['userId'], 'license_seat_assigned', 'license', (string)$licence['id'],
                 $licence['name'] . ': ' . $licence['seatsUsed'] . ' of ' . ($licence['seatsTotal'] ?: 'unlimited'));
        respond(200, ['license' => $licence]);
    }

    if (preg_match('#^ict/licenses/seats/(\d+)$#', $route, $m) && $method === 'DELETE') {
        $user = auth($config);
        requireModule('ictLicenseReleaseSeat', 'lib/ict-licenses.php');
        ictRequire($pdo, $user, $config, 'licenses.manage');

        [$licence, $error] = ictLicenseReleaseSeat($pdo, (int)$m[1], (int)$user['userId']);
        if ($error) respond(400, ['error' => $error]);
        ictAudit($pdo, (int)$user['userId'], 'license_seat_released', 'license', (string)$licence['id'],
                 $licence['name'] . ': ' . $licence['seatsUsed'] . ' now in use');
        respond(200, ['license' => $licence]);
    }

    // ----- ICT: credential register ---------------------------------------------------------

    if ($route === 'ict/credentials' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictCredentialsList', 'lib/ict-credentials.php');
        ictRequire($pdo, $user, $config, 'credentials.view');
        respond(200, [
            'credentials' => ictCredentialsList($pdo),
            'summary'     => ictCredentialsSummary($pdo),
            'kinds'       => ICT_CREDENTIAL_KINDS,
        ]);
    }

    if ($route === 'ict/credentials' && $method === 'POST') {
        $user = auth($config);
        requireModule('ictCredentialCreate', 'lib/ict-credentials.php');
        ictRequire($pdo, $user, $config, 'credentials.manage');

        [$credential, $errors] = ictCredentialCreate($pdo, input(), (int)$user['userId']);
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        ictAudit($pdo, (int)$user['userId'], 'credential_added', 'credential', (string)$credential['id'],
                 $credential['name'], null, ['name' => $credential['name'], 'kind' => $credential['kind']]);
        respond(201, ['credential' => $credential]);
    }

    if (preg_match('#^ict/credentials/(\d+)$#', $route, $m) && in_array($method, ['PATCH', 'PUT'], true)) {
        $user = auth($config);
        requireModule('ictCredentialUpdate', 'lib/ict-credentials.php');
        ictRequire($pdo, $user, $config, 'credentials.manage');

        editConflictGuard($pdo, 'ict_credentials', (int)$m[1], input());
        [$credential, $errors, $before] = ictCredentialUpdate($pdo, (int)$m[1], input());
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        [$was, $now] = ictDiff($before ?: [], $credential);
        $flat = fn(array $a) => array_filter($a, fn($v) => !is_array($v));
        ictAudit($pdo, (int)$user['userId'], 'credential_updated', 'credential', (string)$credential['id'],
                 $credential['name'], $flat($was), $flat($now));
        respond(200, ['credential' => $credential]);
    }

    /**
     * Records that someone went to collect a credential and returns where it is kept.
     *
     * Reading the register is not sensitive - it holds nothing secret. Following the link to
     * the password manager is, so that is what gets logged.
     */
    if (preg_match('#^ict/credentials/(\d+)/open$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('ictCredentialOpen', 'lib/ict-credentials.php');
        ictRequire($pdo, $user, $config, 'credentials.view');

        [$where, $error] = ictCredentialOpen($pdo, (int)$m[1], (int)$user['userId'],
                                             (string)(input()['reason'] ?? ''));
        if ($error) respond(404, ['error' => $error]);
        securityLog($pdo, $config, 'credential_opened', 'warning', 'ict',
                    $where['name'], (int)$user['userId']);
        respond(200, $where);
    }

    if ($route === 'ict/credentials/access-log' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictCredentialAccessLog', 'lib/ict-credentials.php');
        ictRequire($pdo, $user, $config, 'credentials.manage');
        respond(200, ['entries' => ictCredentialAccessLog($pdo, null, 60)]);
    }

    // ----- Elections: members --------------------------------------------------------------

    /**
     * Elections a member can see, or with ?electorate=staff the staff welfare elections - for
     * staff and super admins only. Drafts are never listed.
     */
    if ($route === 'elections' && $method === 'GET') {
        $user = auth($config);
        requireModule('electionsList', 'lib/elections.php');
        if (($_GET['electorate'] ?? '') === 'staff') {
            if (!electionStaffMayView($pdo, $config, $user)) respond(403, ['error' => 'Welfare elections are for ReSoK staff.']);
            respond(200, ['elections' => array_values(array_filter(electionsList($pdo, false, 'staff'), fn($e) => electionVisibleTo($pdo, $config, $e, $user)))]);
        }
        respond(200, ['elections' => electionsList($pdo, false, 'members')]);
    }

    /**
     * One election with its posts and candidates.
     *
     * Withdrawn candidates are visible here with their status, because a member looking at
     * the election should be able to see that somebody stood down rather than wonder why a
     * name they remember is missing.
     */
    if (preg_match('#^elections/([A-Za-z0-9-]+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('electionFind', 'lib/elections.php');
        $election = electionFind($pdo, $m[1]);
        if (!$election || $election['status'] === 'draft' || !electionVisibleTo($pdo, $config, $election, $user)) respond(404, ['error' => 'No such election.']);
        respond(200, electionForVoters($election, [
            'election'  => $election,
            'positions' => electionPositions($pdo, (int)$election['id']),
            'voter'     => electionRollEntry($pdo, (int)$election['id'], (int)$user['userId']),
            'results'   => $election['status'] === 'published'
                ? electionResults($pdo, (int)$election['id']) : null,
        ]));
    }

    /** The ballot paper, for a voter on the roll. */
    if (preg_match('#^elections/([A-Za-z0-9-]+)/ballot$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('electionBallotFor', 'lib/elections.php');
        [$ballot, $error] = electionBallotFor($pdo, $m[1], (int)$user['userId']);
        if ($error) respond(403, ['error' => $error]);
        respond(200, electionForVoters($ballot['election'], $ballot));
    }

    /**
     * Casting a vote.
     *
     * Deliberately not rate limited. throttleCheck only blocks once a lockout has been
     * recorded, and lockouts come from throttleFailure - which voting would never call,
     * because there is no such thing as a failed vote. The call would imply a protection it
     * does not provide, while leaving a client-scoped counter that could one day lock out
     * everyone voting from a single hospital's network.
     *
     * What actually prevents a second ballot is the SELECT ... FOR UPDATE on the roll row
     * inside electionCastVote, and the unique key behind it. Double voting is a database
     * error, not something a counter is asked to notice.
     */
    if (preg_match('#^elections/([A-Za-z0-9-]+)/vote$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionCastVote', 'lib/elections.php');

        $data = input();
        $choices = is_array($data['choices'] ?? null) ? $data['choices'] : [];
        if (!$choices) respond(400, ['error' => 'No choices were submitted.']);

        [$receipt, $error] = electionCastVote($pdo, $m[1], (int)$user['userId'], $choices,
                                              throttleClientHash($config));
        if ($error) respond(400, ['error' => $error]);
        securityLog($pdo, $config, 'election_vote_cast', 'info', 'election',
                    'Ballot recorded', (int)$user['userId']);
        respond(200, $receipt);
    }

    // ----- Elections: nominations ----------------------------------------------------------

    /**
     * The nomination form: who may be nominated, and for what.
     *
     * The list of nominatable members comes from the roll rather than the whole register.
     * Offering names that would be refused on submission is a form that lies about what it
     * will accept.
     */
    if (preg_match('#^elections/([A-Za-z0-9-]+)/nominations$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('electionNominations', 'lib/elections.php');
        $election = electionFind($pdo, $m[1]);
        if (!$election || $election['status'] === 'draft' || !electionVisibleTo($pdo, $config, $election, $user)) respond(404, ['error' => 'No such election.']);

        $entry = electionRollEntry($pdo, (int)$election['id'], (int)$user['userId']);
        respond(200, electionForVoters($election, [
            'election'    => $election,
            'positions'   => electionPositions($pdo, (int)$election['id']),
            'canNominate' => $entry !== null && $election['nominationsOpen'],
            'members'     => $entry ? electionNominatableMembers($pdo, (int)$election['id']) : [],
            'nominations' => electionNominations($pdo, (int)$election['id'], (int)$user['userId']),
        ]));
    }

    if (preg_match('#^elections/([A-Za-z0-9-]+)/nominate$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionNominate', 'lib/elections.php');
        [$result, $error] = electionNominate($pdo, $m[1], (int)$user['userId'], input());
        if ($error) respond(400, ['error' => $error]);
        respond(200, $result);
    }

    /** A nominee accepting or declining a nomination somebody else made for them. */
    if (preg_match('#^elections/nominations/(\d+)/(accept|decline)$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionRespondToNomination', 'lib/elections.php');
        [$result, $error] = electionRespondToNomination($pdo, (int)$m[1], (int)$user['userId'],
                                                        $m[2] === 'accept');
        if ($error) respond(400, ['error' => $error]);
        respond(200, $result);
    }

    /** Every nomination for an election, for the officer reviewing them. */
    if (preg_match('#^admin/elections/(\d+)/nominations$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('electionNominations', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        respond(200, ['nominations' => electionNominations($pdo, (int)$m[1])]);
    }

    // ----- Elections: returning officer ----------------------------------------------------

    if ($route === 'admin/elections' && $method === 'GET') {
        $user = auth($config);
        requireModule('electionsList', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        respond(200, ['elections' => electionsList($pdo, true)]);
    }

    if ($route === 'admin/elections' && $method === 'POST') {
        $user = auth($config);
        requireModule('electionCreate', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        [$election, $error] = electionCreate($pdo, input(), (int)$user['userId']);
        if ($error) respond(400, ['error' => $error]);
        logAdminAction($pdo, (int)$user['userId'], 'election_created', null, $election['title']);
        respond(201, ['election' => $election]);
    }

    if (preg_match('#^admin/elections/(\d+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('electionFind', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        $election = electionFind($pdo, $m[1]);
        if (!$election) respond(404, ['error' => 'No such election.']);
        respond(200, [
            'election'  => $election,
            'positions' => electionPositions($pdo, (int)$m[1]),
            'roll'      => electionRollSummary($pdo, (int)$m[1]),
        ]);
    }

    if (preg_match('#^admin/elections/(\d+)$#', $route, $m)
        && in_array($method, ['PATCH', 'PUT'], true)) {
        $user = auth($config);
        requireModule('electionUpdate', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        [$election, $error] = electionUpdate($pdo, (int)$m[1], input());
        if ($error) respond(400, ['error' => $error]);
        logAdminAction($pdo, (int)$user['userId'], 'election_updated', null, $election['title']);
        respond(200, ['election' => $election]);
    }

    if (preg_match('#^admin/elections/(\d+)/positions$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionPositionSave', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        $data = input();
        [$positions, $error] = electionPositionSave($pdo, (int)$m[1], $data,
                                                    isset($data['id']) ? (int)$data['id'] : null);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['positions' => $positions]);
    }

    if (preg_match('#^admin/elections/positions/(\d+)/candidates$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionCandidateSave', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        $data = input();
        [$positions, $error] = electionCandidateSave($pdo, (int)$m[1], $data,
                                                     isset($data['id']) ? (int)$data['id'] : null);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['positions' => $positions]);
    }

    /**
     * Drawing the roll. The eligibility year is passed explicitly rather than inferred, so
     * the rule that produced a roll is a decision somebody made and can be seen to have made.
     */
    if (preg_match('#^admin/elections/(\d+)/roll$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionDrawRoll', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        $target = electionFind($pdo, $m[1]);
        $isStaffElection = $target && $target['electorate'] === 'staff';
        $year = (int)(input()['paidYear'] ?? 0);
        // A staff roll is the active staff list; only a members' roll is judged on a paid year.
        if (!$isStaffElection && ($year < 2000 || $year > 2100)) respond(400, ['error' => 'Give the year membership must be paid for.']);
        [$summary, $error] = electionDrawRoll($pdo, (int)$m[1], $year);
        if ($error) respond(400, ['error' => $error]);
        logAdminAction($pdo, (int)$user['userId'], 'election_roll_drawn', null,
                       'Election ' . $m[1] . ': ' . $summary['onRoll'] . ' voters, ' . ($isStaffElection ? 'active staff' : 'paid ' . $year));
        respond(200, ['roll' => $summary]);
    }

    if (preg_match('#^admin/elections/(position|candidate)/(\d+)$#', $route, $m) && $method === 'DELETE') {
        $user = auth($config);
        requireModule('electionDelete', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        [$positions, $error] = electionDelete($pdo, $m[1], (int)$m[2]);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['positions' => $positions]);
    }

    /** Recording that somebody outside the membership has agreed to stand. */
    if (preg_match('#^admin/elections/nominations/(\d+)/accepted$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionRecordExternalAcceptance', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        [$nominations, $error] = electionRecordExternalAcceptance(
            $pdo, (int)$m[1], (int)$user['userId'], (string)(input()['note'] ?? ''));
        if ($error) respond(400, ['error' => $error]);
        logAdminAction($pdo, (int)$user['userId'], 'election_external_acceptance', null,
                       'Candidate ' . $m[1]);
        respond(200, ['nominations' => $nominations]);
    }

    /** Every member, with whether they are on the roll and whether they could actually vote. */
    if (preg_match('#^admin/elections/(\d+)/roll/members$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('electionRollCandidates', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        respond(200, ['members' => electionRollCandidates($pdo, (int)$m[1])]);
    }

    /**
     * Adding or removing one voter by hand.
     *
     * The reason is required and goes to the admin log, because a roll corrected by hand can
     * only be defended if the corrections can be named.
     */
    if (preg_match('#^admin/elections/(\d+)/roll/(add|remove)$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionRollAdd', 'lib/elections.php');
        requireSuperAdmin($user, $config);

        $data = input();
        $memberId = (int)($data['memberProfileId'] ?? 0);
        $reason = (string)($data['reason'] ?? '');
        [$result, $error] = $m[2] === 'add'
            ? electionRollAdd($pdo, (int)$m[1], $memberId, $reason)
            : electionRollRemove($pdo, (int)$m[1], $memberId, $reason);
        if ($error) respond(400, ['error' => $error]);

        logAdminAction($pdo, (int)$user['userId'], 'election_roll_' . $m[2], $memberId,
                       'Election ' . $m[1] . ': ' . $result['name'] . ' - ' . trim($reason));
        respond(200, ['roll' => electionRollSummary($pdo, (int)$m[1])] + $result);
    }

    if (preg_match('#^admin/elections/(\d+)/randomise$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionRandomiseBallot', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        [$positions, $error] = electionRandomiseBallot($pdo, (int)$m[1]);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['positions' => $positions]);
    }

    if (preg_match('#^admin/elections/(\d+)/status$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionSetStatus', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        [$election, $error] = electionSetStatus($pdo, (int)$m[1], (string)(input()['status'] ?? ''));
        if ($error) respond(400, ['error' => $error]);
        logAdminAction($pdo, (int)$user['userId'], 'election_' . $election['status'], null,
                       $election['title']);
        respond(200, ['election' => $election]);
    }

    /**
     * The count.
     *
     * Logged on every read. ReSoK's ballot is recorded rather than secret, which means
     * somebody can see how the vote went before it is declared - so the question "who looked,
     * and when" needs an answer that does not depend on anybody's memory.
     */
    if (preg_match('#^admin/elections/(\d+)/tally$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('electionTally', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        [$tally, $error] = electionTally($pdo, (int)$m[1], true);
        if ($error) respond(400, ['error' => $error]);
        securityLog($pdo, $config, 'election_tally_viewed', 'warning', 'election',
                    'Count read for election ' . $m[1], (int)$user['userId']);
        respond(200, $tally);
    }

    if (preg_match('#^admin/elections/(\d+)/declare$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('electionDeclareResult', 'lib/elections.php');
        requireSuperAdmin($user, $config);
        $note = trim((string)(input()['note'] ?? '')) ?: null;
        [$results, $error] = electionDeclareResult($pdo, (int)$m[1], (int)$user['userId'], $note);
        if ($error) respond(400, ['error' => $error]);
        logAdminAction($pdo, (int)$user['userId'], 'election_result_declared', null,
                       'Election ' . $m[1] . ', declaration ' . $results['declaration']);
        respond(200, ['results' => $results]);
    }

    // ----- ReSoK Virtual Academy: catalogue ------------------------------------------------

    /**
     * The public catalogue. No auth() call on purpose: a course platform you cannot look at
     * before signing up is a brochure, and the whole point of the Alison model is that
     * browsing is free and only progress needs an account.
     */
    if ($route === 'academy/courses' && $method === 'GET') {
        requireModule('academyCourseList', 'lib/academy.php');
        respond(200, [
            'courses'    => academyCourseList($pdo, [
                'q'        => (string)($_GET['q'] ?? ''),
                'category' => (string)($_GET['category'] ?? ''),
                'level'    => (string)($_GET['level'] ?? ''),
            ]),
            'categories' => academyCategories($pdo),
            'levels'     => ACADEMY_LEVELS,
        ]);
    }

    /**
     * One course, by slug or id, with its contents page.
     *
     * Lesson bodies are not included - academyOutline returns titles and durations only, so
     * this is safe to serve to anyone. The material itself is what enrolment buys.
     */
    if (preg_match('#^academy/courses/([A-Za-z0-9-]+)$#', $route, $m) && $method === 'GET') {
        requireModule('academyCourseFind', 'lib/academy.php');
        $course = academyCourseFind($pdo, $m[1]);
        if (!$course) respond(404, ['error' => 'No published course at that address.']);

        // A signed-in visitor is told whether they are already enrolled, so the page can say
        // "continue" rather than offering to enrol them a second time.
        $enrolment = null;
        $viewer = authOptional($config);
        if ($viewer) $enrolment = academyEnrolment($pdo, (int)$viewer['userId'], (int)$course['id']);
        respond(200, ['course' => $course, 'enrolment' => $enrolment]);
    }

    // ----- ReSoK Virtual Academy: learning ------------------------------------------------

    if ($route === 'academy/my-courses' && $method === 'GET') {
        $user = auth($config);
        requireModule('academyMyCourses', 'lib/academy.php');
        respond(200, ['courses' => academyMyCourses($pdo, (int)$user['userId'])]);
    }

    if (preg_match('#^academy/courses/([A-Za-z0-9-]+)/enrol$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyEnrol', 'lib/academy.php');

        // Membership is read here rather than trusted from the token: a members-only course
        // has to check standing as it is now, not as it was when the session started.
        //
        // Standing rather than the status column, so a member inside their grace period
        // keeps access - being a fortnight late on a subscription is not the same as having
        // resigned - and one whose grace has run out loses it the day it runs out, without
        // waiting for a nightly job to write the word 'expired' somewhere.
        requireModule('membershipStandingForUser', 'lib/membership.php');
        $standing = membershipStandingForUser($pdo, (int)$user['userId']);

        [$enrolment, $error] = academyEnrol($pdo, (int)$user['userId'], $m[1],
                                            $standing['benefits'] ? 'active' : 'lapsed');
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['enrolment' => $enrolment]);
    }

    /** A lesson with its material. Refuses anyone who is not enrolled. */
    if (preg_match('#^academy/lessons/(\d+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('academyLesson', 'lib/academy.php');
        [$lesson, $error] = academyLesson($pdo, (int)$user['userId'], (int)$m[1]);
        if ($error) respond(403, ['error' => $error]);
        respond(200, ['lesson' => $lesson]);
    }

    if (preg_match('#^academy/lessons/(\d+)/progress$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyRecordProgress', 'lib/academy.php');
        [$enrolment, $error] = academyRecordProgress($pdo, (int)$user['userId'], (int)$m[1], input());
        if ($error) respond(403, ['error' => $error]);
        respond(200, ['enrolment' => $enrolment]);
    }

    // ----- ReSoK Virtual Academy: final assessments ---------------------------------------

    if (preg_match('#^academy/courses/([A-Za-z0-9-]+)/assessment$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('academyAssessmentStatus', 'lib/academy-assessments.php');
        $status = academyAssessmentStatus($pdo, (int)$user['userId'], $m[1]);
        if ($status === null) respond(404, ['error' => 'That course is not in the catalogue.']);
        respond(200, $status);
    }

    /** Opens an attempt, or the one already open. Questions and options only - never which is right. */
    if (preg_match('#^academy/courses/([A-Za-z0-9-]+)/assessment/start$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyAssessmentStart', 'lib/academy-assessments.php');
        [$paper, $error] = academyAssessmentStart($pdo, (int)$user['userId'], $m[1]);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['paper' => $paper]);
    }

    if (preg_match('#^academy/courses/([A-Za-z0-9-]+)/assessment/submit$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyAssessmentSubmit', 'lib/academy-assessments.php');
        $data = input();
        [$result, $error] = academyAssessmentSubmit($pdo, (int)$user['userId'], $m[1],
                                                    (int)($data['attemptId'] ?? 0), $data['answers'] ?? []);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['result' => $result]);
    }

    // ----- ReSoK Virtual Academy: certificates --------------------------------------------

    /** The learner's certificate for a course: the one issued, or what is still needed. */
    if (preg_match('#^academy/courses/([A-Za-z0-9-]+)/certificate$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('academyCertificateStatus', 'lib/academy-certificates.php');
        respond(200, academyCertificateStatus($pdo, (int)$user['userId'], $m[1]));
    }

    if (preg_match('#^academy/courses/([A-Za-z0-9-]+)/certificate$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyCertificateIssue', 'lib/academy-certificates.php');
        [$certificate, $error] = academyCertificateIssue($pdo, (int)$user['userId'], $m[1], (string)(input()['name'] ?? ''));
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['certificate' => $certificate]);
    }

    /** The PDF, for its owner only. Anyone else checks a certificate through its code. */
    if (preg_match('#^academy/courses/([A-Za-z0-9-]+)/certificate/pdf$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('academyCertificatePdf', 'lib/academy-certificates.php');
        [, $enrolment, ] = academyCertificateContext($pdo, (int)$user['userId'], $m[1]);
        $certificate = $enrolment ? academyCertificateForEnrolment($pdo, (int)$enrolment['id']) : null;
        if (!$certificate) respond(404, ['error' => 'No certificate has been issued for this course yet.']);
        if ($certificate['revoked']) respond(410, ['error' => 'This certificate has been revoked, so it can no longer be downloaded.']);

        $document = academyCertificatePdf($certificate);
        http_response_code(200);
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="ReSoK-certificate-' . $certificate['code'] . '.pdf"');
        header('Content-Length: ' . strlen($document));
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        echo $document;
        exit;
    }

    /**
     * Public verification. No auth() on purpose: the person checking is an employer or a
     * regulator, not the learner. Only a code that matches nothing counts against the rate
     * limit, so checking a pile of genuine certificates is never refused; working through
     * guesses is.
     */
    if (preg_match('#^certificates/verify/([A-Za-z0-9-]{1,40})$#', $route, $m) && $method === 'GET') {
        requireModule('academyCertificateVerify', 'lib/academy-certificates.php');
        throttleCheck($pdo, $config, 'certificate-verify', 'verify');
        $result = academyCertificateVerify($pdo, $m[1]);
        if ($result['status'] === 'not_found') throttleFailure($pdo, $config, 'certificate-verify', 'verify');
        respond(200, $result);
    }

    if ($route === 'academy/admin/certificates' && $method === 'GET') {
        $user = auth($config);
        requireModule('academyCertificateList', 'lib/academy-certificates.php');
        if (!academyCanPublish($user)) respond(403, ['error' => 'You do not have permission to manage certificates.']);
        respond(200, ['certificates' => academyCertificateList($pdo, (string)($_GET['q'] ?? ''))]);
    }

    if (preg_match('#^academy/admin/certificates/(\d+)/revoke$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyCertificateRevoke', 'lib/academy-certificates.php');
        if (!academyCanPublish($user)) respond(403, ['error' => 'You do not have permission to manage certificates.']);
        [$certificate, $error] = academyCertificateRevoke($pdo, (int)$m[1], (string)(input()['reason'] ?? ''));
        if ($error) respond(400, ['error' => $error]);
        logAdminAction($pdo, (int)$user['userId'], 'certificate_revoked', null, $certificate['code'] . ': ' . $certificate['revokedReason']);
        respond(200, ['certificate' => $certificate]);
    }

    // ----- ReSoK Virtual Academy: authoring ------------------------------------------------

    if ($route === 'academy/admin/courses' && $method === 'GET') {
        $user = auth($config);
        requireModule('academyCourseList', 'lib/academy.php');
        academyRequireEdit($user);
        respond(200, [
            'courses' => academyCourseList($pdo, ['status' => (string)($_GET['status'] ?? ''),
                                                  'q' => (string)($_GET['q'] ?? '')], true),
            'summary' => academySummary($pdo),
            'canPublish' => academyCanPublish($user),
        ]);
    }

    if ($route === 'academy/admin/courses' && $method === 'POST') {
        $user = auth($config);
        requireModule('academyCourseCreate', 'lib/academy.php');
        academyRequireEdit($user);
        [$course, $errors] = academyCourseCreate($pdo, input(), (int)$user['userId']);
        if ($errors) respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.',
                                   'fields' => $errors]);
        logAdminAction($pdo, (int)$user['userId'], 'academy_course_created', null,
                       'Course: ' . $course['title']);
        respond(201, ['course' => $course]);
    }

    /** One course including drafts - what the builder opens. */
    if (preg_match('#^academy/admin/courses/(\d+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('academyCourseFind', 'lib/academy.php');
        academyRequireEdit($user);
        $course = academyCourseFind($pdo, $m[1], true);
        if (!$course) respond(404, ['error' => 'No course with that id.']);
        respond(200, ['course' => $course]);
    }

    if (preg_match('#^academy/admin/courses/(\d+)$#', $route, $m)
        && in_array($method, ['PATCH', 'PUT'], true)) {
        $user = auth($config);
        requireModule('academyCourseUpdate', 'lib/academy.php');
        academyRequireEdit($user);
        [$course, $errors] = academyCourseUpdate($pdo, (int)$m[1], input());
        if ($errors) respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.',
                                   'fields' => $errors]);
        respond(200, ['course' => $course]);
    }

    /**
     * Publishing is a separate right from authoring, the same way it is for articles: an
     * author can build a course but not put it in front of the public.
     */
    if (preg_match('#^academy/admin/courses/(\d+)/status$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyCoursePublish', 'lib/academy.php');
        academyRequireEdit($user);
        if (!academyCanPublish($user)) {
            respond(403, ['error' => 'You can build courses, but publishing them is an editor\'s decision.']);
        }
        [$course, $error] = academyCoursePublish($pdo, (int)$m[1], (string)(input()['status'] ?? ''));
        if ($error) respond(400, ['error' => $error]);
        logAdminAction($pdo, (int)$user['userId'], 'academy_course_' . $course['status'], null,
                       'Course: ' . $course['title']);
        respond(200, ['course' => $course]);
    }

    if (preg_match('#^academy/admin/courses/(\d+)/modules$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyModuleSave', 'lib/academy.php');
        academyRequireEdit($user);
        $data = input();
        [$outline, $error] = academyModuleSave($pdo, (int)$m[1], $data,
                                               isset($data['id']) ? (int)$data['id'] : null);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['modules' => $outline]);
    }

    if (preg_match('#^academy/admin/modules/(\d+)/lessons$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyLessonSave', 'lib/academy.php');
        academyRequireEdit($user);
        $data = input();
        [$outline, $error] = academyLessonSave($pdo, (int)$m[1], $data,
                                               isset($data['id']) ? (int)$data['id'] : null);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['modules' => $outline]);
    }

    if (preg_match('#^academy/admin/(module|lesson)/(\d+)$#', $route, $m) && $method === 'DELETE') {
        $user = auth($config);
        requireModule('academyDelete', 'lib/academy.php');
        academyRequireEdit($user);
        [$outline, $error] = academyDelete($pdo, $m[1], (int)$m[2]);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['modules' => $outline]);
    }

    if (preg_match('#^academy/admin/(module|lesson)/reorder$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('academyReorder', 'lib/academy.php');
        academyRequireEdit($user);
        $data = input();
        [$outline, $error] = academyReorder($pdo, $m[1], (int)($data['parentId'] ?? 0),
                                            is_array($data['order'] ?? null) ? $data['order'] : []);
        if ($error) respond(400, ['error' => $error]);
        respond(200, ['modules' => $outline]);
    }

    // ----- ICT: assets --------------------------------------------------------------------

    if ($route === 'ict/assets' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictAssetsList', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.view');
        $assets = ictAssetsList($pdo, [
            'search'   => trim((string)($_GET['search'] ?? '')),
            'status'   => (string)($_GET['status'] ?? ''),
            'category' => (string)($_GET['category'] ?? ''),
        ]);
        // During a stock-take, each row says whether its sticker has been scanned yet.
        $stocktake = ictStocktakeCurrent($pdo);
        if ($stocktake) {
            $ticks = ictStocktakeTicks($pdo, $stocktake['id']);
            foreach ($assets as &$a) $a['verifiedAt'] = $ticks[$a['id']] ?? null;
            unset($a);
        }
        respond(200, [
            'assets'     => $assets,
            'summary'    => ictAssetsSummary($pdo),
            'categories' => ICT_ASSET_CATEGORIES,
            'stocktake'  => $stocktake,
        ]);
    }

    // ----- ICT: stock-take (lib/ict-assets.php explains it) ------------------------------

    if (strpos($route, 'ict/stocktake') === 0) {
        $user = auth($config);
        requireModule('ictStocktakeCurrent', 'lib/ict-assets.php');
        $userId = (int)$user['userId'];

        if ($route === 'ict/stocktake' && $method === 'GET') {
            ictRequire($pdo, $user, $config, 'assets.view');
            respond(200, ['current' => ictStocktakeCurrent($pdo), 'history' => ictStocktakeHistory($pdo)]);
        }
        if ($route === 'ict/stocktake' && $method === 'POST') {
            ictRequire($pdo, $user, $config, 'assets.manage');
            [$stocktake, $error] = ictStocktakeStart($pdo, (string)(input()['name'] ?? ''), $userId);
            if ($error) respond(400, ['error' => $error]);
            ictAudit($pdo, $userId, 'stocktake_started', 'stocktake', (string)$stocktake['id'], $stocktake['name']);
            respond(201, ['stocktake' => $stocktake]);
        }
        // A tick records that the sticker was seen; it changes nothing about the asset, so
        // anyone who can view the register can do the walking round.
        if ($route === 'ict/stocktake/verify' && $method === 'POST') {
            ictRequire($pdo, $user, $config, 'assets.view');
            $asset = ictAssetFind($pdo, (int)(input()['assetId'] ?? 0));
            if (!$asset) respond(404, ['error' => 'That asset is not on the register.']);
            $result = ictStocktakeVerify($pdo, (int)$asset['id'], $userId);
            if (!$result['stocktake']) respond(409, ['error' => 'No stock-take is open.']);
            respond(200, $result);
        }
        if ($route === 'ict/stocktake/unverify' && $method === 'POST') {
            ictRequire($pdo, $user, $config, 'assets.manage');
            $stocktake = ictStocktakeUnverify($pdo, (int)(input()['assetId'] ?? 0));
            if (!$stocktake) respond(409, ['error' => 'No stock-take is open.']);
            respond(200, ['stocktake' => $stocktake]);
        }
        if ($route === 'ict/stocktake/finish' && $method === 'POST') {
            ictRequire($pdo, $user, $config, 'assets.manage');
            [$report, $error] = ictStocktakeFinish($pdo, $userId);
            if ($error) respond(400, ['error' => $error]);
            ictAudit($pdo, $userId, 'stocktake_finished', 'stocktake', (string)$report['id'],
                     $report['name'] . ': ' . $report['seen'] . ' of ' . $report['expected'] . ' seen');
            respond(200, ['report' => $report]);
        }
        if (preg_match('#^ict/stocktake/(\d+)$#', $route, $m) && $method === 'GET') {
            ictRequire($pdo, $user, $config, 'assets.view');
            $report = ictStocktakeReport($pdo, (int)$m[1]);
            if (!$report) respond(404, ['error' => 'No such stock-take.']);
            respond(200, ['report' => $report]);
        }
        respond(404, ['error' => 'Route not found']);
    }

    if ($route === 'ict/assets' && $method === 'POST') {
        $user = auth($config);
        requireModule('ictAssetCreate', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.manage');

        [$asset, $errors] = ictAssetCreate($pdo, input(), (int)$user['userId']);
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        ictAudit($pdo, (int)$user['userId'], 'asset_added', 'asset', (string)$asset['id'],
                 $asset['assetTag'] . ' ' . $asset['name'], null,
                 ['assetTag' => $asset['assetTag'], 'name' => $asset['name']]);
        respond(201, ['asset' => $asset]);
    }

    /** Everything one person is holding - what to run before somebody leaves. */
    if ($route === 'ict/assets/held-by' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictAssetsHeldBy', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.view');
        respond(200, ['assets' => ictAssetsHeldBy($pdo, (string)($_GET['email'] ?? ''))]);
    }

    /**
     * One asset with its whole history. This is what a QR scan opens, so it accepts either
     * the numeric id or the tag printed on the sticker.
     */
    /*
     * The tag scanner: GET ict/assets/by-tag?tag=000009. Its own route, because the register's
     * tags are all digits and the route below reads an all-digit value as a row id. A 404
     * carries the cleaned tag back, so the page can offer to add it.
     */
    if ($route === 'ict/assets/by-tag' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictAssetFindByScan', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.view');

        $tag = preg_replace('/\s+/', '', trim((string)($_GET['tag'] ?? '')));
        if ($tag === '') respond(400, ['error' => 'Scan or type a tag number.']);
        $asset = ictAssetFindByScan($pdo, $tag);
        if (!$asset) respond(404, ['error' => 'That tag is not on the asset list yet.', 'tag' => mb_substr($tag, 0, 40)]);
        respond(200, ['asset' => $asset]);
    }

    if (preg_match('#^ict/assets/([A-Za-z0-9-]+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireModule('ictAssetFind', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.view');

        // A leading zero means a sticker number (000009), never a row id.
        $asset = ctype_digit($m[1]) && $m[1][0] !== '0'
            ? ictAssetFind($pdo, (int)$m[1])
            : ictAssetFindByTag($pdo, $m[1]);
        if (!$asset) respond(404, ['error' => 'No asset with that tag or id.']);
        respond(200, ['asset' => $asset]);
    }

    if (preg_match('#^ict/assets/(\d+)$#', $route, $m) && in_array($method, ['PATCH', 'PUT'], true)) {
        $user = auth($config);
        requireModule('ictAssetUpdate', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.manage');

        editConflictGuard($pdo, 'ict_assets', (int)$m[1], input());
        [$asset, $errors, $before] = ictAssetUpdate($pdo, (int)$m[1], input());
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        [$was, $now] = ictDiff($before ?: [], $asset);
        // Nested arrays are the holder and the history, not fields anyone edited here.
        $flat = fn(array $a) => array_filter($a, fn($v) => !is_array($v));
        ictAudit($pdo, (int)$user['userId'], 'asset_updated', 'asset', (string)$asset['id'],
                 $asset['assetTag'], $flat($was), $flat($now));
        respond(200, ['asset' => $asset]);
    }

    // ----- ICT: assignment ------------------------------------------------------------------

    if (preg_match('#^ict/assets/(\d+)/assign$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('ictAssetAssign', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.assign');

        [$asset, $error] = ictAssetAssign($pdo, (int)$m[1], input(), (int)$user['userId']);
        if ($error) respond(400, ['error' => $error]);
        ictAudit($pdo, (int)$user['userId'], 'asset_assigned', 'asset', (string)$asset['id'],
                 $asset['assetTag'] . ' to ' . $asset['holder']['name'],
                 null, ['holder' => $asset['holder']['name']]);
        if (function_exists('staffNotifyByEmail')) {
            staffNotifyByEmail($pdo, $asset['holder']['email'] ?? null, 'asset', 'Issued to you: ' . $asset['assetTag'] . ' ' . $asset['name'], 'staff#equipment');
        }
        respond(200, ['asset' => $asset]);
    }

    if (preg_match('#^ict/assets/(\d+)/return$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('ictAssetReturn', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.assign');

        $was = ictAssetFind($pdo, (int)$m[1]);
        [$asset, $error] = ictAssetReturn($pdo, (int)$m[1], input(), (int)$user['userId']);
        if ($error) respond(400, ['error' => $error]);
        if (function_exists('staffNotifyByEmail')) {
            staffNotifyByEmail($pdo, $was['holder']['email'] ?? null, 'asset', 'Returned and taken off your list: ' . $asset['assetTag'] . ' ' . $asset['name'], 'staff#equipment');
        }
        ictAudit($pdo, (int)$user['userId'], 'asset_returned', 'asset', (string)$asset['id'],
                 $asset['assetTag'] . ' from ' . ($was['holder']['name'] ?? 'unknown'),
                 ['condition' => $was['condition'] ?? null], ['condition' => $asset['condition']]);
        respond(200, ['asset' => $asset]);
    }

    // Change user: straight from one holder to the next, in one step.
    if (preg_match('#^ict/assets/(\d+)/transfer$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('ictAssetTransfer', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'assets.assign');

        $was = ictAssetFind($pdo, (int)$m[1]);
        [$asset, $error] = ictAssetTransfer($pdo, (int)$m[1], input(), (int)$user['userId']);
        if ($error) respond(400, ['error' => $error]);
        ictAudit($pdo, (int)$user['userId'], 'asset_transferred', 'asset', (string)$asset['id'],
                 $asset['assetTag'] . ' from ' . ($was['holder']['name'] ?? 'unknown') . ' to ' . $asset['holder']['name'],
                 ['holder' => $was['holder']['name'] ?? null], ['holder' => $asset['holder']['name']]);
        if (function_exists('staffNotifyByEmail')) {
            staffNotifyByEmail($pdo, $was['holder']['email'] ?? null, 'asset', 'Handed over to ' . $asset['holder']['name'] . ': ' . $asset['assetTag'] . ' ' . $asset['name'], 'staff#equipment');
            staffNotifyByEmail($pdo, $asset['holder']['email'] ?? null, 'asset', 'Issued to you: ' . $asset['assetTag'] . ' ' . $asset['name'], 'staff#equipment');
        }
        respond(200, ['asset' => $asset]);
    }

    // ----- ICT: maintenance -----------------------------------------------------------------

    if (preg_match('#^ict/assets/(\d+)/maintenance$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireModule('ictMaintenanceAdd', 'lib/ict-assets.php');
        ictRequire($pdo, $user, $config, 'maintenance.manage');

        [$asset, $error] = ictMaintenanceAdd($pdo, (int)$m[1], input(), (int)$user['userId']);
        if ($error) respond(400, ['error' => $error]);
        ictAudit($pdo, (int)$user['userId'], 'maintenance_recorded', 'asset', (string)$asset['id'],
                 $asset['assetTag'] . ': ' . ($asset['maintenance'][0]['kind'] ?? 'repair'));
        respond(201, ['asset' => $asset]);
    }

    // ----- ICT: digital infrastructure -----------------------------------------------------

    if ($route === 'ict/infrastructure' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictInfraAll', 'lib/ict-infrastructure.php');
        ictRequire($pdo, $user, $config, 'infrastructure.view');
        respond(200, [
            'items'   => ictInfraAll($pdo),
            'summary' => ictInfraSummary($pdo),
        ]);
    }

    if ($route === 'ict/infrastructure' && $method === 'POST') {
        $user = auth($config);
        requireModule('ictInfraCreate', 'lib/ict-infrastructure.php');
        ictRequire($pdo, $user, $config, 'infrastructure.manage');

        [$item, $errors] = ictInfraCreate($pdo, input());
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        ictAudit($pdo, (int)$user['userId'], 'infrastructure_added', 'infrastructure', (string)$item['id'],
                 $item['kind'] . ': ' . $item['name'], null, ['name' => $item['name'], 'expiresOn' => $item['expiresOn']]);
        respond(201, ['item' => $item]);
    }

    if (preg_match('#^ict/infrastructure/(\d+)$#', $route, $m) && in_array($method, ['PATCH', 'PUT'], true)) {
        $user = auth($config);
        requireModule('ictInfraUpdate', 'lib/ict-infrastructure.php');
        ictRequire($pdo, $user, $config, 'infrastructure.manage');

        editConflictGuard($pdo, 'ict_infrastructure', (int)$m[1], input());
        [$item, $errors, $before] = ictInfraUpdate($pdo, (int)$m[1], input());
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        // Only what actually changed goes into the log, so the entry answers "what did it say
        // before" without storing a copy of the whole record on every edit.
        [$was, $now] = ictDiff($before ?: [], $item);
        ictAudit($pdo, (int)$user['userId'], 'infrastructure_updated', 'infrastructure', (string)$item['id'],
                 $item['kind'] . ': ' . $item['name'], $was, $now);
        respond(200, ['item' => $item]);
    }

    /**
     * The ICT Overview.
     *
     * Assembled from whatever modules are actually deployed - each block is guarded, so this
     * keeps working as later phases land rather than needing a rewrite each time. The CPD
     * figures are read-only counts against the existing tables: no new storage, no duplicated
     * logic, and removing this block tomorrow would leave CPD untouched.
     */
    if ($route === 'ict/overview' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictCan', 'lib/ict.php');
        if (!ictHasAnyAccess($pdo, $user, $config)) {
            respond(403, ['error' => 'You do not have access to the ICT area.']);
        }

        $overview = ['generatedAt' => date('c')];

        if (ictCan($pdo, $user, $config, 'infrastructure.view') && function_exists('ictInfraSummary')) {
            $overview['infrastructure'] = ictInfraSummary($pdo);
        }

        // Read-only CPD visibility. The existing system stays the source of truth.
        if (ictCan($pdo, $user, $config, 'reports.view')) {
            try {
                $one = function (string $sql) use ($pdo): int {
                    return (int)($pdo->query($sql)->fetch()['c'] ?? 0);
                };
                $overview['cpd'] = [
                    'publishedEvents'  => $one("SELECT COUNT(*) c FROM cpd_events WHERE status = 'published'"),
                    'upcomingEvents'   => $one("SELECT COUNT(*) c FROM cpd_events WHERE status = 'published' AND COALESCE(ends_at, starts_at) >= NOW()"),
                    'tokensAwaiting'   => $one("SELECT COUNT(*) c FROM cpd_tokens WHERE status = 'assigned'"),
                    'tokensCollected'  => $one("SELECT COUNT(*) c FROM cpd_tokens WHERE status = 'collected'"),
                ];
            } catch (Throwable $e) {
                // CPD tables absent on this deployment. Not an ICT problem; the block is
                // simply omitted rather than failing the whole overview.
                $overview['cpd'] = null;
            }
        }

        if (ictCan($pdo, $user, $config, 'security.view')) {
            try {
                $stmt = $pdo->query("SELECT COUNT(*) c FROM security_events
                                     WHERE severity IN ('warning','critical') AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)");
                $locked = $pdo->query("SELECT COUNT(*) c FROM auth_attempts WHERE locked_until > NOW()");
                $overview['security'] = [
                    'recentAlerts'    => (int)($stmt->fetch()['c'] ?? 0),
                    'lockedOutNow'    => (int)($locked->fetch()['c'] ?? 0),
                ];
            } catch (Throwable $e) {
                $overview['security'] = null;
            }
        }

        if (ictCan($pdo, $user, $config, 'reports.view') && function_exists('ictAuditRecent')) {
            $overview['activity'] = ictAuditRecent($pdo, 12);
        }

        respond(200, $overview);
    }

    // ----- ICT: access and capabilities ---------------------------------------------------

    /**
     * What the signed-in user may do. The ICT page calls this on load to decide which
     * sections to show - so a section nobody can use is never rendered, rather than being
     * rendered and then failing on click.
     */
    if ($route === 'ict/me' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictCapabilitiesFor', 'lib/ict.php');
        respond(200, [
            'role'         => $user['role'] ?? '',
            'isSuperAdmin' => isSuperAdmin($user, $config),
            'hasAccess'    => ictHasAnyAccess($pdo, $user, $config),
            // A super admin holds everything implicitly, so the list is reported as complete
            // rather than as whatever rows happen to exist for them.
            'capabilities' => isSuperAdmin($user, $config)
                ? array_keys(ictCapabilityList())
                : ictCapabilitiesFor($pdo, (int)$user['userId']),
        ]);
    }

    /** The vocabulary, so the granting screen is never out of step with the server. */
    if ($route === 'ict/capabilities' && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('ictCapabilityList', 'lib/ict.php');
        respond(200, ['capabilities' => ictCapabilityList()]);
    }

    /** Everyone who holds any ICT capability, plus every admin and ICT account. */
    if ($route === 'ict/staff' && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('ictCapabilitiesFor', 'lib/ict.php');
        if (!ictEnsureTables($pdo)) {
            respond(503, ['error' => 'The ICT tables are not available. Import resok-portal/server/schema-ict.sql.']);
        }

        $rows = $pdo->query("SELECT u.id, u.email, u.role,
                                    TRIM(CONCAT(COALESCE(mp.first_name,''), ' ', COALESCE(mp.surname,''))) AS name
                               FROM users u
                               LEFT JOIN member_profiles mp ON mp.user_id = u.id
                              WHERE u.role IN ('admin','ict')
                                 OR u.id IN (SELECT user_id FROM ict_capabilities)
                              ORDER BY u.role, u.id")->fetchAll();

        respond(200, ['staff' => array_map(fn($r) => [
            'id'           => (int)$r['id'],
            'email'        => $r['email'],
            'name'         => trim((string)$r['name']) ?: null,
            'role'         => $r['role'],
            'isSuperAdmin' => isSuperAdmin(['role' => $r['role'], 'email' => $r['email']], $config),
            'capabilities' => ictCapabilitiesFor($pdo, (int)$r['id']),
        ], $rows)]);
    }

    /**
     * Sets one person's ICT capabilities, as a complete list rather than one grant at a time.
     * Sending the whole set makes the screen's state the intended state - there is no way to
     * tick a box, miss a request, and be left with a permission nobody meant to give.
     */
    if (preg_match('#^ict/staff/(\d+)/capabilities$#', $route, $m) && $method === 'PUT') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('ictCapabilityList', 'lib/ict.php');
        if (!ictEnsureTables($pdo)) {
            respond(503, ['error' => 'The ICT tables are not available. Import resok-portal/server/schema-ict.sql.']);
        }

        $targetId = (int)$m[1];
        $target = $pdo->prepare('SELECT id, email, role FROM users WHERE id = ? LIMIT 1');
        $target->execute([$targetId]);
        $targetRow = $target->fetch();
        if (!$targetRow) respond(404, ['error' => 'That account no longer exists.']);

        $wanted = input()['capabilities'] ?? [];
        if (!is_array($wanted)) respond(400, ['error' => 'Send capabilities as a list.']);

        // Anything outside the vocabulary is refused rather than stored. A typo that is
        // saved becomes a permission no check will ever match and nobody can find to revoke.
        $known = array_keys(ictCapabilityList());
        $unknown = array_values(array_diff($wanted, $known));
        if ($unknown) {
            respond(400, ['error' => 'Unknown capability: ' . implode(', ', array_slice($unknown, 0, 3))]);
        }

        $before = ictCapabilitiesFor($pdo, $targetId);

        $pdo->beginTransaction();
        try {
            $pdo->prepare('DELETE FROM ict_capabilities WHERE user_id = ?')->execute([$targetId]);
            if ($wanted) {
                $insert = $pdo->prepare('INSERT INTO ict_capabilities (user_id, capability, granted_by) VALUES (?, ?, ?)');
                foreach (array_unique($wanted) as $capability) {
                    $insert->execute([$targetId, $capability, (int)$user['userId']]);
                }
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            respond(500, ['error' => 'Nothing was changed: ' . $e->getMessage()]);
        }

        sort($before);
        $after = array_values(array_unique($wanted));
        sort($after);
        ictAudit($pdo, (int)$user['userId'], 'capabilities_changed', 'user', (string)$targetId,
                 $targetRow['email'] . ': ' . count($after) . ' capability(ies)',
                 ['capabilities' => $before], ['capabilities' => $after]);
        securityLog($pdo, $config, 'ict_capabilities_changed', 'warning', 'ict',
                    $targetRow['email'], (int)$user['userId']);

        respond(200, ['capabilities' => $after]);
    }

    /**
     * Moves an account between member, admin and ict.
     *
     * Separate from the existing admin role route because that one only accepts member and
     * admin, and widening it would let a super admin turn an ICT officer into an admin from
     * a screen that does not say that is what it is doing.
     */
    if (preg_match('#^ict/staff/(\d+)/role$#', $route, $m) && $method === 'PUT') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('ictCapabilityList', 'lib/ict.php');

        $targetId = (int)$m[1];
        $role = (string)(input()['role'] ?? '');
        if (!in_array($role, ['member', 'ict'], true)) {
            // Promotion to admin stays on the Administrators panel. Granting access to every
            // member's ID number should happen on the screen that says so, not this one.
            respond(400, ['error' => 'From here an account can be set to member or ict. Use the Administrators panel for admin access.']);
        }
        if ($targetId === (int)$user['userId']) {
            respond(400, ['error' => 'You cannot change your own role.']);
        }

        $target = $pdo->prepare('SELECT id, email, role FROM users WHERE id = ? LIMIT 1');
        $target->execute([$targetId]);
        $targetRow = $target->fetch();
        if (!$targetRow) respond(404, ['error' => 'That account no longer exists.']);

        if ($targetRow['role'] === 'admin') {
            respond(400, ['error' => 'That account is an administrator. Remove admin access first.']);
        }
        if (isSuperAdmin(['role' => $targetRow['role'], 'email' => $targetRow['email']], $config)) {
            respond(400, ['error' => 'That account is named as a super administrator in the server configuration.']);
        }

        $pdo->prepare('UPDATE users SET role = ? WHERE id = ?')->execute([$role, $targetId]);
        sessionRevokeAll($pdo, $targetId);
        ictAudit($pdo, (int)$user['userId'], 'role_changed', 'user', (string)$targetId,
                 $targetRow['email'], ['role' => $targetRow['role']], ['role' => $role]);
        securityLog($pdo, $config, 'ict_role_changed', 'warning', 'ict',
                    $targetRow['email'] . ' -> ' . $role, (int)$user['userId']);

        respond(200, ['role' => $role]);
    }

    /** The ICT activity timeline. */
    if ($route === 'ict/audit' && $method === 'GET') {
        $user = auth($config);
        requireModule('ictAuditRecent', 'lib/ict.php');
        ictRequire($pdo, $user, $config, 'reports.view');
        respond(200, ['entries' => ictAuditRecent($pdo, 60)]);
    }

    // ----- CPD token collection (public) --------------------------------------------------

    /**
     * Step one: send a six-digit code to the address attendance was recorded against.
     *
     * The reply is identical whether or not the address is on the list. Saying "you did not
     * attend" would turn this into a way to work through a delegate list and learn who was
     * there and who still has an uncollected token waiting - and the delegate list is exactly
     * what somebody misusing this would already have.
     */
    if (preg_match('#^events/([a-z0-9-]+)/token/request$#', $route, $m) && $method === 'POST') {
        requireModule('attendeeFor', 'lib/attendance.php');
        requireModule('tokenRelease', 'lib/attendance.php');
        $data = input();
        $email = strtolower(trim((string)($data['email'] ?? '')));

        // Two counters: this address, and this browser. The second is what stops one client
        // walking a list of addresses.
        throttleCheck($pdo, $config, 'token-request', $email);

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            respond(400, ['error' => 'Please enter the email address you registered with.']);
        }
        $event = eventFind($pdo, $m[1]);
        if (!$event) respond(404, ['error' => 'That event could not be found.']);

        // Answered the same way in every branch below - attended or not, token assigned or
        // not - so the page cannot be used to learn who attended or who still has a token
        // waiting. The delegate list is exactly what somebody misusing this would already hold.
        $sameEither = ['message' => 'If that address attended this event, your CPD token is on its way to your email.'];

        $attendee = attendeeFor($pdo, (int)$event['id'], $email);
        if (!$attendee || !(int)$attendee['attended']) {
            throttleFailure($pdo, $config, 'token-request', $email);
            respond(200, $sameEither);
        }

        // The token goes straight to the registered address rather than being shown on screen,
        // so the address itself is the proof of ownership and no separate code step is needed.
        // tokenRelease is idempotent: a member who loses the email can ask again and receive the
        // same token.
        $released = tokenRelease($pdo, $config, (int)$attendee['id']);
        if (!$released) {
            // No token assigned yet - the admin has not loaded the batch, or it ran short. Still
            // answered the same way; the office follows up rather than the page explaining.
            error_log('Token requested by attendee ' . $attendee['id'] . ' but none is assigned.');
            respond(200, $sameEither);
        }

        if (function_exists('sendEventTokenEmail')) {
            sendEventTokenEmail(
                $config, $email, (string)$attendee['full_name'], (string)$event['title'],
                (string)$released['token'],
                $event['approved_points'] === null ? null : (float)$event['approved_points'],
                $event['approval_ref'] ?? null,
                $event['regulator'] ?? null
            );
        }
        throttleSuccess($pdo, $config, 'token-request', $email);
        securityLog($pdo, $config, 'token_emailed', 'info', 'token-request', 'Event ' . $event['slug']);
        respond(200, $sameEither);
    }

    /** Step two: check the code, then release the token. */
    if (preg_match('#^events/([a-z0-9-]+)/token/collect$#', $route, $m) && $method === 'POST') {
        requireModule('tokenCodeVerify', 'lib/attendance.php');
        $data = input();
        $email = strtolower(trim((string)($data['email'] ?? '')));
        $code = trim((string)($data['code'] ?? ''));

        throttleCheck($pdo, $config, 'token-collect', $email);

        $event = eventFind($pdo, $m[1]);
        if (!$event) respond(404, ['error' => 'That event could not be found.']);

        $attendee = $email !== '' ? attendeeFor($pdo, (int)$event['id'], $email) : null;
        if (!$attendee) {
            // The address had to be right to receive a code at all, so this is a wrong
            // address rather than a wrong code - reported the same way either way.
            throttleFailure($pdo, $config, 'token-collect', $email);
            respond(400, ['error' => 'That code is not right.']);
        }

        $check = tokenCodeVerify($pdo, (int)$attendee['id'], $code);
        if (!$check['ok']) {
            throttleFailure($pdo, $config, 'token-collect', $email);
            securityLog($pdo, $config, 'token_code_failed', 'info', 'token-collect', 'Event ' . $event['slug']);
            respond(400, ['error' => $check['error']]);
        }

        $released = tokenRelease($pdo, $config, (int)$attendee['id']);
        if (!$released) {
            respond(409, ['error' => 'Your attendance is recorded, but no token is available yet. Please contact the ReSoK office.']);
        }
        throttleSuccess($pdo, $config, 'token-collect', $email);
        securityLog($pdo, $config, 'token_collected', 'info', 'token-collect', 'Event ' . $event['slug']);

        respond(200, [
            'token'  => $released['token'],
            'name'   => $attendee['full_name'],
            'event'  => $event['title'],
            'points' => $event['approved_points'] === null ? null : (float)$event['approved_points'],
            'approvalRef' => $event['approval_ref'],
            'regulator'   => $event['regulator'],
        ]);
    }

    // ----- CPD tokens (member) ------------------------------------------------------------

    /**
     * A signed-in member's tokens. No code: being signed in is a stronger proof than an
     * email round-trip, so asking for one as well would be theatre.
     */
    if ($route === 'cpd/tokens' && $method === 'GET') {
        $user = auth($config);
        requireModule('tokensForMember', 'lib/attendance.php');
        $member = memberRow($pdo, (int)$user['userId']);
        if (!$member) respond(200, ['tokens' => []]);

        $tokens = tokensForMember($pdo, $config, (int)$member['id']);
        // Seeing it in the dashboard is the collection, so it is recorded as such - otherwise
        // the admin reconciliation could never tell a collected member token from a waiting one.
        $pdo->prepare("UPDATE cpd_tokens t
                       JOIN event_attendees a ON a.id = t.attendee_id
                       SET t.status = 'collected', t.collected_at = NOW()
                       WHERE a.member_profile_id = ? AND t.status = 'assigned'")
            ->execute([(int)$member['id']]);
        respond(200, ['tokens' => $tokens]);
    }

    // ----- Attendance and tokens (admin) --------------------------------------------------

    if (preg_match('#^admin/events/(\d+)/attendees$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('attendanceList', 'lib/attendance.php');
        respond(200, [
            'attendees' => attendanceList($pdo, (int)$m[1]),
            'summary'   => tokensSummary($pdo, (int)$m[1]),
        ]);
    }

    /** Paste a register, a Zoom participant export, or a typed list. */
    if (preg_match('#^admin/events/(\d+)/attendees$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('attendanceParseList', 'lib/attendance.php');
        if (!attendanceEnsureTables($pdo)) {
            respond(503, ['error' => 'The attendance tables are not available. Import schema-tokens.sql.']);
        }

        $data = input();
        $parsed = attendanceParseList((string)($data['list'] ?? ''));
        if (!$parsed['rows']) {
            respond(400, ['error' => 'No email addresses were found in that list.']);
        }
        $channel = in_array($data['channel'] ?? '', ['in_person', 'online', 'unknown'], true) ? $data['channel'] : 'unknown';
        $method_ = in_array($data['method'] ?? '', ['register', 'zoom_report', 'venue_code', 'manual'], true) ? $data['method'] : 'manual';

        $result = attendanceRecord($pdo, (int)$m[1], $parsed['rows'], $channel, $method_,
                                   (int)$user['userId'], !empty($data['markAttended']));
        logAdminAction($pdo, (int)$user['userId'], 'attendance_recorded', null,
                       $result['added'] . ' added, ' . $result['updated'] . ' updated');
        respond(200, [
            'result'  => $result,
            'skipped' => count($parsed['skipped']),
            'summary' => tokensSummary($pdo, (int)$m[1]),
        ]);
    }

    /** Load the batch of tokens generated on the KMPDC portal. */
    if (preg_match('#^admin/events/(\d+)/tokens$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('tokensLoad', 'lib/attendance.php');
        if (!attendanceEnsureTables($pdo)) {
            respond(503, ['error' => 'The attendance tables are not available. Import schema-tokens.sql.']);
        }
        if (!cryptoAvailable($config)) {
            // Refused rather than stored in the clear. A table of readable CPD tokens is
            // worth stealing, and this is the one moment where saying no still costs nothing.
            respond(400, ['error' => 'Set a data_encryption_key before loading tokens, so they are not stored in readable form.']);
        }

        $data = input();
        $result = tokensLoad($pdo, $config, (int)$m[1], (string)($data['tokens'] ?? ''));
        logAdminAction($pdo, (int)$user['userId'], 'tokens_loaded', null, $result['added'] . ' tokens');
        respond(200, ['result' => $result, 'summary' => tokensSummary($pdo, (int)$m[1])]);
    }

    /** Hand one token to each attendee marked present who does not have one. */
    if (preg_match('#^admin/events/(\d+)/tokens/assign$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('tokensAssign', 'lib/attendance.php');
        try {
            $result = tokensAssign($pdo, (int)$m[1]);
        } catch (Throwable $e) {
            respond(500, ['error' => 'Assignment failed and nothing was changed: ' . $e->getMessage()]);
        }
        logAdminAction($pdo, (int)$user['userId'], 'tokens_assigned', null, $result['assigned'] . ' assigned');
        respond(200, ['result' => $result, 'summary' => tokensSummary($pdo, (int)$m[1])]);
    }

    /**
     * The override for a mistyped address.
     *
     * Someone will register as name@gmail.con and then be unable to collect anything. Without
     * this every typo becomes a phone call. Logged against the admin who did it, because a
     * route that reveals a token on request is exactly the one worth being able to audit.
     */
    if (preg_match('#^admin/attendees/(\d+)/token$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('tokenRelease', 'lib/attendance.php');

        $released = tokenRelease($pdo, $config, (int)$m[1]);
        if (!$released) respond(404, ['error' => 'No token is assigned to that attendee.']);

        logAdminAction($pdo, (int)$user['userId'], 'token_revealed', null, 'Attendee ' . $m[1]);
        securityLog($pdo, $config, 'token_revealed_by_admin', 'warning', 'admin',
                    'Attendee ' . $m[1], (int)$user['userId']);
        respond(200, ['token' => $released['token']]);
    }

    // ----- Event management (admin) -----------------------------------------------------

    if ($route === 'admin/events' && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('eventsAll', 'lib/events.php');
        respond(200, ['events' => eventsAll($pdo)]);
    }

    if ($route === 'admin/events' && $method === 'POST') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('eventCreate', 'lib/events.php');

        [$event, $errors] = eventCreate($pdo, input(), (int)$user['userId']);
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        logAdminAction($pdo, (int)$user['userId'], 'event_created', null, $event['title']);
        respond(201, ['event' => $event]);
    }

    if (preg_match('#^admin/events/(\d+)$#', $route, $m) && in_array($method, ['PATCH', 'PUT'], true)) {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        requireModule('eventUpdate', 'lib/events.php');

        [$event, $errors] = eventUpdate($pdo, (int)$m[1], input());
        if ($errors) {
            respond(400, ['error' => $errors['_'] ?? 'Please check the highlighted fields.', 'fields' => $errors]);
        }
        logAdminAction($pdo, (int)$user['userId'], 'event_updated', null, $event['title']);
        respond(200, ['event' => $event]);
    }

    if ($route === 'events/public' && $method === 'GET') {
        $payload = ['events' => eventsUpcoming($pdo)];
        if (($_GET['include'] ?? '') === 'past') $payload['past'] = eventsPast($pdo);
        respond(200, $payload);
    }

    if ($route === 'events' && $method === 'GET') {
        $user = auth($config);
        ensureEventRegistrationsTable($pdo);
        $member = memberRow($pdo, (int)$user['userId']);
        $registeredIds = [];
        if ($member) {
            $stmt = $pdo->prepare('SELECT event_id FROM event_registrations WHERE member_profile_id = ?');
            $stmt->execute([(int)$member['id']]);
            $registeredIds = array_column($stmt->fetchAll(), 'event_id');
        }
        // Served from the database now. eventCatalog() remains as the fallback for a portal
        // whose events table has not been created yet, so this page never comes up empty
        // during the changeover.
        $catalog = array_map('eventLegacyShape', eventsUpcoming($pdo));
        if (!$catalog) $catalog = eventCatalog();
        respond(200, array_map(fn($event) => array_merge($event, ['registered' => in_array($event['id'], $registeredIds, true)]), $catalog));
    }

    if (preg_match('#^events/([a-z0-9-]+)/register$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        ensureEventRegistrationsTable($pdo);
        ensureCpdTable($pdo);
        $member = memberRow($pdo, (int)$user['userId']);
        if (!$member) respond(404, ['error' => 'Member profile not found']);

        $event = null;
        foreach (eventCatalog() as $candidate) {
            if ($candidate['id'] === $m[1]) { $event = $candidate; break; }
        }
        if (!$event) respond(404, ['error' => 'Event not found']);

        $stmt = $pdo->prepare('SELECT id FROM event_registrations WHERE member_profile_id = ? AND event_id = ? LIMIT 1');
        $stmt->execute([(int)$member['id'], $event['id']]);
        if ($stmt->fetch()) respond(409, ['error' => 'You are already registered for this event']);

        $pdo->beginTransaction();
        $pdo->prepare('INSERT INTO event_registrations (member_profile_id, event_id, event_title, cpd_points) VALUES (?, ?, ?, ?)')
            ->execute([(int)$member['id'], $event['id'], $event['title'], $event['cpdPoints']]);
        $pdo->prepare('INSERT INTO cpd_activities (member_profile_id, description, points, occurred_on, added_by) VALUES (?, ?, ?, ?, NULL)')
            ->execute([(int)$member['id'], 'Registered: ' . $event['title'], $event['cpdPoints'], $event['date']]);
        $pdo->prepare('UPDATE member_profiles SET cpd_points = cpd_points + ? WHERE id = ?')->execute([$event['cpdPoints'], (int)$member['id']]);
        $pdo->commit();

        respond(201, ['message' => 'Registered for ' . $event['title'], 'event' => array_merge($event, ['registered' => true])]);
    }

    if ($route === 'cpd/me' && $method === 'GET') {
        $user = auth($config);
        ensureCpdTable($pdo);
        $member = memberRow($pdo, (int)$user['userId']);
        if (!$member) respond(200, []);
        $stmt = $pdo->prepare('SELECT * FROM cpd_activities WHERE member_profile_id = ? ORDER BY occurred_on DESC, created_at DESC LIMIT 200');
        $stmt->execute([(int)$member['id']]);
        respond(200, array_map(fn($row) => [
            'id' => (int)$row['id'],
            'description' => $row['description'],
            'points' => (int)$row['points'],
            'date' => $row['occurred_on'] ?? $row['created_at']
        ], $stmt->fetchAll()));
    }

    if (preg_match('#^members/(\d+)/cpd$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireAdmin($user);
        ensureCpdTable($pdo);
        $stmt = $pdo->prepare('SELECT * FROM cpd_activities WHERE member_profile_id = ? ORDER BY occurred_on DESC, created_at DESC LIMIT 200');
        $stmt->execute([(int)$m[1]]);
        respond(200, array_map(fn($row) => [
            'id' => (int)$row['id'],
            'description' => $row['description'],
            'points' => (int)$row['points'],
            'date' => $row['occurred_on'] ?? $row['created_at']
        ], $stmt->fetchAll()));
    }

    if (preg_match('#^members/(\d+)/cpd$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        ensureCpdTable($pdo);
        $data = input();
        $description = trim((string)($data['description'] ?? ''));
        $points = (int)($data['points'] ?? 0);
        if ($description === '' || $points === 0) respond(400, ['error' => 'A description and non-zero points are required']);
        $occurredOn = !empty($data['occurredOn']) ? $data['occurredOn'] : date('Y-m-d');
        $pdo->prepare('INSERT INTO cpd_activities (member_profile_id, description, points, occurred_on, added_by) VALUES (?, ?, ?, ?, ?)')
            ->execute([(int)$m[1], $description, $points, $occurredOn, (int)$user['userId']]);
        $pdo->prepare('UPDATE member_profiles SET cpd_points = cpd_points + ? WHERE id = ?')->execute([$points, (int)$m[1]]);
        logAdminAction($pdo, (int)$user['userId'], 'cpd_add', (int)$m[1], "{$description} ({$points} pts)");
        $stmt = $pdo->prepare('SELECT * FROM member_profiles WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$m[1]]);
        respond(201, mapMember($stmt->fetch()));
    }

    if ($route === 'members/me/profile-image' && $method === 'POST') {
        $user = auth($config);
        if (empty($_FILES['profileImage'])) respond(400, ['error' => 'No profile photo uploaded']);
        $file = $_FILES['profileImage'];
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) respond(400, ['error' => 'Profile photo upload failed']);
        if (($file['size'] ?? 0) > (int)$config['max_file_size']) respond(413, ['error' => 'Uploaded file is too large']);

        $name = (string)($file['name'] ?? '');
        $type = uploadedMime($file);
        if (!preg_match('/\.(jpe?g|png|webp)$/i', $name) || !preg_match('#^image/(jpe?g|png|webp)$#i', $type)) {
            respond(400, ['error' => 'Only JPG, PNG, and WebP profile photos are allowed']);
        }

        $dir = rtrim($config['upload_dir'], '/\\') . '/profile-images';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $filename = 'profileImage-' . bin2hex(random_bytes(16)) . '.' . $extension;
        if (!move_uploaded_file((string)$file['tmp_name'], $dir . '/' . $filename)) {
            respond(500, ['error' => 'Could not save profile photo']);
        }

        $profileImage = 'profile-images/' . $filename;
        $pdo->prepare('UPDATE member_profiles SET profile_image = ? WHERE user_id = ?')->execute([$profileImage, (int)$user['userId']]);
        if (function_exists('viewAsLogEdit')) viewAsLogEdit($pdo, $user, 'Profile photo changed for the member');
        respond(200, mapMember(memberRow($pdo, (int)$user['userId'])) ?? []);
    }

    if ($route === 'payments/stk-push' && $method === 'POST') {
        // Not live until stk_push_enabled, mpesa_enabled and the credentials are all set.
        // Refused before a payment row is created or Safaricom is contacted.
        if (!function_exists('stkPushLive') || !stkPushLive($config)) {
            respond(410, ['error' => 'Instant M-Pesa payment is not available yet. Pay through the paybill and upload your confirmation on the Payment page.']);
        }
        $user = auth($config);
        ensurePaymentProofColumns($pdo);
        $data = input();
        // The amount is the category's fee from config, never the figure the browser sends -
        // otherwise editing one field would buy an Ordinary membership for KES 1.
        $category = trim((string)($data['type'] ?? ''));
        $amount = mpesaCategoryFee($config, $category);
        $phone = trim((string)($data['phone'] ?? ''));
        if ($amount === null) respond(400, ['error' => 'Please choose a valid membership category']);
        if (!preg_match('/^(?:\+?254|0)7\d{8}$|^(?:\+?254|0)1\d{8}$/', $phone)) respond(400, ['error' => 'Enter a valid Safaricom M-Pesa number']);

        $member = memberRow($pdo, (int)$user['userId']);
        $reference = 'RESOK-' . strtoupper(base_convert((string)time(), 10, 36)) . strtoupper(bin2hex(random_bytes(2)));
        $stmt = $pdo->prepare('INSERT INTO payments (user_id, member_profile_id, amount, currency, method, payment_type, phone, status, reference) VALUES (?, ?, ?, "KES", "M-Pesa STK Push", ?, ?, "pending", ?)');
        $stmt->execute([(int)$user['userId'], $member['id'] ?? null, $amount, $category, $phone, $reference]);
        $paymentId = (int)$pdo->lastInsertId();

        try {
            $stk = initiateStkPush($config, $amount, $phone, $reference);
            error_log("STK push initiated OK: paymentId={$paymentId} checkoutRequestId={$stk['checkoutRequestId']} callbackUrl=" . ($config['mpesa_callback_url'] ?? '(not set)'));
        } catch (Throwable $stkError) {
            error_log('STK push failed to initiate: ' . $stkError->getMessage());
            $pdo->prepare('UPDATE payments SET status = "failed" WHERE id = ?')->execute([$paymentId]);
            respond(502, ['error' => $stkError->getMessage()]);
        }

        $pdo->prepare('UPDATE payments SET provider_reference = ? WHERE id = ?')->execute([$stk['checkoutRequestId'], $paymentId]);
        // checkoutRequestId stays server-side: it is the key a forged callback would need.
        respond(201, ['id' => $paymentId, 'status' => 'pending', 'reference' => $reference, 'amount' => $amount, 'message' => 'Enter your M-Pesa PIN on your phone to complete payment.']);
    }

    if (preg_match('#^payments/(\d+)/status$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        $stmt = $pdo->prepare('SELECT id, status, amount, reference FROM payments WHERE id = ? AND user_id = ? LIMIT 1');
        $stmt->execute([(int)$m[1], (int)$user['userId']]);
        $payment = $stmt->fetch();
        if (!$payment) respond(404, ['error' => 'Payment not found']);
        respond(200, ['id' => (int)$payment['id'], 'status' => $payment['status'], 'amount' => (float)$payment['amount'], 'reference' => $payment['reference']]);
    }

    // Safaricom's STK result. Two paths: payments/stk/callback is the one to register (Daraja
    // rejects some callback URLs containing "mpesa"); the old one still works.
    if (($route === 'payments/stk/callback' || $route === 'payments/mpesa/callback') && $method === 'POST') {
        // Optional shared secret in the URL (&key=...), checked before anything is read.
        $callbackSecret = (string)($config['mpesa_callback_secret'] ?? '');
        if ($callbackSecret !== '' && !hash_equals($callbackSecret, (string)($_GET['key'] ?? ''))) {
            error_log('M-Pesa callback rejected: missing or wrong key');
            respond(403, ['message' => 'Forbidden']);
        }
        ensurePaymentProofColumns($pdo);
        $rawBody = (string)file_get_contents('php://input');
        error_log('M-Pesa callback received: ' . substr($rawBody, 0, 2000));
        $raw = json_decode($rawBody, true);
        $callback = $raw['Body']['stkCallback'] ?? null;
        if (!is_array($callback) || empty($callback['CheckoutRequestID'])) {
            error_log('M-Pesa callback ignored: no CheckoutRequestID found in payload');
            respond(200, ['message' => 'Ignored']);
        }

        $checkoutRequestId = (string)$callback['CheckoutRequestID'];
        $stmt = $pdo->prepare('SELECT * FROM payments WHERE provider_reference = ? AND method = "M-Pesa STK Push" LIMIT 1');
        $stmt->execute([$checkoutRequestId]);
        $payment = $stmt->fetch();
        if (!$payment || $payment['status'] !== 'pending') {
            error_log('M-Pesa callback: no pending STK payment for provider_reference=' . $checkoutRequestId);
            respond(200, ['message' => 'Already processed']);
        }

        if ((int)($callback['ResultCode'] ?? 1) !== 0) {
            $pdo->prepare('UPDATE payments SET status = "failed" WHERE id = ?')->execute([(int)$payment['id']]);
            respond(200, ['message' => 'Processed']);
        }

        // The callback says paid. Believe Safaricom, not the POST: this URL is public, so
        // confirm with a server-to-server status query first. If the query fails the
        // payment stays pending for an admin to check, rather than being marked either way.
        try {
            $confirmed = mpesaStkQuery($config, $checkoutRequestId) === 0;
        } catch (Throwable $queryError) {
            error_log("M-Pesa callback: status query failed for payment {$payment['id']}: " . $queryError->getMessage());
            respond(200, ['message' => 'Received']);
        }
        if (!$confirmed) {
            error_log("M-Pesa callback: payment {$payment['id']} claimed paid but the status query disagrees - left pending");
            respond(200, ['message' => 'Received']);
        }

        $meta = mpesaCallbackMetadata($callback);
        if ($meta['amount'] === null || $meta['amount'] + 0.001 < (float)$payment['amount']) {
            // Money moved but not the full fee: leave it for an admin rather than guess.
            $pdo->prepare('UPDATE payments SET method = "M-Pesa STK Push - check amount" WHERE id = ?')->execute([(int)$payment['id']]);
            error_log("M-Pesa callback: payment {$payment['id']} amount " . var_export($meta['amount'], true) . " is below {$payment['amount']} - left pending");
            respond(200, ['message' => 'Received']);
        }

        // Keep the M-Pesa receipt number where manual payments keep theirs, so a receipt
        // cannot also be claimed through the proof form (provider_reference is unique).
        $pdo->beginTransaction();
        try {
            $pdo->prepare('UPDATE payments SET status = "paid", provider_reference = COALESCE(NULLIF(?, ""), provider_reference) WHERE id = ?')
                ->execute([$meta['receipt'], (int)$payment['id']]);
            if (!empty($payment['member_profile_id'])) {
                if (memberAlreadyJoined(memberRowByProfileId($pdo, (int)$payment['member_profile_id']))) {
                    // Confirmed by Safaricom, so a renewal needs nobody to approve it.
                    requireModule('membershipExtend', 'lib/membership.php');
                    membershipRecordPortalYears($pdo, (int)$payment['member_profile_id']);
                    membershipExtend($pdo, (int)$payment['member_profile_id']);
                } else {
                    $pdo->prepare('UPDATE member_profiles SET membership_status = "under_review", review_reason = NULL, reviewed_at = NOW() WHERE id = ?')->execute([(int)$payment['member_profile_id']]);
                }
            }
            $pdo->commit();
        } catch (Throwable $saveError) {
            $pdo->rollBack();
            error_log("M-Pesa callback: could not record payment {$payment['id']} as paid: " . $saveError->getMessage());
            respond(200, ['message' => 'Received']);
        }
        respond(200, ['message' => 'Processed']);
    }

    if ($route === 'payments' && $method === 'GET') {
        $user = auth($config);
        $stmt = $pdo->prepare('SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC LIMIT 100');
        $stmt->execute([(int)$user['userId']]);
        respond(200, array_map(fn($p) => [
            'id' => (int)$p['id'],
            'amount' => (float)$p['amount'],
            'currency' => $p['currency'],
            'method' => $p['method'],
            'type' => $p['payment_type'],
            'phone' => $p['phone'],
            'status' => $p['status'],
            'reference' => $p['reference'],
            'date' => $p['created_at']
        ], $stmt->fetchAll()));
    }

    if ($route === 'payments' && $method === 'POST') {
        $user = auth($config);
        $data = input();
        if (empty($data['amount']) || (float)$data['amount'] <= 0) respond(400, ['error' => 'Valid amount is required']);
        $member = memberRow($pdo, (int)$user['userId']);
        $reference = 'RESOK-' . strtoupper(base_convert((string)time(), 10, 36)) . strtoupper(bin2hex(random_bytes(2)));
        $stmt = $pdo->prepare('INSERT INTO payments (user_id, member_profile_id, amount, currency, method, payment_type, phone, status, reference) VALUES (?, ?, ?, "KES", "Manual review", ?, ?, "pending", ?)');
        $stmt->execute([(int)$user['userId'], $member['id'] ?? null, (float)$data['amount'], $data['type'] ?? 'Membership', $data['phone'] ?? null, $reference]);
        respond(201, ['id' => (int)$pdo->lastInsertId(), 'amount' => (float)$data['amount'], 'method' => 'Manual review', 'status' => 'pending', 'reference' => $reference, 'date' => gmdate('c')]);
    }

    if ($route === 'payments/proof' && $method === 'POST') {
        $user = auth($config);
        ensurePaymentProofColumns($pdo);
        if (empty($_POST['amount']) || (float)$_POST['amount'] <= 0) respond(400, ['error' => 'Valid amount is required']);
        $mpesaCode = strtoupper(trim((string)($_POST['mpesaCode'] ?? '')));
        $paymentMode = trim((string)($_POST['paymentMode'] ?? 'M-PESA Paybill'));
        $allowedPaymentModes = ['M-PESA Paybill', 'Cheque/interbank Funds Transfer'];
        if (!in_array($paymentMode, $allowedPaymentModes, true)) $paymentMode = 'M-PESA Paybill';
        if (!preg_match('/^[A-Z0-9-]{6,24}$/', $mpesaCode)) respond(400, ['error' => 'A valid payment confirmation code is required']);
        if (empty($_FILES['proof'])) respond(400, ['error' => 'Please upload proof of payment']);

        $file = $_FILES['proof'];
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) respond(400, ['error' => 'Proof upload failed']);
        if (($file['size'] ?? 0) > (int)$config['max_file_size']) respond(413, ['error' => 'Uploaded file is too large']);
        $name = (string)($file['name'] ?? '');
        $type = uploadedMime($file);
        if (!preg_match('/\.(pdf|jpe?g|png)$/i', $name) || !preg_match('#^(application/pdf|image/jpe?g|image/png)$#i', $type)) {
            respond(400, ['error' => 'Only PDF, JPG, and PNG files are allowed']);
        }

        $member = memberRow($pdo, (int)$user['userId']);
        if (!$member) respond(404, ['error' => 'Member profile not found']);

        $stmt = $pdo->prepare('SELECT id FROM payments WHERE provider_reference = ? LIMIT 1');
        $stmt->execute([$mpesaCode]);
        if ($stmt->fetch()) respond(409, ['error' => 'This payment confirmation code has already been submitted']);

        $dir = rtrim($config['upload_dir'], '/\\') . '/Payment_Proof';
        if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
            respond(500, ['error' => 'Could not create the payment proof folder']);
        }
        if (!is_writable($dir)) {
            respond(500, ['error' => 'The payment proof folder is not writable']);
        }
        $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $filename = 'proof-' . bin2hex(random_bytes(16)) . '.' . $extension;
        if (!move_uploaded_file((string)$file['tmp_name'], $dir . '/' . $filename)) {
            respond(500, ['error' => 'Could not save proof of payment']);
        }

        $reference = 'PAY-' . $mpesaCode;
        $pdo->beginTransaction();
        $stmt = $pdo->prepare('INSERT INTO payments (user_id, member_profile_id, amount, currency, method, payment_type, phone, status, reference, provider_reference, proof_filename, proof_original_name, proof_mime_type, proof_file_size) VALUES (?, ?, ?, "KES", ?, ?, ?, "pending", ?, ?, ?, ?, ?, ?)');
        $stmt->execute([(int)$user['userId'], (int)$member['id'], (float)$_POST['amount'], $paymentMode, $_POST['type'] ?? 'Membership Application/Renewal', $_POST['phone'] ?? $member['mobile'], $reference, $mpesaCode, $filename, $name, $type, (int)$file['size']]);
        $paymentId = (int)$pdo->lastInsertId();
        // An applicant waits for review. An existing member renewing keeps their access while
        // the slip is checked; it still shows in the review queue (see members/review-queue).
        if (!memberAlreadyJoined($member)) {
            $stmt = $pdo->prepare('UPDATE member_profiles SET membership_status = "under_review", review_reason = NULL, reviewed_at = NOW() WHERE id = ?');
            $stmt->execute([(int)$member['id']]);
        }
        $pdo->commit();

        $stmt = $pdo->prepare('SELECT * FROM payments WHERE id = ? LIMIT 1');
        $stmt->execute([$paymentId]);
        $p = $stmt->fetch();
        respond(201, [
            'message' => 'Payment proof received. Your membership is under admin review.',
            'payment' => [
                'id' => (int)$p['id'],
                'amount' => (float)$p['amount'],
                'currency' => $p['currency'],
                'method' => $p['method'],
                'type' => $p['payment_type'],
                'phone' => $p['phone'],
                'status' => $p['status'],
                'reference' => $p['reference'],
                'date' => $p['created_at']
            ],
            'member' => mapMember(memberRow($pdo, (int)$user['userId']))
        ]);
    }

    if (preg_match('#^payments/member/(\d+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireAdmin($user);
        $stmt = $pdo->prepare('SELECT * FROM payments WHERE member_profile_id = ? ORDER BY created_at DESC LIMIT 100');
        $stmt->execute([(int)$m[1]]);
        respond(200, array_map(fn($p) => [
            'id' => (int)$p['id'],
            'amount' => (float)$p['amount'],
            'currency' => $p['currency'],
            'method' => $p['method'],
            'type' => $p['payment_type'],
            'phone' => $p['phone'],
            'status' => $p['status'],
            'reference' => $p['reference'],
            'date' => $p['created_at'],
            'proofName' => $p['proof_original_name'],
            'proofDownloadUrl' => !empty($p['proof_filename']) ? 'api/index.php?route=payments/proof/' . (int)$p['id'] : null
        ], $stmt->fetchAll()));
    }

    if (preg_match('#^payments/proof/(\d+)$#', $route, $m) && $method === 'GET') {
        $user = auth($config);
        requireAdmin($user);
        $stmt = $pdo->prepare('SELECT proof_filename, proof_original_name, proof_mime_type FROM payments WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$m[1]]);
        $payment = $stmt->fetch();
        if (!$payment || empty($payment['proof_filename'])) respond(404, ['error' => 'Payment proof not found']);

        $filename = basename((string)$payment['proof_filename']);
        $file = rtrim($config['upload_dir'], '/\\') . '/Payment_Proof/' . $filename;
        if (!is_file($file)) respond(404, ['error' => 'Payment proof file not found']);

        $mime = $payment['proof_mime_type'] ?: 'application/octet-stream';
        header_remove('Content-Type');
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($file));
        $downloadName = preg_replace('/[^A-Za-z0-9._ -]/', '_', (string)($payment['proof_original_name'] ?: $filename));
        header('Content-Disposition: inline; filename="' . addslashes($downloadName) . '"');
        // A payment slip is personal financial data: no cache anywhere may keep a copy.
        header('Cache-Control: private, no-store');
        readfile($file);
        exit;
    }

    if (preg_match('#^payments/(\d+)/confirm$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        $stmt = $pdo->prepare('SELECT * FROM payments WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$m[1]]);
        $payment = $stmt->fetch();
        if (!$payment) respond(404, ['error' => 'Payment not found']);

        $pdo->prepare('UPDATE payments SET status = "paid" WHERE id = ?')->execute([(int)$m[1]]);
        if (!empty($payment['member_profile_id'])) {
            $profileId = (int)$payment['member_profile_id'];
            if (function_exists('membershipRecordPortalYears')) membershipRecordPortalYears($pdo, $profileId);
            $stmt = $pdo->prepare('SELECT membership_status FROM member_profiles WHERE id = ? LIMIT 1');
            $stmt->execute([$profileId]);
            $before = (string)($stmt->fetch()['membership_status'] ?? '');

            if (in_array($before, ['payment_required', 'rejected'], true)) {
                // A first subscription still goes to a human. The renewal date is set when
                // they are approved, because that is when the membership actually begins.
                $pdo->prepare('UPDATE member_profiles SET membership_status = "under_review",
                               review_reason = NULL, reviewed_at = NOW() WHERE id = ?')
                    ->execute([$profileId]);
            } else {
                // A renewal. This used to leave the record untouched, so a member paid and
                // nothing moved - not the status, and not the date they were paying to
                // extend. Renewals do not need re-approving: the membership was approved
                // once, and paying is what continues it.
                requireModule('membershipExtend', 'lib/membership.php');
                $newDue = membershipExtend($pdo, $profileId);
                if ($newDue !== null) {
                    logAdminAction($pdo, (int)$user['userId'], 'membership_renewed', $profileId,
                                   'Renewed to ' . $newDue);
                }
            }
        }

        $stmt = $pdo->prepare('SELECT * FROM payments WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$m[1]]);
        $p = $stmt->fetch();
        respond(200, [
            'id' => (int)$p['id'],
            'amount' => (float)$p['amount'],
            'currency' => $p['currency'],
            'method' => $p['method'],
            'type' => $p['payment_type'],
            'phone' => $p['phone'],
            'status' => $p['status'],
            'reference' => $p['reference'],
            'date' => $p['created_at']
        ]);
    }

    if ($route === 'members/review-queue' && $method === 'GET') {
        $user = auth($config);
        requireAdmin($user);
        $rows = $pdo->query('SELECT mp.*, u.email FROM member_profiles mp JOIN users u ON u.id = mp.user_id WHERE mp.membership_status IN ("under_review", "payment_required", "rejected")
                                OR EXISTS (SELECT 1 FROM payments p WHERE p.member_profile_id = mp.id AND p.status = "pending" AND p.proof_filename IS NOT NULL)
                             ORDER BY mp.updated_at DESC LIMIT 100')->fetchAll();
        respond(200, array_map(fn($row) => array_merge(mapMember($row), ['email' => $row['email']]), $rows));
    }

    // Claim emails for members imported from the register. See lib/invites.php for why this is
    // a long-lived reset link rather than an invitation.
    if ($route === 'members/claims' && $method === 'GET') {
        $user = auth($config);
        requireAdmin($user);
        requireModule('claimsSummary', 'lib/invites.php');
        if (!claimsEnsureTable($pdo)) respond(503, ['error' => 'Claim emails are not available on this server: the database user cannot create the table they need.']);
        respond(200, claimsSummary($pdo));
    }

    if ($route === 'members/claims/send' && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        requireModule('claimsSendBatch', 'lib/invites.php');
        if (!claimsEnsureTable($pdo)) respond(503, ['error' => 'Claim emails are not available on this server: the database user cannot create the table they need.']);
        // A small batch per request: each message is its own conversation with the mail
        // server, and a request that runs past PHP's time limit stops partway through with no
        // report of who was reached.
        $limit = max(1, min(25, (int)(input()['limit'] ?? 20)));
        if (function_exists('set_time_limit')) @set_time_limit(180);
        $result = claimsSendBatch($pdo, $config, $limit);
        logAdminAction($pdo, (int)$user['userId'], 'claim_emails_sent', null, count($result['sent']) . ' sent, ' . count($result['failed']) . ' failed');
        respond(200, $result + ['summary' => claimsSummary($pdo)]);
    }

    if (preg_match('#^members/(\d+)/claim-link$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        requireModule('claimSend', 'lib/invites.php');
        if (!claimsEnsureTable($pdo)) respond(503, ['error' => 'Claim emails are not available on this server: the database user cannot create the table they need.']);
        $row = memberRowByProfileId($pdo, (int)$m[1]);
        if (!$row) respond(404, ['error' => 'No such member.']);
        if ((int)($row['email_verified'] ?? 1) === 1) {
            respond(409, ['error' => 'This member has already claimed their account. If they cannot sign in, they can use "Forgot password".']);
        }
        $reason = null;
        $sent = claimSend($pdo, $config, $row, $reason);
        logAdminAction($pdo, (int)$user['userId'], $sent ? 'claim_email_sent' : 'claim_email_failed', (int)$m[1], $reason);
        respond($sent ? 200 : 502, [
            'sent' => $sent,
            'sentTo' => (string)$row['email'],
            'error' => $sent ? null : ($reason ?? 'The mail server did not accept the message.'),
        ]);
    }

    if ($route === 'members' && $method === 'GET') {
        $user = auth($config);
        requireAdmin($user);
        $rows = $pdo->query(
            'SELECT mp.*, u.email, u.email_verified,
                    COUNT(p.id) AS payment_count,
                    COALESCE(SUM(CASE WHEN p.status = "paid" THEN p.amount ELSE 0 END), 0) AS paid_total,
                    COALESCE(SUM(CASE WHEN p.status = "pending" THEN p.amount ELSE 0 END), 0) AS pending_total,
                    MAX(p.created_at) AS latest_payment_at
             FROM member_profiles mp
             JOIN users u ON u.id = mp.user_id
             LEFT JOIN payments p ON p.member_profile_id = mp.id
             GROUP BY mp.id, u.email, u.email_verified
             ORDER BY mp.created_at DESC
             LIMIT 500'
        )->fetchAll();

        // Which years each member has paid for, fetched once for the whole list rather than
        // once per member - this is a few hundred rows on a page that draws a column per year.
        requireModule('membershipYearsByMember', 'lib/membership.php');
        $years = membershipYearsByMember($pdo);

        respond(200, [
            'members' => array_map(function ($row) use ($years) {
                $paid = $years[(int)$row['id']] ?? [];
                return array_merge(mapMember($row), [
                    'email' => $row['email'],
                    'paymentCount' => (int)$row['payment_count'],
                    'paidTotal' => (float)$row['paid_total'],
                    'pendingTotal' => (float)($row['pending_total'] ?? 0),
                    'latestPaymentAt' => $row['latest_payment_at'],
                    'yearsPaid' => $paid,
                    'lastYearPaid' => $paid ? max($paid) : null,
                ]);
            }, $rows),
            'years' => membershipYearRange($pdo),
        ]);
    }

    if (preg_match('#^members/(\d+)/approve$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        try {
            respond(200, approveMemberById($pdo, $config, (int)$m[1], (int)$user['userId']));
        } catch (RuntimeException $approveError) {
            respond(409, ['error' => $approveError->getMessage()]);
        }
    }

    // Sending the welcome packet is separate from approving, because the two came apart in
    // practice: members imported straight into the database were never approved through the
    // portal and so were never sent their letter and card, and a send that fails leaves an
    // approved member with nothing. This re-sends to a member who already holds a membership
    // ID, and reports the outcome rather than logging it where nobody looks.
    if (preg_match('#^members/(\d+)/welcome-packet$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        $row = memberRowByProfileId($pdo, (int)$m[1]);
        if (!$row) respond(404, ['error' => 'No such member.']);

        $member = mapMember($row);
        if (!$member) respond(404, ['error' => 'No such member.']);
        if (($row['membership_status'] ?? '') !== 'active' || empty($row['membership_id'])) {
            respond(409, ['error' => 'Only an active member with a membership ID can be sent a welcome packet. Approve them first.']);
        }

        $reason = null;
        try {
            $sent = sendWelcomePacketEmail($config, array_merge($member, ['email' => $row['email']]), $reason);
        } catch (Throwable $packetError) {
            $sent = false;
            $reason = $packetError->getMessage();
            error_log('Welcome packet resend failed: ' . $packetError->getMessage());
        }
        logAdminAction($pdo, (int)$user['userId'], $sent ? 'welcome_packet_sent' : 'welcome_packet_failed', (int)$m[1], $reason);
        respond($sent ? 200 : 502, [
            'sent' => $sent,
            'sentTo' => (string)$row['email'],
            // Never null on a failure: the browser shows this string, and "Request failed"
            // tells the administrator nothing they can act on.
            'error' => $sent ? null : ($reason ?? 'The mail server did not accept the message.'),
        ]);
    }

    // Years a member has paid for, and recording one paid outside the portal (the office
    // register's 2026 entries were never imported, e.g. Dr Valentine Kei-Muriithi, 16.02.2026).
    if (preg_match('#^members/(\d+)/years$#', $route, $m)) {
        $user = auth($config);
        requireAdmin($user);
        $row = memberRowByProfileId($pdo, (int)$m[1]);
        if (!$row) respond(404, ['error' => 'No such member.']);
        requireModule('membershipYearsPaid', 'lib/membership.php');
        if ($method === 'POST') {
            $data = input();
            $year = (int)($data['year'] ?? 0);
            $thisYear = (int)date('Y');
            if ($year < 2010 || $year > $thisYear + 1) respond(400, ['error' => 'Choose a year between 2010 and ' . ($thisYear + 1) . '.']);
            $paidOn = trim(is_scalar($data['paidOn'] ?? null) ? (string)$data['paidOn'] : '');
            if ($paidOn !== '') {
                $d = DateTimeImmutable::createFromFormat('!Y-m-d', $paidOn);
                if (!$d || $d->format('Y-m-d') !== $paidOn) respond(400, ['error' => 'The date paid must be a real date.']);
                if ($d > new DateTimeImmutable('today')) respond(400, ['error' => 'The date paid cannot be in the future.']);
            }
            $amount = $data['amount'] ?? null;
            if ($amount === '' || $amount === null) $amount = null;
            elseif (!is_numeric($amount) || (float)$amount < 0 || (float)$amount > 1000000) respond(400, ['error' => 'The amount must be a number.']);
            $receipt = mb_substr(trim(is_scalar($data['receipt'] ?? null) ? (string)$data['receipt'] : ''), 0, 120);
            $exists = $pdo->prepare('SELECT source FROM member_payment_years WHERE member_profile_id = ? AND year = ?');
            $exists->execute([(int)$m[1], $year]);
            if ($exists->fetchColumn()) respond(409, ['error' => $year . ' is already recorded as paid for this member.']);
            $pdo->prepare("INSERT INTO member_payment_years (member_profile_id, year, amount, currency, paid_on, receipt, method, source, note, recorded_by)
                           VALUES (?, ?, ?, 'KES', ?, ?, NULL, 'manual', 'Recorded by an administrator', ?)")
                ->execute([(int)$m[1], $year, $amount === null ? null : (float)$amount, $paidOn ?: null, $receipt ?: null, (int)$user['userId']]);
            // The membership then runs 12 months from the date paid (the end of that year when
            // no date is given), never moving an expiry earlier; a lapsed member who has paid
            // is a member again.
            $due = membershipDueFromPayment($paidOn ?: null, $year);
            $pdo->prepare("UPDATE member_profiles SET renewal_due = ?, membership_status = IF(membership_status = 'expired', 'active', membership_status)
                           WHERE id = ? AND (renewal_due IS NULL OR renewal_due < ?)")
                ->execute([$due, (int)$m[1], $due]);
            logAdminAction($pdo, (int)$user['userId'], 'year_marked_paid', (int)$m[1],
                           $year . ($paidOn ? ', paid ' . $paidOn : '') . ($amount !== null ? ', KES ' . $amount : '') . ($receipt ? ', receipt ' . $receipt : ''));
        }
        respond(200, ['years' => membershipYearsPaid($pdo, (int)$m[1])]);
    }
    // Undo a year recorded by hand by mistake. Register and portal records are not removable here.
    if (preg_match('#^members/(\d+)/years/(\d{4})/remove$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        $stmt = $pdo->prepare("DELETE FROM member_payment_years WHERE member_profile_id = ? AND year = ? AND source = 'manual'");
        $stmt->execute([(int)$m[1], (int)$m[2]]);
        if (!$stmt->rowCount()) respond(400, ['error' => 'Only a year recorded by hand can be removed here.']);
        logAdminAction($pdo, (int)$user['userId'], 'year_unmarked', (int)$m[1], (string)$m[2]);
        requireModule('membershipYearsPaid', 'lib/membership.php');
        respond(200, ['years' => membershipYearsPaid($pdo, (int)$m[1])]);
    }

    // Correcting a member's name: the register import put some names in the wrong fields
    // (e.g. "Amir Faraj Tamin" all in the surname). Logged with the old and new name.
    if (preg_match('#^members/(\d+)/name$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        $row = memberRowByProfileId($pdo, (int)$m[1]);
        if (!$row) respond(404, ['error' => 'No such member.']);
        $data = input();
        $clean = static function ($v, int $max): string {
            $v = trim(preg_replace('/\s+/u', ' ', is_scalar($v) ? (string)$v : '') ?? '');
            return mb_substr($v, 0, $max);
        };
        $title = $clean($data['title'] ?? '', 20);
        $first = $clean($data['firstName'] ?? '', 60);
        $middle = $clean($data['middleName'] ?? '', 60);
        $surname = $clean($data['surname'] ?? '', 60);
        if ($first === '' || $surname === '') respond(400, ['error' => 'First name and surname are both needed.']);
        foreach ([$title, $first, $middle, $surname] as $part) {
            if ($part !== '' && !preg_match("/^[\p{L}\p{M}'. -]+$/u", $part)) {
                respond(400, ['error' => 'Names can contain letters, spaces, apostrophes, hyphens and full stops only.']);
            }
        }
        $before = trim(implode(' ', array_filter([$row['title'] ?? '', $row['first_name'] ?? '', $row['middle_name'] ?? '', $row['surname'] ?? ''])));
        $pdo->prepare('UPDATE member_profiles SET title = ?, first_name = ?, middle_name = ?, surname = ? WHERE id = ?')
            ->execute([$title !== '' ? $title : null, $first, $middle !== '' ? $middle : null, $surname, (int)$m[1]]);
        $after = trim(implode(' ', array_filter([$title, $first, $middle, $surname])));
        logAdminAction($pdo, (int)$user['userId'], 'name_corrected', (int)$m[1], $before . ' -> ' . $after);
        respond(200, mapMember(memberRowByProfileId($pdo, (int)$m[1])) ?? []);
    }

    if (preg_match('#^members/(\d+)/reject$#', $route, $m) && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        $data = input();
        respond(200, rejectMemberById($pdo, (int)$m[1], (string)($data['reason'] ?? 'Please contact ReSoK support for assistance.'), (int)$user['userId']));
    }

    if ($route === 'members/bulk-approve' && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        $data = input();
        $ids = array_map('intval', is_array($data['ids'] ?? null) ? $data['ids'] : []);
        if (!$ids) respond(400, ['error' => 'No members selected']);
        $results = [];
        $errors = [];
        foreach ($ids as $id) {
            try {
                $results[] = approveMemberById($pdo, $config, $id, (int)$user['userId']);
            } catch (RuntimeException $bulkError) {
                $errors[] = ['id' => $id, 'error' => $bulkError->getMessage()];
            }
        }
        respond(200, ['approved' => $results, 'errors' => $errors]);
    }

    if ($route === 'members/bulk-reject' && $method === 'POST') {
        $user = auth($config);
        requireAdmin($user);
        $data = input();
        $ids = array_map('intval', is_array($data['ids'] ?? null) ? $data['ids'] : []);
        $reason = (string)($data['reason'] ?? 'Please contact ReSoK support for assistance.');
        if (!$ids) respond(400, ['error' => 'No members selected']);
        $results = [];
        foreach ($ids as $id) {
            $results[] = rejectMemberById($pdo, $id, $reason, (int)$user['userId']);
        }
        respond(200, ['rejected' => $results]);
    }

    if ($route === 'admin/audit-log' && $method === 'GET') {
        $user = auth($config);
        requireSuperAdmin($user, $config);
        ensureAuditTable($pdo);
        $rows = $pdo->query(
            'SELECT a.*, u.email AS admin_email
             FROM admin_actions a
             LEFT JOIN users u ON u.id = a.admin_user_id
             ORDER BY a.created_at DESC LIMIT 200'
        )->fetchAll();
        respond(200, array_map(fn($row) => [
            'id' => (int)$row['id'],
            'adminEmail' => $row['admin_email'] ?? 'Unknown admin',
            'action' => $row['action'],
            'targetMemberProfileId' => $row['target_member_profile_id'] !== null ? (int)$row['target_member_profile_id'] : null,
            'reason' => $row['reason'],
            'date' => $row['created_at']
        ], $rows));
    }

    // ---------------------------------------------------------------------------------
    // National ILD MDT case submission. Patient data: everything lives in lib/mdt.php, which
    // explains the rules it follows. Off until mdt_enabled is set, except for its staff.
    // ---------------------------------------------------------------------------------
    // Find a Specialist: the public directory of members who opted in, and its admin side.
    if (strpos($route, 'directory/') === 0) {
        requireModule('directoryHandle', 'lib/directory.php');
        directoryHandle($pdo, $config, $route, $method);
    }

    // Staff accounts: the staff home page, and adding and inviting staff (super admins).
    if (strpos($route, 'staff/') === 0) {
        requireModule('staffHandle', 'lib/staff.php');
        staffHandle($pdo, $config, $route, $method);
    }

    // The newsletter list and sending to it (super admins). Signup itself is /newsletter.php.
    if (strpos($route, 'newsletter/') === 0) {
        requireModule('newsletterHandle', 'lib/newsletter.php');
        newsletterHandle($pdo, $config, $route, $method);
    }

    // Staff recruitment: public vacancies and applications, and the recruiters' side.
    if (strpos($route, 'careers/') === 0) {
        requireModule('careersHandle', 'lib/careers.php');
        careersHandle($pdo, $config, $route, $method);
    }

    if ($route === 'mdt' || strpos($route, 'mdt/') === 0) {
        requireModule('mdtHandle', 'lib/mdt.php');
        mdtHandle($pdo, $config, $route, $method);
    }

    // Conference registration, badges and check-in (KISLHC platform). Its routes live in
    // lib/conference-api.php, as the MDT module's do in lib/mdt.php.
    if ($route === 'conference' || strpos($route, 'conference/') === 0) {
        requireModule('confHandle', 'lib/conference-api.php');
        confHandle($pdo, $config, $route, $method);
    }

    // ---------------------------------------------------------------------------------
    // Abstract submission (KISLHC). Authors see an event only once it is published; a
    // super administrator also sees a draft, to try the call before it launches.
    // ---------------------------------------------------------------------------------
    if (strpos($route, 'abstracts') === 0) {
        requireModule('abstractsEnsureTables', 'lib/abstracts.php');
        if (!abstractsEnsureTables($pdo)) {
            respond(503, ['error' => 'Abstract submission is unavailable: its tables could not be created. Import resok-portal/server/schema-abstracts.sql.']);
        }
        // Any visit moves a little of the email queue along, so queued mail goes out even if
        // the cron job was never set up. Bounded by the hourly budget like every send.
        absMailPump($pdo, $config, 3);

        // The author's event, or a 404 that reads the same whether nothing exists or it is
        // still a draft - an unlaunched call is not something the public can discover.
        $absEventFor = function (?array $viewer) use ($pdo, $config): array {
            $preview = $viewer !== null && isSuperAdmin($viewer, $config);
            $row = absCurrentEventRow($pdo, $preview);
            if (!$row) respond(404, ['error' => 'There is no open call for abstracts at the moment.']);
            return $row;
        };
        $absEventOfAbstract = function (array $abstract, array $viewer) use ($pdo, $config): array {
            $event = absEventRow($pdo, (int)$abstract['event_id']);
            if (!$event || ($event['status'] === 'draft' && !isSuperAdmin($viewer, $config))) {
                respond(404, ['error' => 'No such abstract.']);
            }
            return $event;
        };

        // The call as the public and the author page see it (INT-5 can read this too).
        if ($route === 'abstracts/call' && $method === 'GET') {
            $viewer = authOptional($config);
            $row = $absEventFor($viewer);
            respond(200, ['event' => absEventShape($pdo, $row), 'preview' => $row['status'] === 'draft']);
        }

        // Accepted abstracts, once released, for the conference website (INT-5).
        if ($route === 'abstracts/accepted' && $method === 'GET') {
            requireModule('absAcceptedPublic', 'lib/abstracts-decisions.php');
            $row = absCurrentEventRow($pdo, false);
            if (!$row) respond(404, ['error' => 'There is no published conference.']);
            respond(200, ['event' => $row['name'], 'tracks' => absAcceptedPublic($pdo, $row)]);
        }

        // An author account (ACC-1): a portal login with an author profile and no membership
        // record, so it is never asked to pay a membership fee.
        if ($route === 'abstracts/register' && $method === 'POST') {
            $data = input();
            requireFields($data, ['email', 'password', 'firstName', 'lastName', 'affiliation', 'country']);
            $email = strtolower(trim((string)$data['email']));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respond(400, ['error' => 'Please enter a valid email address']);
            botScreenOrFakeSuccess($pdo, $config, $data, 'register', [
                'message' => 'Account created. Please check your email to confirm your address.',
                'requiresVerification' => true,
            ]);
            validateInput($data, [
                'firstName'   => ['First name', 'name'],
                'lastName'    => ['Last name', 'name'],
                'affiliation' => ['Affiliation', 'text', true, ['max' => 200]],
                'country'     => ['Country', 'text', true, ['max' => 60]],
            ]);
            if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{8,64}$/', (string)$data['password'])) {
                respond(400, ['error' => 'Password must be 8-64 characters and include uppercase, lowercase, and a number']);
            }
            throttleCheck($pdo, $config, 'register', $email);
            $stmt = $pdo->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1');
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                throttleFailure($pdo, $config, 'register', $email);
                respond(400, ['error' => 'An account with this email already exists. Sign in instead - members and Academy learners use the same login - or use "Forgot password".']);
            }
            $verified = empty($config['require_email_verification']) ? 1 : 0;
            $verificationToken = $verified ? null : bin2hex(random_bytes(32));
            $pdo->beginTransaction();
            try {
                $pdo->prepare('INSERT INTO users (email, password_hash, email_verified, role, verification_token) VALUES (?, ?, ?, "member", ?)')
                    ->execute([$email, password_hash((string)$data['password'], PASSWORD_DEFAULT), $verified, $verificationToken]);
                $userId = (int)$pdo->lastInsertId();
                $profileError = absProfileSave($pdo, $userId, $data);
                if ($profileError) { $pdo->rollBack(); respond(400, ['error' => $profileError]); }
                $pdo->commit();
            } catch (Throwable $registerError) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $registerError;
            }
            if ($verificationToken) {
                absSendVerificationEmail($pdo, $config, $email, $verificationToken, trim((string)$data['firstName']));
            }
            securityLog($pdo, $config, 'author_registered', 'info', 'register', null, $userId);
            $payload = [
                'message' => $verified ? 'Your account is ready.' : 'Account created. Please check your email to confirm your address, then sign in.',
                'requiresVerification' => !$verified,
            ];
            if ($verified) {
                issueAuthCookie(token(['userId' => $userId, 'email' => $email, 'role' => 'member'], $config['jwt_secret']));
            }
            respond(201, $payload);
        }

        // ------------------------------- Author --------------------------------------
        if ($route === 'abstracts/me' && $method === 'GET') {
            $user = auth($config);
            $row = absCurrentEventRow($pdo, isSuperAdmin($user, $config));
            respond(200, [
                'email' => $user['email'] ?? '',
                'profile' => absProfile($pdo, (int)$user['userId']),
                'abstracts' => absMyAbstracts($pdo, (int)$user['userId']),
                'event' => $row ? absEventShape($pdo, $row) : null,
                'preview' => $row && $row['status'] === 'draft',
                // Whether to show the links to the chairs' page and the reviewer's page.
                'isEventAdmin' => $row && function_exists('absAccess') ? absAccess($pdo, $user, $config, (int)$row['id'])['chair'] : isSuperAdmin($user, $config),
                'isReviewer' => (function () use ($pdo, $user) {
                    $r = $pdo->prepare("SELECT 1 FROM abs_roles WHERE user_id = ? AND role = 'reviewer' LIMIT 1");
                    $r->execute([(int)$user['userId']]);
                    return (bool)$r->fetch();
                })(),
            ]);
        }

        if ($route === 'abstracts/me/profile' && $method === 'POST') {
            $user = auth($config);
            $error = absProfileSave($pdo, (int)$user['userId'], input());
            if ($error) respond(400, ['error' => $error]);
            respond(200, ['profile' => absProfile($pdo, (int)$user['userId'])]);
        }

        if ($route === 'abstracts' && $method === 'POST') {
            $user = auth($config);
            $event = $absEventFor($user);
            if (!absProfile($pdo, (int)$user['userId'])['complete']) {
                respond(400, ['error' => 'Please complete your profile (name, affiliation and country) first.']);
            }
            [$id, $error] = absCreateDraft($pdo, $event, (int)$user['userId']);
            if ($error) respond(400, ['error' => $error]);
            respond(201, ['abstract' => absAbstractShape($pdo, absAbstractRow($pdo, $id), $event)]);
        }

        // Figures (SUB-10, lib/abstracts-figures.php). The image itself, for anyone who may
        // read the abstract; a 404 for everyone else, so a guessed id learns nothing.
        if (preg_match('#^abstracts/figures/(\d+)$#', $route, $m) && $method === 'GET') {
            requireModule('absFigureSend', 'lib/abstracts-figures.php');
            $user = auth($config);
            $figure = absFigureRow($pdo, (int)$m[1]);
            $abstract = $figure ? absAbstractRow($pdo, (int)$figure['abstract_id']) : null;
            if (!$abstract || !absFigureVisible($pdo, $user, $config, $abstract)) respond(404, ['error' => 'Figure not found.']);
            absFigureSend($config, $figure, $abstract['reference']);
        }

        // Adding, captioning and removing figures: the author, or an administrator working
        // for them (ADM-4), while the abstract can still be edited.
        if (preg_match('#^abstracts/(\d+)/figures(?:/(\d+))?$#', $route, $m)) {
            requireModule('absFigureUpload', 'lib/abstracts-figures.php');
            $user = auth($config);
            $row = absOwnAbstract($pdo, (int)$m[1], (int)$user['userId']);
            if (!$row && function_exists('absAccess')) {
                $candidate = absAbstractRow($pdo, (int)$m[1]);
                if ($candidate && absAccess($pdo, $user, $config, (int)$candidate['event_id'])['admin']) $row = $candidate;
            }
            if (!$row) respond(404, ['error' => 'No such abstract.']);
            $event = $absEventOfAbstract($row, $user);
            $figureId = isset($m[2]) ? (int)$m[2] : 0;
            if (!$figureId && $method === 'POST') {
                [$figures, $error] = absFigureUpload($pdo, $config, $event, $row, $_FILES['figure'] ?? [], (string)($_POST['caption'] ?? ''), (int)$user['userId']);
                if ($error) respond(400, ['error' => $error]);
                respond(201, ['figures' => $figures]);
            }
            if ($figureId && $method === 'POST') {
                $error = absFigureCaption($pdo, $event, $row, $figureId, (string)(input()['caption'] ?? ''), (int)$user['userId']);
                if ($error) respond(400, ['error' => $error]);
                respond(200, ['figures' => absFigures($pdo, (int)$row['id'])]);
            }
            if ($figureId && $method === 'DELETE') {
                $error = absFigureDelete($pdo, $config, $event, $row, $figureId, (int)$user['userId']);
                if ($error) respond(400, ['error' => $error]);
                respond(200, ['figures' => absFigures($pdo, (int)$row['id'])]);
            }
            respond(405, ['error' => 'Method not allowed']);
        }

        if (preg_match('#^abstracts/(\d+)(/submit|/withdraw|/attendance)?$#', $route, $m)) {
            $user = auth($config);
            $row = absOwnAbstract($pdo, (int)$m[1], (int)$user['userId']);
            $onBehalf = false;
            // An event administrator may work on an author's abstract for them (ADM-4).
            // Attendance stays the author's own answer.
            if (!$row && ($m[2] ?? '') !== '/attendance' && function_exists('absAccess')) {
                $candidate = absAbstractRow($pdo, (int)$m[1]);
                if ($candidate && absAccess($pdo, $user, $config, (int)$candidate['event_id'])['admin']) { $row = $candidate; $onBehalf = true; }
            }
            if (!$row) respond(404, ['error' => 'No such abstract.']);
            $event = $absEventOfAbstract($row, $user);
            $action = $m[2] ?? '';
            if ($action === '/attendance' && $method === 'POST') {
                requireModule('absAttendance', 'lib/abstracts-decisions.php');
                $data = input();
                $error = absAttendance($pdo, $config, $event, $row, (int)$user['userId'], !empty($data['confirm']), trim((string)($data['reason'] ?? '')));
                if ($error) respond(400, ['error' => $error]);
                respond(200, ['abstract' => absAbstractShape($pdo, absAbstractRow($pdo, (int)$row['id']), $event)]);
            }
            if ($onBehalf && $action === '' && $method === 'GET') {
                $shape = absAbstractShape($pdo, $row, $event);
                $shape['onBehalfOf'] = absPersonName($pdo, (int)$row['submitter_user_id'])['email'];
                respond(200, ['abstract' => $shape, 'event' => absEventShape($pdo, $event)]);
            }

            if ($action === '' && $method === 'GET') {
                respond(200, ['abstract' => absAbstractShape($pdo, $row, $event), 'event' => absEventShape($pdo, $event)]);
            }
            if ($action === '' && in_array($method, ['POST', 'PUT', 'PATCH'], true)) {
                [$ok, $error, $fields] = absSave($pdo, $event, $row, input(), (int)$user['userId']);
                if (!$ok) respond(400, ['error' => $error, 'fields' => $fields]);
                respond(200, ['abstract' => absAbstractShape($pdo, absAbstractRow($pdo, (int)$row['id']), $event)]);
            }
            if ($action === '/submit' && $method === 'POST') {
                [$ok, $error, $fields, $first] = absSubmit($pdo, $event, $row, input(), (int)$user['userId']);
                if (!$ok) respond(400, ['error' => $error, 'fields' => $fields]);
                absSendSubmissionEmails($pdo, $config, $event, (int)$row['id'], $first);
                respond(200, ['abstract' => absAbstractShape($pdo, absAbstractRow($pdo, (int)$row['id']), $event)]);
            }
            if ($action === '/withdraw' && $method === 'POST') {
                $error = absWithdraw($pdo, $event, $row, (int)$user['userId'], trim((string)(input()['reason'] ?? '')));
                if ($error) respond(400, ['error' => $error]);
                absSendWithdrawalEmails($pdo, $config, $event, (int)$row['id']);
                respond(200, ['abstract' => absAbstractShape($pdo, absAbstractRow($pdo, (int)$row['id']), $event)]);
            }
            respond(405, ['error' => 'Method not allowed']);
        }

        // ------------------------------- Reviewer ------------------------------------
        // An invitation link: who it is for and whether it is still open. Public, because
        // the invitee may not have an account yet; the token is the only key.
        if (preg_match('#^abstracts/invite/([a-f0-9]{48})(/accept|/decline)?$#', $route, $m)) {
            requireModule('absInvitationByToken', 'lib/abstracts-review.php');
            $invitation = absInvitationByToken($pdo, $m[1]);
            if (!$invitation) respond(404, ['error' => 'This invitation link is not valid. Ask the programme committee for a new one.']);
            $event = absEventRow($pdo, (int)$invitation['event_id']);
            $action = $m[2] ?? '';
            if ($action === '' && $method === 'GET') {
                $viewer = authOptional($config);
                respond(200, [
                    'invitation' => ['email' => $invitation['email'], 'name' => $invitation['name'], 'status' => $invitation['status'],
                                     'message' => $invitation['message']],
                    'event' => absEventShape($pdo, $event),
                    'reviewDeadline' => absIso($event['review_deadline'], absZone($event)),
                    'signedInAs' => $viewer['email'] ?? null,
                    'profile' => $viewer ? absProfile($pdo, (int)$viewer['userId']) : null,
                ]);
            }
            if ($method === 'POST') {
                $viewer = $action === '/accept' ? auth($config) : authOptional($config);
                $error = absInvitationRespond($pdo, $invitation, $viewer ? (int)$viewer['userId'] : null, $action === '/accept', input());
                if ($error) respond(400, ['error' => $error]);
                respond(200, ['status' => $action === '/accept' ? 'accepted' : 'declined']);
            }
            respond(405, ['error' => 'Method not allowed']);
        }

        if ($route === 'abstracts/reviews' && $method === 'GET') {
            $user = auth($config);
            requireModule('absMyReviews', 'lib/abstracts-review.php');
            $roles = $pdo->prepare("SELECT e.id, e.name, v.tracks, v.expertise, v.max_load FROM abs_roles r
                                    JOIN abs_events e ON e.id = r.event_id
                                    LEFT JOIN abs_reviewers v ON v.event_id = r.event_id AND v.user_id = r.user_id
                                    WHERE r.user_id = ? AND r.role = 'reviewer' AND e.status <> 'archived' ORDER BY e.id DESC");
            $roles->execute([(int)$user['userId']]);
            $events = array_map(fn($r) => [
                'id' => (int)$r['id'], 'name' => $r['name'], 'tracks' => absTracks($pdo, (int)$r['id']),
                'trackIds' => array_map('intval', json_decode((string)($r['tracks'] ?? '[]'), true) ?: []),
                'expertise' => $r['expertise'], 'maxLoad' => $r['max_load'] !== null ? (int)$r['max_load'] : null,
            ], $roles->fetchAll());
            respond(200, ['email' => $user['email'] ?? '', 'events' => $events, 'reviews' => absMyReviews($pdo, (int)$user['userId'])]);
        }

        if (preg_match('#^abstracts/reviewer/(\d+)$#', $route, $m) && $method === 'POST') {
            $user = auth($config);
            requireModule('absReviewerProfileSave', 'lib/abstracts-review.php');
            if (!absAccess($pdo, $user, $config, (int)$m[1])['reviewer']) respond(403, ['error' => 'You are not a reviewer for this event.']);
            $error = absReviewerProfileSave($pdo, (int)$m[1], (int)$user['userId'], input());
            if ($error) respond(400, ['error' => $error]);
            respond(200, ['saved' => true]);
        }

        if (preg_match('#^abstracts/reviews/(\d+)(/submit|/decline)?$#', $route, $m)) {
            $user = auth($config);
            requireModule('absOwnReview', 'lib/abstracts-review.php');
            $review = absOwnReview($pdo, (int)$m[1], (int)$user['userId']);
            if (!$review) respond(404, ['error' => 'No such review.']);
            $event = absEventRow($pdo, (int)$review['event_id']);
            $action = $m[2] ?? '';
            if ($action === '' && $method === 'GET') respond(200, ['review' => absReviewForReviewer($pdo, $review, $event)]);
            if ($action === '/decline' && $method === 'POST') {
                $error = absReviewDecline($pdo, $event, $review, (string)(input()['reason'] ?? ''), (int)$user['userId']);
                if ($error) respond(400, ['error' => $error]);
            } elseif ($method === 'POST' && in_array($action, ['', '/submit'], true)) {
                [$ok, $error, $fields] = absReviewSave($pdo, $event, $review, input(), $action === '/submit', (int)$user['userId']);
                if (!$ok) respond(400, ['error' => $error, 'fields' => $fields]);
            } else {
                respond(405, ['error' => 'Method not allowed']);
            }
            respond(200, ['review' => absReviewForReviewer($pdo, absOwnReview($pdo, (int)$review['id'], (int)$user['userId']) ?? $review, $event)]);
        }

        // --------------------------- Administration ----------------------------------
        // Super administrators see every event; chairs and event administrators see the
        // events they hold a role in. Only super administrators create events.
        if ($route === 'abstracts/admin/events' && $method === 'GET') {
            $user = auth($config);
            requireModule('absChairEvents', 'lib/abstracts-review.php');
            $events = absChairEvents($pdo, $user, $config);
            if (!$events && !isSuperAdmin($user, $config)) respond(403, ['error' => 'You do not chair or administer any conference.']);
            foreach ($events as &$e) $e['access'] = absAccess($pdo, $user, $config, $e['id']);
            unset($e);
            respond(200, ['events' => $events, 'defaults' => absDefaultSettings(), 'canCreate' => isSuperAdmin($user, $config),
                          'timezones' => DateTimeZone::listIdentifiers()]);
        }

        if ($route === 'abstracts/admin/events' && $method === 'POST') {
            $user = auth($config);
            requireSuperAdmin($user, $config);
            [$event, $error] = absEventSave($pdo, null, input(), (int)$user['userId']);
            if ($error) respond(400, ['error' => $error]);
            respond(201, ['event' => $event]);
        }

        if (preg_match('#^abstracts/admin/events/(\d+)(?:/([a-z-]+))?(?:/(\d+))?(?:/([a-z]+))?$#', $route, $m)) {
            $user = auth($config);
            requireModule('absAccess', 'lib/abstracts-review.php');
            $eventId = (int)$m[1];
            $event = absEventRow($pdo, $eventId);
            if (!$event) respond(404, ['error' => 'No such event.']);
            $access = absAccess($pdo, $user, $config, $eventId);
            if (!$access['chair']) respond(403, ['error' => 'You do not chair or administer this event.']);
            $sub = $m[2] ?? '';
            $itemId = isset($m[3]) ? (int)$m[3] : null;
            $verb = $m[4] ?? '';
            $me = (int)$user['userId'];
            $needAdmin = function () use ($access) { if (!$access['admin']) respond(403, ['error' => 'Only an event administrator can do that.']); };
            $needProgramme = function () use ($access) { if (!$access['programme']) respond(403, ['error' => 'Only the programme chair can do that.']); };

            // An archived event is read-only (INT-2): it can be looked at, exported and
            // un-archived from the setup tab, but nothing in it changes.
            if ($event['status'] === 'archived' && $method === 'POST' && $sub !== '') {
                respond(403, ['error' => 'This event is archived and read-only. Change its visibility in Event setup to make changes.']);
            }


            if ($sub === '' && $method === 'GET') respond(200, ['event' => absEventShape($pdo, $event, true), 'access' => $access]);
            if ($sub === '' && in_array($method, ['POST', 'PUT', 'PATCH'], true)) {
                $needAdmin();
                [$saved, $error] = absEventSave($pdo, $eventId, input(), $me);
                if ($error) respond(400, ['error' => $error]);
                respond(200, ['event' => $saved]);
            }
            if ($sub === 'abstracts' && $method === 'GET') {
                $list = absAdminList($pdo, $event);
                if (!$access['programme']) {
                    $ids = $access['trackIds'];
                    $trackOf = $pdo->prepare('SELECT id, track_id FROM abs_abstracts WHERE event_id = ?');
                    $trackOf->execute([$eventId]);
                    $map = array_column($trackOf->fetchAll(), 'track_id', 'id');
                    $list['abstracts'] = array_values(array_filter($list['abstracts'], fn($a) => in_array((int)($map[$a['id']] ?? 0), $ids, true)));
                    $list['counts'] = array_fill_keys(ABS_STATUSES, 0);
                    foreach ($list['abstracts'] as $a) $list['counts'][$a['status']]++;
                }
                respond(200, $list);
            }
            if ($sub === 'audit' && $method === 'GET') { $needProgramme(); respond(200, ['audit' => absAuditFor($pdo, $eventId, null)]); }

            // Roles (administrators).
            if ($sub === 'roles' && $method === 'GET') respond(200, ['roles' => absRolesList($pdo, $eventId)]);
            if ($sub === 'roles' && $method === 'POST' && !$itemId) {
                $needAdmin();
                $data = input();
                $error = absRoleGrant($pdo, $eventId, (string)($data['email'] ?? ''), (string)($data['role'] ?? ''),
                                      isset($data['trackId']) ? (int)$data['trackId'] : null, $me);
                if ($error) respond(400, ['error' => $error]);
                respond(200, ['roles' => absRolesList($pdo, $eventId)]);
            }
            if ($sub === 'roles' && $itemId && $verb === 'revoke' && $method === 'POST') {
                $needAdmin();
                if ($error = absRoleRevoke($pdo, $eventId, $itemId, $me)) respond(400, ['error' => $error]);
                respond(200, ['roles' => absRolesList($pdo, $eventId)]);
            }

            // Reviewers and invitations (any chair).
            if ($sub === 'reviewers' && $method === 'GET') {
                respond(200, ['reviewers' => absReviewersList($pdo, $event), 'invitations' => absInvitationsList($pdo, $eventId)]);
            }
            if ($sub === 'invitations' && $method === 'POST' && !$itemId) {
                $data = input();
                $emails = preg_split('/[\s,;]+/', strtolower((string)($data['emails'] ?? ''))) ?: [];
                $emails = array_values(array_unique(array_filter($emails)));
                if (!$emails) respond(400, ['error' => 'Enter at least one email address.']);
                if (count($emails) > 100) respond(400, ['error' => 'Invite up to 100 people at a time.']);
                $errors = [];
                $sent = 0;
                foreach ($emails as $email) {
                    $error = absInvite($pdo, $config, $event, $email, count($emails) === 1 ? (string)($data['name'] ?? '') : '', (string)($data['message'] ?? ''), $me);
                    $error ? $errors[] = $error : $sent++;
                }
                respond(200, ['sent' => $sent, 'errors' => $errors, 'invitations' => absInvitationsList($pdo, $eventId)]);
            }
            if ($sub === 'invitations' && $itemId && in_array($verb, ['resend', 'revoke'], true) && $method === 'POST') {
                $inv = $pdo->prepare('SELECT * FROM abs_invitations WHERE id = ? AND event_id = ?');
                $inv->execute([$itemId, $eventId]);
                $row = $inv->fetch();
                if (!$row || $row['status'] !== 'pending') respond(400, ['error' => 'That invitation is no longer pending.']);
                if ($verb === 'revoke') {
                    $pdo->prepare("UPDATE abs_invitations SET status = 'revoked', responded_at = NOW() WHERE id = ?")->execute([$itemId]);
                } elseif ($error = absInvite($pdo, $config, $event, (string)$row['email'], (string)($row['name'] ?? ''), (string)($row['message'] ?? ''), $me)) {
                    respond(400, ['error' => $error]);
                }
                respond(200, ['invitations' => absInvitationsList($pdo, $eventId)]);
            }
            if ($sub === 'reinvite' && $method === 'POST') {
                $from = (int)(input()['fromEventId'] ?? 0);
                if (!$from || $from === $eventId) respond(400, ['error' => 'Choose an earlier event.']);
                respond(200, absReinvitePrevious($pdo, $config, $event, $from, $me));
            }

            // Assignment and progress (chairs, within their tracks).
            if ($sub === 'board' && $method === 'GET') {
                $board = absReviewBoard($pdo, $event, $access);
                $tracks = array_values(array_filter(absTracks($pdo, $eventId), fn($t) => absReaches($access, $t['id'])));
                respond(200, ['board' => $board, 'reviewers' => absReviewersList($pdo, $event),
                              'byTrack' => absProgressByTrack($board, $tracks, absSettings($event['settings'])['reviewsPerAbstract']),
                              'callOpen' => absCallState($event) === 'open', 'reviewOverdue' => absReviewOverdue($event)]);
            }
            if ($sub === 'assign' && $method === 'POST') {
                $data = input();
                $pairs = is_array($data['pairs'] ?? null) ? $data['pairs'] : [];
                if (!$pairs && isset($data['reviewerUserId'])) {
                    foreach ((array)($data['abstractIds'] ?? []) as $aid) $pairs[] = ['abstractId' => (int)$aid, 'reviewerUserId' => (int)$data['reviewerUserId']];
                }
                if (!$pairs) respond(400, ['error' => 'Choose abstracts and a reviewer.']);
                respond(200, absAssignMany($pdo, $config, $event, $access, $pairs, $me));
            }
            if ($sub === 'reviews' && $itemId && $verb === 'unassign' && $method === 'POST') {
                if ($error = absUnassign($pdo, $event, $access, $itemId, $me)) respond(400, ['error' => $error]);
                respond(200, ['ok' => true]);
            }
            if ($sub === 'auto-proposal' && $method === 'GET') respond(200, absAutoProposal($pdo, $event, $access));
            if ($sub === 'reminders' && $method === 'POST') respond(200, ['sent' => absSendReviewReminders($pdo, $config, $event, true)]);

            // Decisions (DEC-1..7), reporting and templates.
            if (in_array($sub, ['decisions', 'recommend', 'decide', 'release', 'move', 'on-behalf', 'export', 'book', 'stats', 'templates'], true)) {
                requireModule('absDecisionBoard', 'lib/abstracts-decisions.php');
            }
            if ($sub === 'decisions' && $method === 'GET') {
                $pending = $pdo->prepare("SELECT COUNT(*) FROM abs_abstracts a JOIN abs_decisions d ON d.abstract_id = a.id
                                          WHERE a.event_id = ? AND a.status = 'decision_pending' AND d.released_at IS NULL");
                $pending->execute([$eventId]);
                respond(200, ['board' => absDecisionBoard($pdo, $event, $access),
                              'finalTypes' => absFinalTypes(absSettings($event['settings'])),
                              'pendingRelease' => (int)$pending->fetchColumn()]);
            }
            if ($sub === 'recommend' && $method === 'POST') {
                $data = input();
                if ($error = absRecommend($pdo, $event, $access, (int)($data['abstractId'] ?? 0), (string)($data['outcome'] ?? ''), $data['type'] ?? null, $me)) {
                    respond(400, ['error' => $error]);
                }
                respond(200, ['ok' => true]);
            }
            if ($sub === 'decide' && $method === 'POST') {
                $needProgramme();
                $data = input();
                respond(200, absDecide($pdo, $event, $access, (array)($data['abstractIds'] ?? []), (string)($data['outcome'] ?? ''),
                                       $data['type'] ?? null, trim((string)($data['note'] ?? '')), !empty($data['override']), $me));
            }
            if ($sub === 'release' && $method === 'POST') {
                $needProgramme();
                $data = input();
                respond(200, absRelease($pdo, $config, $event, $access, !empty($data['trackId']) ? (int)$data['trackId'] : null,
                                        isset($data['abstractIds']) ? (array)$data['abstractIds'] : null, $me));
            }
            if ($sub === 'move' && $method === 'POST') {
                $data = input();
                if ($error = absMoveTrack($pdo, $event, $access, (int)($data['abstractId'] ?? 0), (int)($data['trackId'] ?? 0), $me)) {
                    respond(400, ['error' => $error]);
                }
                respond(200, ['ok' => true]);
            }
            if ($sub === 'on-behalf' && $method === 'POST') {
                $needAdmin();
                [$id, $error] = absStartOnBehalf($pdo, $event, input(), $me);
                if ($error) respond(400, ['error' => $error]);
                respond(201, ['abstractId' => $id]);
            }
            if ($sub === 'stats' && $method === 'GET') { $needProgramme(); respond(200, absStats($pdo, $event)); }
            if ($sub === 'templates' && $method === 'GET') { $needAdmin(); respond(200, ['templates' => absTemplatesFor($pdo, $eventId)]); }
            if ($sub === 'templates' && $method === 'POST') {
                $needAdmin();
                $data = input();
                if ($error = absTemplateSave($pdo, $eventId, (string)($data['key'] ?? ''), (string)($data['subject'] ?? ''), (string)($data['body'] ?? ''), $me)) {
                    respond(400, ['error' => $error]);
                }
                respond(200, ['templates' => absTemplatesFor($pdo, $eventId)]);
            }
            // Downloads, sent as files rather than JSON; the filename carries the event and date.
            if (in_array($sub, ['export', 'book'], true) && $method === 'GET') {
                $kind = (string)($_GET['kind'] ?? 'abstracts');
                $format = (string)($_GET['format'] ?? 'csv');
                if ($sub === 'book' || $kind === 'reviews') $needProgramme();
                if ($sub === 'export' && !in_array($kind, ['abstracts', 'authors', 'reviews', 'decisions'], true)) respond(400, ['error' => 'Unknown export.']);
                $stamp = $event['ref_prefix'] . '-' . date('Y-m-d');
                absAudit($pdo, $eventId, null, $me, 'exported', null, null, ['kind' => $sub === 'book' ? 'book' : $kind, 'format' => $format]);
                header_remove('Content-Type');
                header('Cache-Control: no-store');
                if ($sub === 'book') {
                    $book = absBookData($pdo, $event);
                    if ($format === 'word') {
                        header('Content-Type: application/msword; charset=UTF-8');
                        header('Content-Disposition: attachment; filename="abstract-book-' . $stamp . '.doc"');
                        echo absBookWordHtml($book);
                        exit;
                    }
                    respond(200, $book);
                }
                $rows = absExportRows($pdo, $event, $access, $kind);
                if ($format === 'xlsx') {
                    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                    header('Content-Disposition: attachment; filename="' . $kind . '-' . $stamp . '.xlsx"');
                    echo absXlsx($rows, ucfirst($kind));
                } else {
                    header('Content-Type: text/csv; charset=UTF-8');
                    header('Content-Disposition: attachment; filename="' . $kind . '-' . $stamp . '.csv"');
                    echo absCsv($rows);
                }
                exit;
            }

            // The email queue (administrators).
            if ($sub === 'emails' && $method === 'GET') {
                $needAdmin();
                $q = $pdo->prepare("SELECT id, template, to_email, subject, status, error, attempts, created_at, sent_at FROM abs_emails
                                    WHERE (event_id = ? OR event_id IS NULL) AND template NOT IN ('newsletter','staff-announcement') AND status IN ('queued','sending','failed') ORDER BY id DESC LIMIT 300");
                $q->execute([$eventId]);
                $counts = $pdo->prepare("SELECT status, COUNT(*) AS n FROM abs_emails WHERE (event_id = ? OR event_id IS NULL) AND template NOT IN ('newsletter','staff-announcement') GROUP BY status");
                $counts->execute([$eventId]);
                respond(200, ['emails' => $q->fetchAll(), 'counts' => array_column($counts->fetchAll(), 'n', 'status'),
                              'hourlyLimit' => absMailHourlyLimit($config)]);
            }
            if ($sub === 'emails' && $itemId && $verb === 'resend' && $method === 'POST') {
                $needAdmin();
                if (!absMailResend($pdo, $config, $itemId)) respond(400, ['error' => 'That message cannot be resent.']);
                respond(200, ['ok' => true]);
            }
            if ($sub === 'emails' && $verb === '' && !$itemId && $method === 'POST') {
                $needAdmin();
                respond(200, absMailPump($pdo, $config, 50));
            }
            respond(404, ['error' => 'Route not found']);
        }

        if (preg_match('#^abstracts/admin/abstracts/(\d+)(/reopen)?$#', $route, $m)) {
            $user = auth($config);
            requireModule('absAccess', 'lib/abstracts-review.php');
            $row = absAbstractRow($pdo, (int)$m[1]);
            if (!$row) respond(404, ['error' => 'No such abstract.']);
            $access = absAccess($pdo, $user, $config, (int)$row['event_id']);
            if (!$access['chair'] || !absReaches($access, $row['track_id'])) respond(403, ['error' => 'This abstract is outside what you chair.']);
            $event = absEventRow($pdo, (int)$row['event_id']);
            if (($m[2] ?? '') === '' && $method === 'GET') {
                $submitter = $pdo->prepare('SELECT email FROM users WHERE id = ?');
                $submitter->execute([(int)$row['submitter_user_id']]);
                $emails = $pdo->prepare('SELECT id, template, to_email, subject, status, error, created_at FROM abs_emails WHERE abstract_id = ? ORDER BY id DESC');
                $emails->execute([(int)$row['id']]);
                // The committee sees every review in full, with who wrote it (REV-11 limits
                // reviewers, not chairs).
                $reviews = $pdo->prepare("SELECT * FROM abs_reviews WHERE abstract_id = ? AND status <> 'cancelled' ORDER BY id");
                $reviews->execute([(int)$row['id']]);
                $reviewList = array_map(fn($r) => [
                    'id' => (int)$r['id'], 'reviewer' => absPersonName($pdo, (int)$r['reviewer_user_id'])['name'], 'status' => $r['status'],
                    'scores' => json_decode((string)($r['scores'] ?? '{}'), true) ?: [], 'total' => $r['total'] !== null ? (float)$r['total'] : null,
                    'commentsAuthors' => $r['comments_authors'], 'commentsCommittee' => $r['comments_committee'],
                    'recommendation' => $r['recommendation'], 'recommendedType' => $r['recommended_type'], 'declineReason' => $r['decline_reason'],
                    'submittedAt' => $r['submitted_at'],
                ], $reviews->fetchAll());
                respond(200, [
                    'abstract' => absAbstractShape($pdo, $row, $event, true),
                    'submitterEmail' => (string)$submitter->fetchColumn(),
                    'versions' => absVersions($pdo, (int)$row['id']),
                    'audit' => absAuditFor($pdo, null, (int)$row['id']),
                    'emails' => $emails->fetchAll(),
                    'reviews' => $reviewList,
                    'criteria' => absSettings($event['settings'])['criteria'],
                    'access' => $access,
                ]);
            }
            if (($m[2] ?? '') === '/reopen' && $method === 'POST') {
                if (!$access['admin']) respond(403, ['error' => 'Only an event administrator can return an abstract for corrections.']);
                $data = input();
                $error = absReopen($pdo, $event, $row, (int)$user['userId'], $data['until'] ?? null, trim((string)($data['note'] ?? '')));
                if ($error) respond(400, ['error' => $error]);
                respond(200, ['abstract' => absAbstractShape($pdo, absAbstractRow($pdo, (int)$row['id']), $event, true)]);
            }
            respond(405, ['error' => 'Method not allowed']);
        }

        respond(404, ['error' => 'Route not found']);
    }

    respond(404, ['error' => 'Route not found']);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    error_log($error->getMessage());
    respond(500, ['error' => $isDebug ? $error->getMessage() : 'The portal API could not complete this request.']);
}

