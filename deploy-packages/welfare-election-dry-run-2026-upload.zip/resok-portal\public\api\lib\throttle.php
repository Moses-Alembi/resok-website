<?php
declare(strict_types=1);

/**
 * Abuse protection: rate limiting for any endpoint, and the security event log that the
 * admin threat assessment reads.
 *
 * Every limited action uses the same two-counter shape, because one counter is never
 * enough:
 *
 *   subject - keyed on what is being attacked (an email, a member id) plus the client, so
 *             hammering one target is stopped quickly. Keyed on the target ALONE, anyone
 *             could lock a member out of their own account by failing logins on their
 *             behalf - trading a break-in risk for a denial-of-service one.
 *
 *   client  - keyed on the client alone, catching the attack the first cannot see: one
 *             password sprayed across many emails, where no single account fails twice.
 *
 * Nothing identifying is stored. Both keys are salted HMACs of the email and client, so the
 * tables cannot be mined if they leak and hold nothing that needs a retention policy.
 *
 * The client fingerprint mixes in the user agent because a hospital or a shared office will
 * NAT many legitimate members behind one address, and an IP-only counter locks them out
 * together.
 */

// Per-action limits: [subject failures, client failures, window seconds, lock seconds].
// Login is tightest. Registration and password reset are looser but still bounded, since
// both send email and are therefore also a way to use the site as a spam relay.
const THROTTLE_RULES = [
    'login'          => [8,  25, 900, 900],
    'register'       => [5,  15, 3600, 1800],
    'password-reset' => [5,  15, 3600, 1800],
    'payment'        => [10, 30, 3600, 900],
    'upload'         => [20, 60, 3600, 900],
    // Find a Specialist contact reveals. Generous for a person comparing a few clinicians;
    // the client limit stops a script collecting every member's phone number.
    'directory-contact' => [20, 40, 3600, 1800],
    // Job applications. Every submission counts, so one browser cannot flood a vacancy.
    'careers-apply'  => [5,  20, 3600, 1800],
    // Conference group join codes: a delegate mistyping one is fine, a script trying many is not.
    'conf_group_code' => [5, 15, 3600, 1800],
    // Booth staff scanning codes that are not badges: a misread or two, not a sweep.
    'conf_lead_scan' => [20, 60, 3600, 900],
    // Token collection. The client limit is the one that matters: a delegate list is public
    // enough that the attack is one browser working through many addresses, not many
    // attempts at one. Generous per address, because a real attendee whose code expires
    // while they hunt for the email will legitimately ask for two or three.
    'token-request'  => [6,  20, 3600, 900],
    'token-collect'  => [8,  30, 3600, 900],
    // Generous: a bad morning genuinely produces three tickets, and a helpdesk that refuses
    // the third is a helpdesk people stop using.
    'ticket'         => [20, 60, 3600, 900],
    // Certificate checks are public. Only a code that matches nothing is counted, so an
    // employer checking a stack of genuine certificates is never refused.
    'certificate-verify' => [30, 30, 900, 900],
    // The public contact form. Every send counts, not just failures: it mails info@resok.org,
    // so an unlimited form is a way to bury the secretariat's inbox.
    'contact'        => [3,  8,  3600, 3600],
    // Newsletter signup. Each attempt emails the address typed in, so the limit protects
    // that inbox as much as ours: 3 confirmation emails an hour to one address.
    'newsletter'     => [3,  10, 3600, 3600],
];
const THROTTLE_DEFAULT = [15, 40, 900, 900];

/**
 * Creates the tables on first use, and returns false if it cannot.
 *
 * Creating them at request time only works if the database user holds CREATE privilege,
 * which on shared hosting it often does not. Every caller must therefore treat failure as
 * "this control is unavailable" rather than letting the exception escape: a login that
 * fails because rate limiting could not build its own table locks every member out of the
 * portal to protect them from a brute-force attack that has not happened. Losing the
 * control is bad; losing authentication is worse.
 */
function throttleEnsureTables(PDO $pdo): bool
{
    static $state = null;
    if ($state !== null) return $state;
    try {
        throttleCreateTables($pdo);
        $state = true;
    } catch (Throwable $e) {
        error_log('Rate limiting unavailable - could not create its tables: ' . $e->getMessage());
        $state = false;
    }
    return $state;
}

function throttleCreateTables(PDO $pdo): void
{
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS auth_attempts (
            scope_key CHAR(64) NOT NULL,
            action VARCHAR(40) NOT NULL DEFAULT "login",
            failures SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            first_failure_at DATETIME NOT NULL,
            last_failure_at DATETIME NOT NULL,
            locked_until DATETIME NULL,
            PRIMARY KEY (scope_key),
            KEY auth_attempts_locked (locked_until),
            KEY auth_attempts_action (action, last_failure_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
    // The event log is what the admin threat assessment reads. It records that something
    // happened and roughly where, never who: an event carries a client hash, not an address.
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS security_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_type VARCHAR(40) NOT NULL,
            action VARCHAR(40) NULL,
            severity ENUM("info","warning","critical") NOT NULL DEFAULT "info",
            client_hash CHAR(64) NULL,
            user_id INT UNSIGNED NULL,
            detail VARCHAR(300) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY security_events_time (created_at),
            KEY security_events_type (event_type, created_at),
            KEY security_events_severity (severity, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
}

function throttleScopeKey(array $config, string $action, string $scope, string $value): string
{
    return hash_hmac('sha256', $action . '|' . $scope . '|' . strtolower(trim($value)), (string)$config['jwt_secret']);
}

/**
 * Cloudflare's published address ranges (https://www.cloudflare.com/ips/, checked 16 Oct 2026).
 * Re-check that page if Cloudflare announces a change; 'trusted_proxy_ranges' in config adds
 * more without a code change.
 */
const CLOUDFLARE_RANGES = [
    '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22', '141.101.64.0/18', '108.162.192.0/18',
    '190.93.240.0/20', '188.114.96.0/20', '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
    '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
    '2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32', '2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
];

function ipInRange(string $ip, string $cidr): bool
{
    [$net, $bits] = array_pad(explode('/', $cidr, 2), 2, null);
    $ipBin = @inet_pton($ip);
    $netBin = @inet_pton((string)$net);
    if ($ipBin === false || $netBin === false || strlen($ipBin) !== strlen($netBin)) return false;
    $bits = $bits === null ? strlen($ipBin) * 8 : (int)$bits;
    $bytes = intdiv($bits, 8);
    if (substr($ipBin, 0, $bytes) !== substr($netBin, 0, $bytes)) return false;
    $rest = $bits % 8;
    if ($rest === 0) return true;
    $mask = chr((0xFF << (8 - $rest)) & 0xFF);
    return (($ipBin[$bytes] & $mask) === ($netBin[$bytes] & $mask));
}

/**
 * The visitor's real address. Behind Cloudflare every request arrives from a Cloudflare
 * address, which would make every visitor look like one and let one abuser lock everyone
 * out of a rate limit. Cloudflare passes the visitor's address in CF-Connecting-IP, but that
 * header is believed only when the request really came from Cloudflare's network: from
 * anywhere else, anyone could send it to choose their own address and dodge the limits.
 */
function clientIp(): string
{
    $remote = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $claimed = trim((string)($_SERVER['HTTP_CF_CONNECTING_IP'] ?? ''));
    if ($claimed === '' || filter_var($claimed, FILTER_VALIDATE_IP) === false) return $remote;
    // The settings already loaded by the entry script (index.php, the cron jobs). Loading the
    // file again here would redeclare its helper functions and stop the request.
    $extra = (array)(($GLOBALS['config'] ?? [])['trusted_proxy_ranges'] ?? []);
    $ranges = array_merge(CLOUDFLARE_RANGES, $extra);
    foreach ($ranges as $range) {
        if (ipInRange($remote, (string)$range)) return $claimed;
    }
    return $remote;
}

function throttleClientFingerprint(): string
{
    $ip = clientIp();
    $agent = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 120);
    return $ip . '|' . $agent;
}

function throttleClientHash(array $config): string
{
    return throttleScopeKey($config, 'client', 'fingerprint', throttleClientFingerprint());
}

/** Writes one line to the security log. Never throws - logging must not break a request. */
function securityLog(PDO $pdo, array $config, string $type, string $severity = 'info',
                     ?string $action = null, ?string $detail = null, ?int $userId = null): void
{
    try {
        if (!throttleEnsureTables($pdo)) return;
        $pdo->prepare('INSERT INTO security_events (event_type, action, severity, client_hash, user_id, detail, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, NOW())')
            ->execute([$type, $action, $severity, throttleClientHash($config), $userId,
                       $detail !== null ? mb_substr($detail, 0, 300) : null]);
    } catch (Throwable $e) {
        error_log('securityLog failed: ' . $e->getMessage());
    }
}

/**
 * Refuses the request when either counter is over its limit. Call before doing the work,
 * so a blocked attempt costs nothing and reveals nothing about whether the target exists.
 */
function throttleCheck(PDO $pdo, array $config, string $action, string $subject): void
{
    if (!throttleEnsureTables($pdo)) return;
    try {
        [, , $window, ] = THROTTLE_RULES[$action] ?? THROTTLE_DEFAULT;
    
        // Stale rows are cleared here rather than by a cron: these endpoints are the only
        // things that read the table, so they are the natural place to tidy it.
        $pdo->prepare('DELETE FROM auth_attempts WHERE last_failure_at < DATE_SUB(NOW(), INTERVAL ? SECOND)
                       AND (locked_until IS NULL OR locked_until < NOW())')->execute([$window]);
    
        $client = throttleClientFingerprint();
        $keys = [
            throttleScopeKey($config, $action, 'subject', $subject . '|' . $client),
            throttleScopeKey($config, $action, 'client', $client),
        ];
        $stmt = $pdo->prepare('SELECT locked_until FROM auth_attempts
                                WHERE scope_key IN (?, ?) AND locked_until IS NOT NULL AND locked_until > NOW()
                                ORDER BY locked_until DESC LIMIT 1');
        $stmt->execute($keys);
        if ($row = $stmt->fetch()) {
            $seconds = max(1, strtotime((string)$row['locked_until']) - time());
            $minutes = (int)ceil($seconds / 60);
            securityLog($pdo, $config, 'rate_limit_blocked', 'warning', $action, 'Request refused while locked out');
            header('Retry-After: ' . $seconds);
            respond(429, [
                'error' => "Too many attempts. Please try again in {$minutes} minute" . ($minutes === 1 ? '' : 's') . '.',
                'reason' => 'rate_limited',
            ]);
        }
    } catch (Throwable $e) {
        // Bookkeeping must never be the reason a member cannot sign in.
        error_log('throttleCheck failed: ' . $e->getMessage());
    }
}

function throttleFailure(PDO $pdo, array $config, string $action, string $subject): void
{
    if (!throttleEnsureTables($pdo)) return;
    try {
        [$subjectLimit, $clientLimit, $window, $lock] = THROTTLE_RULES[$action] ?? THROTTLE_DEFAULT;
        $client = throttleClientFingerprint();
    
        foreach ([['subject', $subject . '|' . $client, $subjectLimit], ['client', $client, $clientLimit]] as [$scope, $value, $limit]) {
            $key = throttleScopeKey($config, $action, $scope, $value);
            $pdo->prepare(
                'INSERT INTO auth_attempts (scope_key, action, failures, first_failure_at, last_failure_at)
                 VALUES (?, ?, 1, NOW(), NOW())
                 ON DUPLICATE KEY UPDATE
                   failures = IF(first_failure_at < DATE_SUB(NOW(), INTERVAL ? SECOND), 1, failures + 1),
                   first_failure_at = IF(first_failure_at < DATE_SUB(NOW(), INTERVAL ? SECOND), NOW(), first_failure_at),
                   last_failure_at = NOW()'
            )->execute([$key, $action, $window, $window]);
    
            $locked = $pdo->prepare('UPDATE auth_attempts SET locked_until = DATE_ADD(NOW(), INTERVAL ? SECOND)
                                      WHERE scope_key = ? AND failures >= ? AND (locked_until IS NULL OR locked_until < NOW())');
            $locked->execute([$lock, $key, $limit]);
            if ($locked->rowCount() > 0) {
                securityLog($pdo, $config, 'lockout', $scope === 'client' ? 'critical' : 'warning', $action,
                    $scope === 'client'
                        ? 'Client locked out after repeated failures across multiple targets'
                        : 'Target locked out after repeated failures');
            }
        }
        securityLog($pdo, $config, 'failed_attempt', 'info', $action);
    } catch (Throwable $e) {
        // Bookkeeping must never be the reason a member cannot sign in.
        error_log('throttleFailure failed: ' . $e->getMessage());
    }
}

/** A success clears the subject counter. The client counter survives, so a spray is not
 *  reset by happening to guess one account correctly. */
function throttleSuccess(PDO $pdo, array $config, string $action, string $subject): void
{
    if (!throttleEnsureTables($pdo)) return;
    try {
        $pdo->prepare('DELETE FROM auth_attempts WHERE scope_key = ?')
            ->execute([throttleScopeKey($config, $action, 'subject', $subject . '|' . throttleClientFingerprint())]);
    } catch (Throwable $e) {
        // Bookkeeping must never be the reason a member cannot sign in.
        error_log('throttleSuccess failed: ' . $e->getMessage());
    }
}

/* Names kept from when this only guarded login, so the login route reads plainly. */
function authThrottleCheck(PDO $pdo, array $config, string $email): void
{
    throttleCheck($pdo, $config, 'login', $email);
}

function authThrottleFailure(PDO $pdo, array $config, string $email): void
{
    throttleFailure($pdo, $config, 'login', $email);
}

function authThrottleSuccess(PDO $pdo, array $config, string $email): void
{
    throttleSuccess($pdo, $config, 'login', $email);
    securityLog($pdo, $config, 'login_success', 'info', 'login');
}
