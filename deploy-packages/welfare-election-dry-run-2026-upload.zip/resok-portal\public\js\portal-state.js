(function () {
  const SELF_SRC = document.currentScript ? document.currentScript.src : "";
  const STORAGE_KEY = "resok_portal_state";
  const TOKEN_KEY = "token";
  const CARD_ASSET_VERSION = "20261021-silver";
  const CARD_LOGO_PATH = `assets/img/logo.png?v=${CARD_ASSET_VERSION}`;
  const CARD_FONT_PATH = `assets/fonts/montserrat-600-latin.woff2?v=${CARD_ASSET_VERSION}`;
  const CARD_BARCODE_PATH = `js/vendor/jsbarcode-code128-3.11.6.js?v=${CARD_ASSET_VERSION}`;

  function defaultState() {
    return {
      loggedIn: false,
      token: "",
      member: {
        title: "",
        firstName: "",
        middleName: "",
        surname: "",
        email: "",
        mobile: "",
        country: "",
        county: "",
        division: "",
        category: "",
        idType: "",
        idNumber: "",
        profileImage: "",
        profileImageUrl: "",
        membershipId: "",
        status: "payment_required",
        cpdPoints: 0,
        renewalDue: "Pending payment"
      },
      payments: []
    };
  }

  function getState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return Object.assign(defaultState(), saved || {});
    } catch {
      return defaultState();
    }
  }

  function saveState(state) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return state;
  }

  function token() {
    return localStorage.getItem(TOKEN_KEY) || getState().token || "";
  }

  function pageName() {
    return (window.location.pathname.split("/").pop() || "index").replace(/\.html$/i, "");
  }

  function isLocalPreview() {
    return ["localhost", "127.0.0.1", ""].includes(window.location.hostname) || window.location.protocol === "file:";
  }

  function ensureLocalPreviewSession() {
    const state = getState();
    if (state.loggedIn) return state;
    state.loggedIn = true;
    state.member = Object.assign({}, state.member, {
      firstName: state.member.firstName || "Local",
      surname: state.member.surname || "Preview",
      email: state.member.email || "local.preview@resok.test",
      category: state.member.category || "Demo Member",
      status: state.member.status || "payment_required"
    });
    return saveState(state);
  }

  function apiUrl(path) {
    const route = String(path || "").replace(/^\/api\/?/, "").replace(/^\/+/, "");
    return `api/index.php?route=${encodeURIComponent(route).replace(/%2F/g, "/")}`;
  }

  // "Verifying your browser" (js/proof.js, api/lib/proof.php). Loaded only the first time
  // the server asks for it, so pages pay nothing while the check is off.
  let proofLoading = null;
  function loadProof() {
    if (window.ResokProof) return Promise.resolve(window.ResokProof);
    if (!proofLoading) {
      proofLoading = new Promise((resolve) => {
        const s = document.createElement("script");
        s.src = new URL("proof.js?v=20261017-proof", SELF_SRC || location.href).href;
        s.onload = () => resolve(window.ResokProof || null);
        s.onerror = () => { proofLoading = null; resolve(null); };
        document.head.appendChild(s);
      });
    }
    return proofLoading;
  }
  async function proofFetch(url, init) {
    const first = await fetch(url, init);
    if (first.status !== 428) return first;
    const proof = await loadProof();
    return proof ? proof.fetch(url, init) : first;
  }

  async function api(path, options = {}) {
    const headers = Object.assign({}, options.headers || {});
    if (!(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
    // Session lives in the httpOnly resok_token cookie (sent automatically via
    // credentials:"same-origin"); the Authorization header is only a fallback for any
    // caller that still has a token in localStorage from before this change.
    if (token()) headers.Authorization = `Bearer ${token()}`;

    const response = await proofFetch(apiUrl(path), Object.assign({ credentials: "same-origin" }, options, { headers }));
    let data = null;
    try {
      data = await response.json();
    } catch {
      data = null;
    }
    if (!response.ok) {
      // The server ends a session after 20 minutes with no authenticated request. When that
      // lands mid-page, tear the local session down and send the member to login with an
      // explanation, rather than surfacing a bare "request failed" on whatever they clicked.
      if (response.status === 401 && data?.reason === "idle") endSessionForInactivity();
      // Ended on the server: logged out on this device, a password reset, or a role change.
      if (response.status === 401 && data?.reason === "revoked") endSessionRevoked();
      // A staff account without two-factor is held at the setup page. The server refuses
      // everything else until it is on, so send them where they can finish it.
      if (response.status === 403 && data?.mfaSetupRequired && pageName() !== "two-factor-setup") {
        window.location.href = "two-factor-setup";
      }
      // A staff session refused for where it is (api/lib/staff-geo.php): the login page
      // explains and lets them ask ICT. The server has already ended the session.
      if (response.status === 403 && data?.geoBlocked && pageName() !== "login") {
        try { sessionStorage.setItem("resok_geo", JSON.stringify(data)); } catch { /* private mode */ }
        window.location.href = "login?blocked=geo";
      }
      // The status travels with the error. Without it every caller has to guess what went
      // wrong from the wording of a message written for a human, and "not signed in" and
      // "the server is not there" are opposite problems that need opposite handling.
      const failure = new Error(data?.error || data?.message || "Request failed");
      failure.status = response.status;
      failure.payload = data;
      throw failure;
    }
    if (data === null || typeof data !== "object") {
      const failure = new Error("The portal server did not return a valid response. Please open the portal and sign in again.");
      failure.status = response.status;
      failure.code = "INVALID_API_RESPONSE";
      throw failure;
    }
    return data;
  }

  function memberName(member = getState().member) {
    return [member.title, member.firstName, member.middleName, member.surname]
      .filter(Boolean)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function initials(member = getState().member) {
    const source = `${member.firstName || "ReSoK"} ${member.surname || "Member"}`;
    return source
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0].toUpperCase())
      .join("");
  }

  function avatarUrl(member = getState().member, size = 128) {
    if (member?.profileImageUrl) return member.profileImageUrl;
    const name = encodeURIComponent(memberName(member) || "ReSoK Member");
    return `https://ui-avatars.com/api/?name=${name}&background=00932e&color=fff&size=${size}`;
  }

  function mergeMemberFromApi(member) {
    if (!member) return getState();
    const state = getState();
    state.member = Object.assign({}, state.member, {
      id: member.id || state.member.id,
      userId: member.userId || state.member.userId,
      title: member.title || "",
      firstName: member.firstName || "",
      middleName: member.middleName || "",
      surname: member.surname || "",
      profession: member.profession || "",
      specialization: member.specialization || "",
      institution: member.institution || "",
      country: member.country || "",
      county: member.county || "",
      division: member.division || "",
      physicalAddress: member.physicalAddress || "",
      payerType: member.payerType || "Individual",
      category: member.category || "",
      idType: member.idType || "",
      idNumber: member.idNumber || "",
      mobile: member.mobile || "",
      profileImage: member.profileImage || "",
      profileImageUrl: member.profileImageUrl || "",
      membershipId: member.membershipId || "",
      status: member.membershipStatus || member.status || "payment_required",
      cpdPoints: Number(member.cpdPoints || 0),
      renewalDue: member.renewalDue || "Pending payment",
      memberSince: member.memberSince || "",
      reviewReason: member.reviewReason || ""
    });
    return saveState(state);
  }

  function normalizePayment(payment) {
    const dateSource = payment.date || payment.createdAt || "";
    return {
      id: payment.id,
      createdAt: dateSource,
      date: dateSource ? new Date(dateSource).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "",
      reference: payment.reference || "",
      amount: Number(payment.amount || 0),
      method: payment.method || "M-Pesa Paybill",
      status: payment.status === "paid" ? "Paid" : payment.status === "failed" ? "Failed" : "Pending",
      phone: payment.phone || "",
      type: payment.type || "Membership"
    };
  }

  async function refreshFromApi() {
    // No client-readable flag proves a cookie session exists (it's httpOnly), so this
    // always attempts the call; the server 401s if there is no valid resok_token cookie.
    const [member, payments] = await Promise.all([api("/api/members/me"), api("/api/payments")]);
    const state = mergeMemberFromApi(member);
    state.payments = Array.isArray(payments) ? payments.map(normalizePayment) : [];
    return saveState(state);
  }

  function login(email, user) {
    // The session now lives in the httpOnly resok_token cookie the server just set
    // (issueAuthCookie in index.php) — it's deliberately not stored in localStorage,
    // so it can't be read by any XSS in this page. state.loggedIn is just a UI hint.
    const state = getState();
    state.loggedIn = true;
    state.token = "";
    state.member.email = email || user?.email || state.member.email;
    state.member.role = user?.role || state.member.role || "member";
    state.member.membershipId = user?.membershipId || "";
    state.member.status = user?.membershipStatus || state.member.status;
    state.member.cpdPoints = Number(user?.cpdPoints || 0);
    return saveState(state);
  }

  // Pass { timedOut: true } for an inactivity logout so the login page can say why. Called
  // straight from click handlers in a few pages, hence the defensive check rather than a
  // destructured parameter - an Event object must not read as a timeout.
  function logout(options) {
    const timedOut = Boolean(options && options.timedOut === true);
    api("/api/auth/logout", { method: "POST" }).catch(() => {});
    localStorage.removeItem(TOKEN_KEY);
    try {
      localStorage.removeItem(ACTIVITY_KEY);
    } catch {
      /* private mode - nothing to clear */
    }
    const state = getState();
    state.loggedIn = false;
    state.token = "";
    saveState(state);
    window.location.href = timedOut ? "login?timeout=1" : "login";
  }

  const pageLoadedAt = Date.now();

  /**
   * The two fields the server screens on. Read at submit time, not page load, so a form left
   * open in a tab reports the dwell it actually had.
   *
   * Deliberately forgiving: if the honeypot input is missing from a page the object simply
   * carries an empty string, which passes. A screening signal that breaks a real member's
   * registration because of a markup change would cost far more than the spam it stops.
   */
  function screeningFields(form) {
    const scope = form || document;
    const trap = scope.querySelector('input[name="website"]');
    return {
      website: trap ? trap.value : "",
      formLoadedAt: pageLoadedAt
    };
  }

  async function registerMember(data) {
    const result = await api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify(Object.assign({}, data, screeningFields()))
    });
    if (result.token) login(data.email, result.user, result.token);
    return result;
  }

  async function updateProfile(updates) {
    const member = await api("/api/members/me", {
      method: "PATCH",
      body: JSON.stringify(updates)
    });
    return mergeMemberFromApi(member);
  }

  async function uploadProfileImage(file) {
    const form = new FormData();
    form.append("profileImage", file);
    const member = await api("/api/members/me/profile-image", { method: "POST", body: form });
    return mergeMemberFromApi(member);
  }

  async function uploadPaymentProof({ amount, phone, type, paymentMode, mpesaCode, proof }) {
    if (!proof) throw new Error("Please upload proof of payment.");
    const form = new FormData();
    form.append("amount", amount);
    form.append("phone", phone || "");
    form.append("type", type || "Membership Registration");
    form.append("paymentMode", paymentMode || "M-PESA Paybill");
    form.append("mpesaCode", mpesaCode || "");
    form.append("proof", proof);
    const result = await api("/api/payments/proof", { method: "POST", body: form });
    if (result.member) mergeMemberFromApi(result.member);
    await refreshFromApi();
    return result;
  }

  async function paymentInstructions() {
    return api("/api/payment-instructions");
  }

  async function initiateStkPush({ amount, phone, type }) {
    return api("/api/payments/stk-push", {
      method: "POST",
      body: JSON.stringify({ amount, phone, type })
    });
  }

  async function paymentStatus(paymentId) {
    return api(`/api/payments/${paymentId}/status`);
  }

  async function pollPaymentStatus(paymentId, { intervalMs = 3000, timeoutMs = 60000 } = {}) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const result = await paymentStatus(paymentId);
      if (result.status === "paid" || result.status === "failed") return result;
      await new Promise((resolve) => setTimeout(resolve, intervalMs));
    }
    return { status: "pending", timedOut: true };
  }

  async function cpdLedger() {
    return api("/api/cpd/me");
  }

  async function listEvents() {
    return api("/api/events");
  }

  /* ---------------------------------------------------------------------------------
   * Two-factor authentication. The password step and the code step are separate requests;
   * the challenge returned by login proves the first passed and nothing more.
   * --------------------------------------------------------------------------------- */
  function resendVerification(email) {
    return api("/api/auth/resend-verification", {
      method: "POST",
      body: JSON.stringify({ email })
    });
  }

  function mfaStatus() {
    return api("/api/auth/mfa/status");
  }

  function mfaBeginSetup() {
    return api("/api/auth/mfa/setup", { method: "POST" });
  }

  function mfaConfirmSetup(code) {
    return api("/api/auth/mfa/enable", { method: "POST", body: JSON.stringify({ code }) });
  }

  function mfaDisable(password) {
    return api("/api/auth/mfa/disable", { method: "POST", body: JSON.stringify({ password }) });
  }

  async function mfaVerifyLogin(challenge, code) {
    const result = await api("/api/auth/mfa/verify", {
      method: "POST",
      body: JSON.stringify({ challenge, code })
    });
    login(result.user?.email || "", result.user);
    return result;
  }

  async function registerForEvent(eventId) {
    return api(`/api/events/${eventId}/register`, { method: "POST" });
  }

  /**
   * The resok_token session cookie is httpOnly, so this page can't just read a flag to
   * know if it's logged in — it has to ask the server. Callers must await this and stop
   * if it resolves false (a redirect to login is already underway in that case).
   */
  async function requireAuthForProtectedPage() {
    const page = pageName();
    const protectedPages = new Set(["dashboard", "profile", "payment", "card", "financials", "events"]);
    if (!protectedPages.has(page)) return true;
    if (isLocalPreview()) {
      ensureLocalPreviewSession();
      return true;
    }
    try {
      const me = await api("/api/members/me");
      // An Academy learner has an account but no membership record, so the member pages have
      // nothing to show them - they are sent to the Academy. Not while the Academy is still
      // locked, though: the lock sends visitors back to the dashboard, and the two redirects
      // would pass the learner between each other forever.
      if (!(me && me.id) && !LOCKED_FEATURES.includes("academy")) {
        window.location.replace("academy");
        return false;
      }
      startIdleWatch();
      return true;
    } catch {
      window.location.href = "login";
      return false;
    }
  }

  function hydrateShell() {
    const member = getState().member;
    document.querySelectorAll(".user-name").forEach((el) => {
      el.textContent = memberName(member) || "Member";
    });
    document.querySelectorAll(".user-avatar").forEach((el) => {
      if (member.profileImageUrl) {
        el.textContent = "";
        el.style.backgroundImage = `url("${member.profileImageUrl}")`;
        el.style.backgroundSize = "cover";
        el.style.backgroundPosition = "center";
      } else {
        el.textContent = initials(member);
        el.style.backgroundImage = "";
      }
    });
  }

  function absoluteAssetUrl(path) {
    try {
      return new URL(path, window.location.href).href;
    } catch {
      return path;
    }
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async function imageToDataUrl(src) {
    if (!src) return "";
    const response = await fetch(absoluteAssetUrl(src), { credentials: "same-origin" });
    if (!response.ok) throw new Error("Could not load card image.");
    return blobToDataUrl(await response.blob());
  }

  // The card is drawn entirely in code - no background artwork - so everything a downloaded
  // copy needs is inlined: the logo, the number font and the barcode bars. Without that, a
  // saved card would open on the member's phone with a missing logo and a fallback font.
  function loadScriptOnce(src, globalName) {
    if (window[globalName]) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = () => resolve();
      script.onerror = () => reject(new Error("Could not load card component."));
      document.head.appendChild(script);
    });
  }

  async function membershipCardImageAssets() {
    const [logo, font] = await Promise.all([
      imageToDataUrl(CARD_LOGO_PATH).catch(() => absoluteAssetUrl(CARD_LOGO_PATH)),
      imageToDataUrl(CARD_FONT_PATH).catch(() => ""),
      loadScriptOnce(absoluteAssetUrl(CARD_BARCODE_PATH), "JsBarcode").catch(() => null)
    ]);
    return { logo, font };
  }

  // "28 FEB 2027" rather than 02/27, which reads as a different date in different places.
  function cardDateLabel(value) {
    const match = String(value || "").trim().match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!match) return "—";
    const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
    return `${Number(match[3])} ${months[Number(match[2]) - 1]} ${match[1]}`;
  }

  // Title, first name, middle initials, surname - "DR AMANI K. ODHIAMBO".
  function cardName(member) {
    const middle = String(member.middleName || "").split(/\s+/).filter(Boolean).map((part) => `${part[0]}.`).join(" ");
    return [member.title, member.firstName, middle, member.surname].filter(Boolean).join(" ").replace(/\s+/g, " ").trim() || "ReSoK Member";
  }

  // A small seeded generator: the same membership number always grows the same airway tree,
  // and no two numbers grow the same one.
  function cardSeed(text) {
    let h = 1779033703 ^ text.length;
    for (let i = 0; i < text.length; i++) { h = Math.imul(h ^ text.charCodeAt(i), 3432918353); h = h << 13 | h >>> 19; }
    return () => { h = Math.imul(h ^ h >>> 16, 2246822507); h = Math.imul(h ^ h >>> 13, 3266489909); return ((h ^= h >>> 16) >>> 0) / 4294967296; };
  }

  /**
   * Draws a member's silver e-card: an engraved sea of wave bands, a ribbon carrying the
   * Society's vision, an engraved pair of lungs whose airway tree is grown from the
   * membership number, and a Code 128 barcode of that number.
   *
   * Every id is prefixed, because the card sits inline on pages that have ids of their own.
   */
  function membershipCardSvg(member = getState().member, assets = {}) {
    const esc = (value) => String(value || "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[char]));
    const SANS = "'Segoe UI', Arial, sans-serif";
    const NUM = "ResokCardNum, Montserrat, 'Segoe UI', Arial, sans-serif";
    const INK = "#3a4247", LABEL = "#5e686d", ETCH = "#8a959b";
    const P = "rcard-";
    const membershipId = member.membershipId || "Pending";
    const name = esc(cardName(member).toUpperCase());
    const category = esc((member.category || "Member").toUpperCase());
    const since = esc(member.memberSince || "—");
    const validThru = esc(cardDateLabel(member.renewalDue));
    const micro = esc(`RESPIRATORY SOCIETY OF KENYA ✦ ${membershipId.toUpperCase()} ✦ `);
    const rand = cardSeed(membershipId);
    const fit = (text, size, maxWidth, ratio, spacing = 0) => {
      let px = size;
      while (px > 16 && text.length * px * ratio + (text.length - 1) * spacing > maxWidth) px -= 1;
      return px;
    };
    const line = (points) => points.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`).join(" ");
    const range = (from, to, step) => { const out = []; for (let v = from; v <= to; v += step) out.push(v); return out; };

    // Engraved sea: each band is painted over the one above, so the crests overlap.
    let sea = "";
    const seaXs = range(-20, 1032, 8);
    for (let row = -1; row < 638 / 36 + 2; row++) {
      const y0 = row * 36, ph = row * 1.7, wl = 120 + (row % 3) * 18, amp = 12 + (row % 2) * 4;
      const at = (x, k) => y0 + k * 4.2 + Math.sin(x / wl * Math.PI * 2 + ph) * amp * (1 - k * .04);
      sea += `<path d="${line(seaXs.map((x) => [x, at(x, 0)]))} L1032 ${y0 + 90} L-20 ${y0 + 90} Z" fill="url(#${P}metal)"/>`;
      for (let k = 0; k < 9; k++) {
        sea += `<path d="${line(seaXs.map((x) => [x, at(x, k)]))}" fill="none" stroke="${k % 2 ? ETCH : "#ffffff"}" stroke-width="${k % 2 ? .8 : 1.2}" opacity="${k % 2 ? .45 : .85}"/>`;
      }
    }

    // The ribbon, and the Society's vision engraved along it.
    const top = (x) => 152 + Math.sin(x / 150 + .6) * 18 - x * .035;
    const rx = range(-20, 720, 8);
    const edgeT = line(rx.map((x) => [x, top(x)]));
    const edgeB = line(rx.map((x) => [x, top(x) + 50]));
    const ribbonShape = `${edgeT} ${rx.slice().reverse().map((x) => `L${x} ${(top(x) + 50).toFixed(1)}`).join(" ")} Z`;
    const stripes = range(-20, 720, 2.6).map((x) => `<line x1="${x.toFixed(1)}" y1="${top(x).toFixed(1)}" x2="${(x - 7).toFixed(1)}" y2="${(top(x) + 50).toFixed(1)}" stroke="${INK}" stroke-width=".6" opacity=".38"/>`).join("");
    const vision = "HEALTHY LUNGS FOR ALL PEOPLE IN KENYA AND BEYOND";
    const visionText = (fill, shift) => `<text font-family="${NUM}" font-size="17" font-weight="600" letter-spacing="2.2" text-anchor="middle"${shift}><textPath href="#${P}ribbonText" startOffset="52%" fill="${fill}">${vision}</textPath></text>`;

    // Engraved lungs: outline, hatched shading, windpipe rings and the member's airway tree.
    const leftLung = "M-70 165 C-140 150 -215 250 -240 380 C-262 480 -262 560 -235 585 C-190 602 -110 576 -52 592 C-38 520 -36 330 -44 250 C-48 205 -54 178 -70 165 Z";
    const rightLung = "M70 165 C140 150 215 250 240 380 C262 480 262 560 235 585 C190 602 120 580 78 592 C96 522 58 462 46 400 C38 330 48 205 70 165 Z";
    const lungPaths = typeof Path2D === "function" ? [new Path2D(leftLung), new Path2D(rightLung)] : [];
    const probe = document.createElement("canvas").getContext("2d");
    const inLung = (x, y) => !lungPaths.length || lungPaths.some((p) => probe.isPointInPath(p, x, y));
    const hatch = range(140, 610, 4.4).map((y) => `<path d="${line(range(-270, 270, 8).map((x) => [x, y + Math.sin(x / 28 + y / 40) * 3 + Math.abs(x) * .05]))}" fill="none" stroke="${INK}" stroke-width="1"/>`).join("");
    let tree = "";
    const seg = (x1, y1, x2, y2, w) => { tree += `<path d="M${x1.toFixed(1)} ${y1.toFixed(1)} L${x2.toFixed(1)} ${y2.toFixed(1)}" stroke="#ffffff" stroke-width="${w.toFixed(2)}" stroke-linecap="round"/>`; };
    const branch = (x, y, angle, len, w, depth) => {
      if (depth > 7 || len < 8) return;
      const a = angle * Math.PI / 180, x2 = x + Math.cos(a) * len, y2 = y + Math.sin(a) * len;
      if (depth > 1 && !inLung(x2, y2)) return;
      seg(x, y, x2, y2, w);
      const spread = 18 + rand() * 14, pull = (90 - angle) * .15;
      branch(x2, y2, angle - spread + pull, len * (.72 + rand() * .12), w * .72, depth + 1);
      branch(x2, y2, angle + spread + pull, len * (.72 + rand() * .12), w * .72, depth + 1);
    };
    seg(0, 236, -72, 296, 9); seg(0, 236, 72, 296, 9);
    branch(-72, 296, 112 + rand() * 10, 66, 6.5, 1); branch(72, 296, 68 - rand() * 10, 66, 6.5, 1);
    branch(-60, 286, 160 + rand() * 10, 44, 5, 2); branch(60, 286, 20 - rand() * 10, 44, 5, 2);
    branch(-52, 280, 232 + rand() * 12, 50, 5, 2); branch(52, 280, -52 - rand() * 12, 50, 5, 2);
    const rings = range(40, 231, 11).map((y) => `<path d="M-17 ${y} Q0 ${y + 6} 17 ${y}" fill="none" stroke="${INK}" stroke-width="2"/>`).join("");

    // Barcode of the membership number, drawn by JsBarcode when it loaded. A card without it
    // is still a valid card, so a failed load leaves the space empty rather than failing.
    let barcode = "";
    if (window.JsBarcode && member.membershipId) {
      try {
        const el = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        window.JsBarcode(el, membershipId.toUpperCase(), { format: "CODE128", displayValue: false, width: 1.7, height: 36, margin: 0, background: "transparent", lineColor: INK });
        const w = parseFloat(el.getAttribute("width")) || 0, x = 430 - w / 2;
        barcode = `<rect x="${(x - 10).toFixed(1)}" y="556" width="${(w + 20).toFixed(1)}" height="48" rx="6" fill="#ffffff" opacity=".7"/>
  <g transform="translate(${x.toFixed(1)} 562)">${el.innerHTML}</g>`;
      } catch (error) {
        console.warn("Card barcode skipped:", error.message);
      }
    }

    // Raised lettering: a light edge below and a dark edge above.
    const emboss = (x, y, text, attrs) => `<text x="${x + 1.2}" y="${y + 1.6}" ${attrs} fill="#ffffff" opacity=".95">${text}</text>
  <text x="${x - .8}" y="${y - 1}" ${attrs} fill="#000000" opacity=".22">${text}</text>
  <text x="${x}" y="${y}" ${attrs} fill="url(#${P}inkText)">${text}</text>`;

    const fontFace = assets.font ? `<style>@font-face{font-family:ResokCardNum;src:url(${assets.font}) format("woff2");font-weight:600;}</style>` : "";
    const logoSrc = esc(assets.logo || absoluteAssetUrl(CARD_LOGO_PATH));
    const nameSize = fit(name, 50, 840, .74, 2);

    return `<svg xmlns="http://www.w3.org/2000/svg" width="1012" height="638" viewBox="0 0 1012 638">
  ${fontFace}
  <defs>
    <linearGradient id="${P}metal" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="1012" y2="638">
      <stop offset="0" stop-color="#eef1f2"/><stop offset=".25" stop-color="#d3d9dc"/><stop offset=".45" stop-color="#f2f4f5"/>
      <stop offset=".7" stop-color="#c9d0d4"/><stop offset="1" stop-color="#e2e6e8"/>
    </linearGradient>
    <linearGradient id="${P}sheen" x1="0" y1="0" x2="1" y2=".65">
      <stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset=".26" stop-color="#ffffff" stop-opacity=".05"/><stop offset=".34" stop-color="#ffffff" stop-opacity=".6"/>
      <stop offset=".42" stop-color="#ffffff" stop-opacity=".05"/><stop offset=".55" stop-color="#9aa6ad" stop-opacity=".18"/><stop offset=".74" stop-color="#ffffff" stop-opacity=".35"/>
      <stop offset=".86" stop-color="#9aa6ad" stop-opacity=".12"/><stop offset="1" stop-color="#ffffff" stop-opacity=".2"/>
    </linearGradient>
    <linearGradient id="${P}inkText" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a6469"/><stop offset="1" stop-color="#2b3236"/></linearGradient>
    <linearGradient id="${P}ribbonFade" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".05" stop-color="#fff"/><stop offset=".94" stop-color="#fff"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
    <mask id="${P}ribbonMask"><rect x="-20" y="0" width="760" height="638" fill="url(#${P}ribbonFade)"/></mask>
    <clipPath id="${P}card"><rect width="1012" height="638" rx="36"/></clipPath>
    <clipPath id="${P}ribbonClip"><path d="${ribbonShape}"/></clipPath>
    <clipPath id="${P}lungClip"><path d="${leftLung}"/><path d="${rightLung}"/></clipPath>
    <path id="${P}ribbonText" d="${line(rx.map((x) => [x, top(x) + 35]))}"/>
    <path id="${P}micro" d="M927 22 L927 616"/>
  </defs>

  <g clip-path="url(#${P}card)">
    <rect width="1012" height="638" fill="url(#${P}metal)"/>
    <g opacity=".8">${sea}</g>
    <rect width="1012" height="638" fill="url(#${P}sheen)"/>
    <g mask="url(#${P}ribbonMask)">
      <path d="${ribbonShape}" fill="url(#${P}metal)"/>
      <g clip-path="url(#${P}ribbonClip)">${stripes}</g>
      <path d="${edgeT}" fill="none" stroke="#ffffff" stroke-width="2"/><path d="${edgeT}" fill="none" stroke="${INK}" stroke-width="1" opacity=".45" transform="translate(0 2.5)"/>
      <path d="${edgeB}" fill="none" stroke="${INK}" stroke-width="1.2" opacity=".5"/><path d="${edgeB}" fill="none" stroke="#ffffff" stroke-width="1.6" transform="translate(0 2)"/>
      ${visionText("#ffffff", "")}
      ${visionText("#4a5459", ' transform="translate(-1.2 -1.6)"')}
    </g>
    <g transform="translate(735 88) scale(.66)">
      <g opacity=".56"><g clip-path="url(#${P}lungClip)">${hatch}</g>
        <path d="${leftLung}" fill="none" stroke="${INK}" stroke-width="3"/><path d="${rightLung}" fill="none" stroke="${INK}" stroke-width="3"/>
        <path d="M-18 28 L-18 236 M18 28 L18 236" stroke="${INK}" stroke-width="3"/>${rings}</g>
      <path d="${leftLung}" fill="none" stroke="#ffffff" stroke-width="2" transform="translate(2 2.5)" opacity=".9"/>
      <path d="${rightLung}" fill="none" stroke="#ffffff" stroke-width="2" transform="translate(2 2.5)" opacity=".9"/>
      <g opacity=".95">${tree}</g>
      <g opacity=".45" transform="translate(-1.6 -2)">${tree.replace(/#ffffff/g, INK)}</g>
    </g>
  </g>
  <rect x="1.5" y="1.5" width="1009" height="635" rx="35" fill="none" stroke="#ffffff" stroke-width="2.5" opacity=".9"/>
  <rect x="1.5" y="1.5" width="1009" height="635" rx="35" fill="none" stroke="#9aa4a9" stroke-width="1" opacity=".6"/>

  <image href="${logoSrc}" x="44" y="34" width="330" height="88" preserveAspectRatio="xMinYMid meet"/>
  ${emboss(900, 95, "MEMBERSHIP CARD", `text-anchor="end" font-family="${SANS}" font-size="23" font-weight="700" letter-spacing="5"`)}

  <text x="60" y="242" font-family="${SANS}" font-size="16" font-weight="600" letter-spacing="3" fill="${LABEL}">MEMBERSHIP NO.</text>
  ${emboss(58, 306, esc(membershipId), `font-family="${NUM}" font-size="58" font-weight="600" letter-spacing="5"`)}
  <text x="60" y="370" font-family="${SANS}" font-size="14" font-weight="600" letter-spacing="3" fill="${LABEL}">MEMBER SINCE</text>
  ${emboss(60, 408, since, `font-family="${NUM}" font-size="32" font-weight="600" letter-spacing="2"`)}
  <text x="290" y="370" font-family="${SANS}" font-size="14" font-weight="600" letter-spacing="3" fill="${LABEL}">VALID THRU</text>
  ${emboss(290, 408, validThru, `font-family="${NUM}" font-size="32" font-weight="600" letter-spacing="2"`)}

  ${emboss(60, 500, name, `font-family="${NUM}" font-size="${nameSize}" font-weight="600" textLength="840" lengthAdjust="spacing"`)}
  ${barcode}
  <line x1="60" y1="548" x2="900" y2="548" stroke="#8a959b" stroke-width="1" opacity=".6"/>
  <line x1="60" y1="549.5" x2="900" y2="549.5" stroke="#ffffff" stroke-width="1" opacity=".9"/>
  <g font-family="${SANS}" font-size="16" font-weight="600" fill="${INK}">
    <text x="60" y="584">www.resok.org</text>
    <text x="900" y="584" text-anchor="end">+254 735 700 660  ·  info@resok.org</text>
  </g>

  <text font-family="${SANS}" font-size="7.6" font-weight="600" letter-spacing=".6" fill="#47527f"><textPath href="#${P}micro">${micro.repeat(5)}</textPath></text>
  ${emboss(962, 340, category, `transform="rotate(90 962 340)" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-size="${fit(category, 26, 440, .72, 6)}" letter-spacing="6"`)}
</svg>`;
  }

  // Saved as a PNG, which every phone opens; the SVG it is drawn from is the fallback.
  async function downloadMembershipCard(member = getState().member) {
    if (!member.membershipId) throw new Error("Membership code is not available yet.");
    const assets = await membershipCardImageAssets(member);
    const svg = membershipCardSvg(member, assets);
    const save = (href, ext) => {
      const link = document.createElement("a");
      link.href = href;
      link.download = `${member.membershipId}-membership-card.${ext}`;
      document.body.appendChild(link);
      link.click();
      link.remove();
    };
    const svgUrl = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
    try {
      const img = new Image();
      await new Promise((resolve, reject) => { img.onload = resolve; img.onerror = reject; img.src = svgUrl; });
      const canvas = document.createElement("canvas");
      canvas.width = 2024;
      canvas.height = 1276;
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      const png = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
      if (!png) throw new Error("PNG export failed");
      const pngUrl = URL.createObjectURL(png);
      save(pngUrl, "png");
      setTimeout(() => URL.revokeObjectURL(pngUrl), 1000);
    } catch {
      save(svgUrl, "svg");
    } finally {
      setTimeout(() => URL.revokeObjectURL(svgUrl), 1000);
    }
  }

  function currentDateLabel() {
    return new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  }

  function paymentNumber(payment, index = 0) {
    return payment.reference || payment.mpesaCode || `RESOK-${String(payment.id || index + 1).padStart(4, "0")}`;
  }

  function feeStatementSvg(member = getState().member, payments = getState().payments, options = {}) {
    const esc = (value) => String(value || "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[char]));
    const amountDue = Number(options.amountDue || member.membershipFee || 5000);
    // Confirmed payments only, matching the Financials page - a pending proof is not money received.
    const paidTotal = payments.filter((payment) => payment.status === "Paid")
      .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
    const balance = Math.max(amountDue - paidTotal, 0);
    const name = memberName(member) || "ReSoK Member";
    const rows = (payments.length ? payments : [{ date: "", reference: "No payment recorded", method: "", amount: 0, status: "Pending" }]).slice(0, 8).map((payment, index) => {
      const y = 366 + index * 46;
      return `<text x="72" y="${y}" font-family="Segoe UI, Arial, sans-serif" font-size="20" fill="#344054">${esc(payment.date || "-")}</text>
  <text x="250" y="${y}" font-family="Segoe UI, Arial, sans-serif" font-size="20" fill="#344054">${esc(paymentNumber(payment, index))}</text>
  <text x="516" y="${y}" font-family="Segoe UI, Arial, sans-serif" font-size="20" fill="#344054">${esc(payment.method || "-")}</text>
  <text x="838" y="${y}" text-anchor="end" font-family="Segoe UI, Arial, sans-serif" font-size="20" fill="#344054">KES ${Number(payment.amount || 0).toLocaleString()}</text>
  <line x1="60" y1="${y + 18}" x2="852" y2="${y + 18}" stroke="#e5e7eb"/>`;
    }).join("\n  ");
    return `<svg xmlns="http://www.w3.org/2000/svg" width="920" height="1040" viewBox="0 0 920 1040">
  <rect width="920" height="1040" fill="#ffffff"/>
  <rect x="0" y="0" width="920" height="126" fill="#00932e"/>
  <rect x="0" y="104" width="920" height="22" fill="#bc0b22"/>
  <text x="60" y="58" font-family="Segoe UI, Arial, sans-serif" font-size="31" font-weight="700" fill="#ffffff">Respiratory Society of Kenya</text>
  <text x="60" y="92" font-family="Segoe UI, Arial, sans-serif" font-size="17" fill="#ffffff">Member Fee Statement</text>
  <text x="860" y="56" text-anchor="end" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#ffffff">${esc(currentDateLabel())}</text>
  <text x="60" y="184" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#667085">Member</text>
  <text x="60" y="222" font-family="Segoe UI, Arial, sans-serif" font-size="30" font-weight="700" fill="#253141">${esc(name)}</text>
  <text x="60" y="258" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#667085">Membership ID: ${esc(member.membershipId || "Pending")} | Category: ${esc(member.category || "Member")}</text>
  <rect x="60" y="294" width="792" height="72" rx="8" fill="#f8fafc" stroke="#e5e7eb"/>
  <text x="96" y="326" font-family="Segoe UI, Arial, sans-serif" font-size="15" font-weight="700" fill="#667085">AMOUNT DUE</text>
  <text x="96" y="352" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="700" fill="#253141">KES ${amountDue.toLocaleString()}</text>
  <text x="376" y="326" font-family="Segoe UI, Arial, sans-serif" font-size="15" font-weight="700" fill="#667085">TOTAL PAID</text>
  <text x="376" y="352" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="700" fill="#00932e">KES ${paidTotal.toLocaleString()}</text>
  <text x="654" y="326" font-family="Segoe UI, Arial, sans-serif" font-size="15" font-weight="700" fill="#667085">BALANCE</text>
  <text x="654" y="352" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="700" fill="#bc0b22">KES ${balance.toLocaleString()}</text>
  <text x="72" y="326" opacity="0">.</text>
  <text x="72" y="416" font-family="Segoe UI, Arial, sans-serif" font-size="16" font-weight="700" fill="#667085">DATE</text>
  <text x="250" y="416" font-family="Segoe UI, Arial, sans-serif" font-size="16" font-weight="700" fill="#667085">REFERENCE</text>
  <text x="516" y="416" font-family="Segoe UI, Arial, sans-serif" font-size="16" font-weight="700" fill="#667085">METHOD</text>
  <text x="838" y="416" text-anchor="end" font-family="Segoe UI, Arial, sans-serif" font-size="16" font-weight="700" fill="#667085">AMOUNT</text>
  <line x1="60" y1="432" x2="852" y2="432" stroke="#cbd5e1"/>
  <g transform="translate(0 88)">${rows}</g>
  <text x="60" y="968" font-family="Segoe UI, Arial, sans-serif" font-size="16" fill="#667085">Generated from the ReSoK Members' Portal.</text>
</svg>`;
  }

  function receiptSvg(payment, member = getState().member, index = 0) {
    const esc = (value) => String(value || "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[char]));
    const amount = Number(payment?.amount || 0);
    const reference = paymentNumber(payment || {}, index);
    return `<svg xmlns="http://www.w3.org/2000/svg" width="1040" height="720" viewBox="0 0 1040 720">
  <rect width="1040" height="720" fill="#ffffff"/>
  <rect x="58" y="48" width="924" height="624" fill="#ffffff" stroke="#d0d5dd" stroke-width="2"/>
  <text x="92" y="104" font-family="Segoe UI, Arial, sans-serif" font-size="28" font-weight="700" fill="#00932e">ReSoK</text>
  <text x="194" y="88" font-family="Segoe UI, Arial, sans-serif" font-size="15" font-weight="700" fill="#253141">RESPIRATORY</text>
  <text x="194" y="108" font-family="Segoe UI, Arial, sans-serif" font-size="15" font-weight="700" fill="#253141">SOCIETY OF KENYA</text>
  <text x="92" y="170" font-family="Segoe UI, Arial, sans-serif" font-size="30" font-weight="700" fill="#253141">PAYMENT RECEIPT</text>
  <text x="716" y="92" font-family="Segoe UI, Arial, sans-serif" font-size="16" fill="#667085">Receipt No.</text>
  <rect x="814" y="66" width="124" height="42" fill="#ffffff" stroke="#e89aaa" stroke-width="2"/>
  <text x="876" y="94" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="18" font-weight="700" fill="#253141">${esc(reference)}</text>
  <text x="716" y="150" font-family="Segoe UI, Arial, sans-serif" font-size="16" fill="#667085">Date</text>
  <rect x="814" y="124" width="124" height="42" fill="#ffffff" stroke="#e89aaa" stroke-width="2"/>
  <text x="876" y="152" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="15" font-weight="700" fill="#253141">${esc(payment?.date || currentDateLabel())}</text>
  <text x="92" y="244" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#667085">Received from:</text>
  <text x="248" y="244" font-family="Segoe UI, Arial, sans-serif" font-size="23" font-weight="700" fill="#253141">${esc(memberName(member) || "ReSoK Member")}</text>
  <line x1="248" y1="254" x2="920" y2="254" stroke="#d0d5dd"/>
  <text x="92" y="314" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#667085">Being payment of:</text>
  <text x="292" y="314" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="700" fill="#253141">${esc(payment?.type || "Membership Registration / Renewal")}</text>
  <line x1="292" y1="324" x2="920" y2="324" stroke="#d0d5dd"/>
  <text x="92" y="384" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#667085">Amount in words:</text>
  <text x="292" y="384" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="700" fill="#253141">Kenya Shillings ${amount.toLocaleString()} only</text>
  <line x1="292" y1="394" x2="920" y2="394" stroke="#d0d5dd"/>
  <text x="92" y="470" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#667085">Payment Method:</text>
  <text x="292" y="470" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="700" fill="#253141">${esc(payment?.method || "M-Pesa Paybill")}</text>
  <text x="646" y="470" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#667085">Amount in Figures:</text>
  <rect x="814" y="438" width="124" height="48" fill="#ffffff" stroke="#d0d5dd" stroke-width="2"/>
  <text x="876" y="469" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="18" font-weight="700" fill="#253141">${amount.toLocaleString()}</text>
  <text x="646" y="536" font-family="Segoe UI, Arial, sans-serif" font-size="18" fill="#667085">Ref No:</text>
  <rect x="814" y="506" width="124" height="48" fill="#ffffff" stroke="#d0d5dd" stroke-width="2"/>
  <text x="876" y="537" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="16" font-weight="700" fill="#253141">${esc(reference)}</text>
  <rect x="692" y="558" width="178" height="74" rx="6" fill="none" stroke="#1d4ed8" stroke-width="3" transform="rotate(-18 781 595)"/>
  <text x="780" y="590" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="19" font-weight="800" fill="#1d4ed8" transform="rotate(-18 780 590)">ReSoK PAID</text>
  <text x="92" y="626" font-family="Segoe UI, Arial, sans-serif" font-size="15" fill="#667085">This receipt was generated from the ReSoK Members' Portal.</text>
</svg>`;
  }

  function downloadSvg(svg, filename) {
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function downloadFeeStatement(options = {}) {
    const state = getState();
    const filenameId = state.member.membershipId || "resok-member";
    downloadSvg(feeStatementSvg(state.member, state.payments, options), `${filenameId}-fee-statement.svg`);
  }

  function downloadReceipt(paymentId) {
    const state = getState();
    const index = state.payments.findIndex((payment) => String(payment.id || payment.reference) === String(paymentId));
    // A receipt says PAID, so it exists only for a confirmed payment - never for a proof that
    // is still awaiting review, and never by falling back to whichever payment came first.
    const payment = index >= 0 ? state.payments[index] : null;
    if (!payment || payment.status !== "Paid") throw new Error("A receipt is available once the payment is confirmed.");
    downloadSvg(receiptSvg(payment, state.member, Math.max(index, 0)), `${paymentNumber(payment, Math.max(index, 0))}-receipt.svg`);
  }

  /* --------------------------------------------------------------------------
   * Inactivity timeout
   *
   * The server is what actually enforces this: auth() in the API rejects any token
   * whose last-activity stamp is over 20 minutes old, and member-gate.php applies the
   * same window to /learning. This is the browser half, which does three things the
   * server cannot:
   *
   *  - closes the session on schedule instead of leaving a signed-in page sitting open
   *    on a shared screen until someone happens to click something;
   *  - warns a minute before, so a half-filled form is not lost without notice;
   *  - keeps the server's window in step while the member is genuinely working - they
   *    can spend 25 minutes typing into a form without making a single API call, and
   *    without this their eventual save would be the request that gets rejected.
   * -------------------------------------------------------------------------- */
  const IDLE_TIMEOUT_MS = 20 * 60 * 1000;
  const IDLE_WARNING_MS = 60 * 1000;
  const IDLE_TICK_MS = 5 * 1000;
  const KEEPALIVE_MS = 5 * 60 * 1000;
  // In localStorage rather than a variable so that activity in any open portal tab counts
  // for all of them - otherwise a member working in one tab is logged out by an idle one.
  const ACTIVITY_KEY = "resok_last_activity";
  const ACTIVITY_EVENTS = ["mousedown", "keydown", "scroll", "touchstart", "click"];

  let idleTimer = null;
  let lastKeepAlive = 0;
  let warningEl = null;

  function lastActivityAt() {
    try {
      const saved = Number(localStorage.getItem(ACTIVITY_KEY));
      if (Number.isFinite(saved) && saved > 0) return saved;
    } catch {
      /* private mode - fall through to "active now" */
    }
    return Date.now();
  }

  function markActivity() {
    try {
      localStorage.setItem(ACTIVITY_KEY, String(Date.now()));
    } catch {
      /* private mode - the in-page timer below still works, just not across tabs */
    }
  }

  function hideIdleWarning() {
    if (!warningEl) return;
    warningEl.remove();
    warningEl = null;
  }

  function showIdleWarning(secondsLeft) {
    if (!warningEl) {
      warningEl = document.createElement("div");
      warningEl.setAttribute("role", "alertdialog");
      warningEl.setAttribute("aria-live", "assertive");
      // Styled inline: this has to look the same on all ten portal pages, and they do not
      // share a stylesheet beyond css/styles.css which not all of them load.
      warningEl.style.cssText =
        "position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:9999;" +
        "display:flex;align-items:center;gap:14px;max-width:min(440px,92vw);padding:14px 18px;" +
        "border-radius:10px;background:#fff;border:1px solid #e5e7eb;color:#253141;" +
        "box-shadow:0 18px 40px rgba(15,23,42,.18);font-family:'Segoe UI',Tahoma,sans-serif;font-size:14px";

      const text = document.createElement("span");
      text.style.cssText = "flex:1;line-height:1.45";

      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "Stay signed in";
      button.style.cssText =
        "flex-shrink:0;border:0;border-radius:6px;padding:9px 14px;background:#00932e;" +
        "color:#fff;font-weight:800;font-size:13px;cursor:pointer";
      button.addEventListener("click", () => {
        markActivity();
        keepServerSessionAlive(true);
        hideIdleWarning();
      });

      warningEl.append(text, button);
      document.body.appendChild(warningEl);
    }
    warningEl.firstChild.textContent = `You will be signed out in ${secondsLeft}s due to inactivity.`;
  }

  function keepServerSessionAlive(force) {
    if (!force && Date.now() - lastKeepAlive < KEEPALIVE_MS) return;
    lastKeepAlive = Date.now();
    // Any authenticated GET slides the server's window forward. members/me is the cheapest
    // one and works for admins too - it just answers with an empty object when the account
    // has no member profile.
    api("/api/members/me").catch(() => {});
  }

  function stopIdleWatch() {
    if (!idleTimer) return;
    clearInterval(idleTimer);
    idleTimer = null;
    ACTIVITY_EVENTS.forEach((type) => window.removeEventListener(type, markActivity));
  }

  // The server has already ended this session, so there is nothing to log out of - only the
  // page's own idea that someone is signed in, which would otherwise outlive it.
  function endSessionRevoked() {
    stopIdleWatch();
    hideIdleWarning();
    localStorage.removeItem(TOKEN_KEY);
    const state = getState();
    state.loggedIn = false;
    state.token = "";
    saveState(state);
    if (pageName() !== "login") window.location.href = "login";
  }

  function endSessionForInactivity() {
    stopIdleWatch();
    hideIdleWarning();
    logout({ timedOut: true });
  }

  function startIdleWatch() {
    // Local preview hands itself a session in ensureLocalPreviewSession(), so timing one
    // out would just loop; there is no server session to protect there anyway.
    if (idleTimer || isLocalPreview()) return;
    markActivity();
    ACTIVITY_EVENTS.forEach((type) => window.addEventListener(type, markActivity, { passive: true }));
    idleTimer = setInterval(() => {
      const idleFor = Date.now() - lastActivityAt();
      if (idleFor >= IDLE_TIMEOUT_MS) {
        endSessionForInactivity();
        return;
      }
      if (idleFor >= IDLE_TIMEOUT_MS - IDLE_WARNING_MS) {
        showIdleWarning(Math.max(1, Math.ceil((IDLE_TIMEOUT_MS - idleFor) / 1000)));
        return;
      }
      hideIdleWarning();
      keepServerSessionAlive(false);
    }, IDLE_TICK_MS);
  }

  // ----- Super-administrator member/staff previews (api/lib/view-as.php) ---------------
  // The server decides who each request acts as, from an httpOnly cookie this page cannot
  // read. This flag only tells pages to ask (view-as/status) and show the banner; it grants
  // nothing. The cached member in resok_portal_state is dropped on the way in and out, so
  // neither person's details are ever shown as the other's.
  const VIEW_AS_FLAG = "resok_viewas";
  const VIEW_AS_SYNC = "resok_viewas_sync";
  let viewAsReturnTo = "admin-review";
  let viewAsMemoryFlag = false;
  let viewAsSnapshot = null, viewAsStatusLoading = false, viewAsReloading = false;

  function notifyViewAsChanged() {
    try { localStorage.setItem(VIEW_AS_SYNC, Date.now() + ":" + Math.random().toString(36).slice(2)); } catch { /* Focus checks still work. */ }
  }
  function reloadViewAsPage() {
    if (!viewAsReloading) { viewAsReloading = true; window.location.reload(); }
  }

  function viewAsReturnPath(value, fallback = "admin-review") {
    const allowed = ["admin-review", "ict#staff", "staff#people"];
    return allowed.includes(value) ? value : (allowed.includes(fallback) ? fallback : "admin-review");
  }

  function viewAsFlag(on) {
    try {
      if (on === undefined) return localStorage.getItem(VIEW_AS_FLAG) === "1" || viewAsMemoryFlag;
      if (on) localStorage.setItem(VIEW_AS_FLAG, "1");
      else localStorage.removeItem(VIEW_AS_FLAG);
    } catch {
      /* The server status check still shows the banner when storage is unavailable. */
    }
    if (on !== undefined) viewAsMemoryFlag = Boolean(on);
    return viewAsMemoryFlag;
  }

  function resetCachedMember(email) {
    const state = defaultState();
    state.loggedIn = true;
    // The profile page shows the sign-in email from here; the member's, not the admin's.
    if (email) state.member.email = email;
    try { saveState(state); } catch { /* A blocked cache must not strand a server-side preview. */ }
  }

  async function viewAsStart(profileId) {
    const result = await api("/api/view-as/start", { method: "POST", body: JSON.stringify({ profileId }) });
    viewAsReturnTo = viewAsReturnPath(result.returnTo);
    viewAsFlag(true);
    resetCachedMember(result.email);
    notifyViewAsChanged();
    window.location.href = ["dashboard", "academy"].includes(result.goTo) ? result.goTo : "dashboard";
  }

  async function viewAsStaffStart(userId, returnTo = "ict#staff") {
    const target = Number(userId);
    if (!Number.isSafeInteger(target) || target <= 0) throw new Error("Choose a staff account to preview.");
    const result = await api("/api/view-as/start", {
      method: "POST", body: JSON.stringify({ userId: target, scope: "staff", returnTo: viewAsReturnPath(returnTo, "ict#staff") })
    });
    viewAsReturnTo = viewAsReturnPath(result.returnTo, returnTo);
    viewAsFlag(true);
    resetCachedMember(result.email);
    notifyViewAsChanged();
    window.location.href = "staff";
  }

  async function viewAsEnd() {
    const result = await api("/api/view-as/end", { method: "POST", body: "{}" });
    viewAsFlag(false);
    resetCachedMember();
    notifyViewAsChanged();
    window.location.href = result.targetUserId === null
      ? viewAsReturnPath(viewAsReturnTo)
      : viewAsReturnPath(result.returnTo, viewAsReturnTo);
  }

  async function showViewAsBanner() {
    // The cookie is shared across tabs and can outlive a page's local-storage flag.
    // Always check protected pages, including when browser storage is unavailable.
    const wasViewing = viewAsFlag();
    if (!wasViewing && ["login", "forgot-password", "index", "two-factor-setup"].includes(pageName())) return;
    if (viewAsStatusLoading) return;
    viewAsStatusLoading = true;
    let status = null;
    try {
      status = await api("/api/view-as/status");
    } catch {
      return;
    } finally {
      viewAsStatusLoading = false;
    }
    const snapshot = status?.active === true ? [status.scope || "member", status.targetUserId || status.profileId || status.email, status.targetSuperAdmin === true, status.endsAt].join(":") : "inactive";
    if (viewAsSnapshot !== null && snapshot !== viewAsSnapshot) { reloadViewAsPage(); return; }
    viewAsSnapshot = snapshot;
    if (!status || !status.active) {
      // Ended on its own (30 minutes, or the administrator signed out): forget it quietly.
      viewAsFlag(false);
      if (wasViewing) resetCachedMember();
      return;
    }
    if (document.getElementById("viewAsBanner")) return;
    viewAsFlag(true);
    viewAsReturnTo = viewAsReturnPath(status.returnTo);
    const staffPreview = status.scope === "staff";
    const style = document.createElement("style");
    style.textContent =
      "body.view-as-active{padding-top:var(--resok-view-as-height,64px)}" +
      "body.view-as-active .admin-topbar,body.view-as-active .topbar{top:var(--resok-view-as-height,64px)}" +
      "body.view-as-active .admin-body{min-height:calc(100vh - var(--resok-view-as-height,64px))}" +
      "body.view-as-active .admin-sidebar{top:calc(64px + var(--resok-view-as-height,64px))}" +
      "body.view-as-active .admin-sidebar-backdrop{inset:calc(64px + var(--resok-view-as-height,64px)) 0 0}" +
      "body.view-as-active .bell-panel{top:calc(72px + var(--resok-view-as-height,64px))}" +
      "body.view-as-active .dashboard-nav{top:var(--resok-view-as-height,64px)}" +
      "body.view-as-active .dashboard-sidebar:not(.admin-sidebar){top:calc(94px + var(--resok-view-as-height,64px))}";
    document.head.appendChild(style);
    const bar = document.createElement("div");
    bar.id = "viewAsBanner";
    bar.setAttribute("role", "status");
    bar.style.cssText =
      "position:fixed;top:0;left:0;right:0;z-index:10000;display:flex;align-items:center;gap:12px;flex-wrap:wrap;" +
      "padding:10px 16px;background:#bc0b22;color:#fff;font-family:'Segoe UI',Tahoma,sans-serif;font-size:14px;line-height:1.4;" +
      "box-shadow:0 2px 10px rgba(0,0,0,.2)";
    const text = document.createElement("span");
    text.style.cssText = "flex:1;min-width:220px;overflow-wrap:anywhere";
    const ends = new Date(status.endsAt * 1000).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
    const who = document.createElement("strong");
    who.textContent = status.name;
    text.append(staffPreview ? "Viewing staff portal as " : "Viewing the portal as ", who,
      staffPreview
        ? ` (${status.email}). Read-only preview using their permissions. No actions are submitted as them. Ends at ${ends}.`
        : ` (${status.email}). This is exactly what they see. Only their profile can be changed; every change is logged. Ends at ${ends}.`);
    const exit = document.createElement("button");
    exit.type = "button";
    exit.textContent = staffPreview ? "Return to my admin view" : "Exit view as";
    exit.style.cssText =
      "flex-shrink:0;border:0;border-radius:6px;padding:8px 14px;background:#fff;color:#bc0b22;font-weight:800;font-size:13px;cursor:pointer";
    exit.addEventListener("click", async () => {
      exit.disabled = true;
      try { await viewAsEnd(); }
      catch (error) {
        exit.disabled = false;
        let failure = document.getElementById("viewAsExitError");
        if (!failure) {
          failure = document.createElement("span"); failure.id = "viewAsExitError"; failure.setAttribute("role", "alert"); bar.appendChild(failure);
        }
        failure.textContent = error.message || "Could not exit the preview. Please try again.";
      }
    });
    bar.append(text, exit);
    document.body.prepend(bar);
    document.body.classList.add("view-as-active");
    const sizeBanner = () => document.documentElement.style.setProperty("--resok-view-as-height", Math.ceil(bar.getBoundingClientRect().height) + "px");
    sizeBanner();
    window.addEventListener("resize", sizeBanner);
    if (typeof ResizeObserver !== "undefined") new ResizeObserver(sizeBanner).observe(bar);
    const expiresIn = Number(status.endsAt) * 1000 - Date.now();
    if (staffPreview && Number.isFinite(expiresIn)) window.setTimeout(() => exit.click(), Math.max(0, expiresIn));
  }

  window.addEventListener("storage", (event) => {
    if (event.key === VIEW_AS_FLAG || event.key === VIEW_AS_SYNC) reloadViewAsPage();
  });
  window.addEventListener("focus", () => { if (document.readyState !== "loading") showViewAsBanner(); });
  document.addEventListener("visibilitychange", () => { if (!document.hidden && document.readyState !== "loading") showViewAsBanner(); });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", showViewAsBanner);
  } else {
    showViewAsBanner();
  }

  window.ResokPortal = {
    isFeatureLocked: (name) => LOCKED_FEATURES.includes(name),
    viewAsStart,
    viewAsStaffStart,
    viewAsEnd,
    api,
    proofFetch,
    screeningFields,
    apiUrl,
    getState,
    saveState,
    registerMember,
    login,
    logout,
    refreshFromApi,
    updateProfile,
    uploadProfileImage,
    uploadPaymentProof,
    paymentInstructions,
    initiateStkPush,
    paymentStatus,
    pollPaymentStatus,
    cpdLedger,
    listEvents,
    registerForEvent,
    resendVerification,
    mfaStatus,
    mfaBeginSetup,
    mfaConfirmSetup,
    mfaDisable,
    mfaVerifyLogin,
    requireAuthForProtectedPage,
    startIdleWatch,
    stopIdleWatch,
    hydrateShell,
    memberName,
    initials,
    avatarUrl,
    membershipCardImageAssets,
    membershipCardSvg,
    downloadMembershipCard,
    feeStatementSvg,
    receiptSvg,
    downloadFeeStatement,
    downloadReceipt
  };

  // Member features that are built but not launched yet. Their dashboard links are shown
  // greyed out, and opening one of these pages directly sends the visitor back to the
  // dashboard. To launch a feature, delete its name here and restore its link in
  // dashboard.html. Admins manage events and elections from admin-review and
  // election-admin, which are not affected.
  // On localhost nothing is locked, so every feature can be reviewed before launch.
  // The Virtual Academy launched 28 Sep 2026; events and elections are still to come.
  // The membership card, payment receipts and fee statement download were locked on
  // 15 Oct 2026 (receipts and statement are being redesigned). Their sidebar links on
  // every page are greyed out by lockSidebarLinks() below, so no page needs editing to
  // launch them. "statement" locks only the download button: the Financials page and
  // its Fee Statement link stay open for the balance summary.
  // "directory" greys out the Find a Specialist listing panel on the profile page (15 Oct 2026).
  const LOCKED_FEATURES = isLocalPreview() ? [] : ["events", "elections", "card", "receipts", "statement", "directory"];
  // Staff welfare elections share the elections page (elections?for=staff) but are not part
  // of the members' launch lock: without this, staff - and a super admin, who has no
  // membership for the dashboard to show - were sent dashboard -> Academy (27 Oct 2026).
  const staffElections = pageName() === "elections" && new URLSearchParams(location.search).get("for") === "staff";
  if (LOCKED_FEATURES.includes(pageName()) && !staffElections) {
    window.location.replace("dashboard");
  }

  function lockSidebarLinks() {
    LOCKED_FEATURES.forEach((name) => {
      document.querySelectorAll(`.sidebar a[href="${name}"], .sidebar a[href$="#${name}"]`).forEach((link) => {
        const item = document.createElement("span");
        item.className = "nav-locked";
        item.setAttribute("aria-disabled", "true");
        item.title = "Coming soon";
        item.style.cssText = "display:flex;align-items:center;gap:10px;padding:12px;border-radius:6px;color:#98a2b3;font-weight:600;font-size:14px;cursor:not-allowed;user-select:none;white-space:nowrap";
        item.innerHTML = `${link.innerHTML} <span class="soon" style="margin-left:auto;padding:2px 7px;border-radius:999px;background:#eef2f7;color:#667085;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.05em">Soon</span>`;
        link.replaceWith(item);
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", lockSidebarLinks);
  } else {
    lockSidebarLinks();
  }

  // Start the watch on any portal page that already believes it has a session. Protected
  // pages also call startIdleWatch() from requireAuthForProtectedPage() once the server has
  // confirmed the session; this covers the rest (admin-review, certificates) without each
  // page having to opt in. It is a no-op if already running.
  function autoStartIdleWatch() {
    if (["login", "forgot-password"].includes(pageName())) return;
    if (!getState().loggedIn) return;
    startIdleWatch();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", autoStartIdleWatch);
  } else {
    autoStartIdleWatch();
  }

  // The same aggregate election feed appears on signed-in portal pages.
  function loadWelfareFeed() {
    if (["login", "forgot-password", "index", "two-factor-setup"].includes(pageName())) return;
    if (document.getElementById("resokWelfareLoader")) return;
    const script = document.createElement("script");
    script.id = "resokWelfareLoader";
    script.src = new URL("welfare-live.js?v=20261103-welfare2", SELF_SRC || location.href).href;
    document.body.appendChild(script);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", loadWelfareFeed);
  else loadWelfareFeed();
})();
