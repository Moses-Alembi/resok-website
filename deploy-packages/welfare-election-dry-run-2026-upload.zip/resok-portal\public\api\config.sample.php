<?php
declare(strict_types=1);

return [
    'db_host' => 'localhost',
    'db_port' => 3306,
    'db_name' => 'resok_portal',
    'db_user' => 'resok_user',
    'db_pass' => 'replace_with_database_password',

    'jwt_secret' => 'replace_with_a_random_secret_of_at_least_32_characters',
    // To change jwt_secret without signing everyone out: put the old value here, the new one
    // above, and delete this line a week later.
    // 'jwt_secret_previous' => 'the_old_jwt_secret',
    'require_email_verification' => true,

    // SMTP is optional: leave smtp_host blank to fall back to PHP's mail().
    'smtp_host' => '',
    'smtp_port' => 587,
    'smtp_user' => '',
    'smtp_pass' => '',

    // M-Pesa Daraja STK push (required for the payment flow to work; sandbox
    // credentials are free from developer.safaricom.co.ke for testing).
    // Set to true only once a real STK payment has gone through end to end. Until then
    // the portal shows the paybill and confirmation flow instead.
    'mpesa_enabled' => false,
    // STK push go-live switch. Leave false until STK is finished and tested; members then
    // see only the paybill. Both this and mpesa_enabled must be true to offer "Pay Now".
    'stk_push_enabled' => false,
    'mpesa_env' => 'sandbox',
    'mpesa_consumer_key' => '',
    'mpesa_consumer_secret' => '',
    'mpesa_shortcode' => '',
    'mpesa_passkey' => '',
    'mpesa_callback_url' => 'https://www.resok.org/resok-portal/public/api/index.php?route=payments/stk/callback',
    // Register the neutral path ...route=payments/stk/callback with Safaricom (Daraja
    // rejects some URLs containing "mpesa"), plus &key=<mpesa_callback_secret> if set.
    'mpesa_callback_secret' => '',

    'upload_dir' => __DIR__ . '/../../uploads',
    'max_file_size' => 5242880,

    'allow_approve_without_payment' => false,
    'setup_key' => '',
    // Staff must set up two-factor before reaching anything. Leave true; false is only the
    // emergency way back in if every admin is locked out.
    'require_staff_mfa' => true,
    // 32+ random characters. Back it up somewhere you will still have in five years: lose
    // it and every encrypted ID number becomes unreadable. Changing it has the same effect,
    // so treat it as permanent once members have registered.
    'data_encryption_key' => '',
    // Super administrators, by email. They see everything: analytics, elections, events and
    // CPD tokens, ICT, security, and the administrators list. Every other admin works on
    // membership only. Leave this empty and NOBODY is a super admin.
    // Must match the email each super admin signs in with; compared case-insensitively,
    // and more than one may be listed. Wrong or misspelled means that person silently
    // loses super-admin access, so check it against the Administrators panel.
    'super_admins' => ['super-admin@resok.org'],
    // Set this and pass ?key=... to cron/renewal-reminders.php if the host only offers URL-triggered cron.
    'cron_secret' => '',
    // "Continue with Google". Google Cloud Console > APIs & Services > Credentials > Create
    // OAuth client ID > Web application, with https://www.resok.org (and https://resok.org)
    // as Authorized JavaScript origins. No redirect URI is needed. Empty hides the button.
    'google_client_id' => '',
    // Abstract emails sent per hour at most (the queue holds the rest). Set it a little under
    // the host's own outgoing-mail limit, which cPanel shows or the host can confirm.
    'abstracts_mail_hourly_limit' => 150,
    // National ILD MDT case submission. Stays off for clinicians until true; super admins and
    // MDT coordinators/panellists can use it before then to set it up. Set data_encryption_key
    // first - case content and files are encrypted with it.
    'mdt_enabled' => false,
    'mdt_retention_months' => 24,
    // Months after a vacancy closes before unsuccessful candidates' CVs and details are deleted.
    'careers_retention_months' => 6,
    'portal_base_url' => 'https://www.resok.org/resok-portal/public',
    'mail_from' => 'no-reply@example.org',
    // Every email is also sent, hidden, to this inbox (except password-setting links).
    // Leave it out to use respiratorysockenya@gmail.com; set '' to turn the copies off.
    // 'mail_archive_bcc' => 'respiratorysockenya@gmail.com',

    'paybill_number' => '303030',
    'paybill_account' => '2038334878',
    'membership_fee' => 5000,
    'membership_categories' => [
        ['name' => 'Associate Membership', 'description' => 'For allied HCPs & students', 'amount' => 2000],
        ['name' => 'Ordinary Membership', 'description' => 'For individuals', 'amount' => 5000],
        ['name' => 'Benefactor Membership - Bronze', 'description' => 'For individuals', 'amount' => 20000],
        ['name' => 'Benefactor Membership - Silver', 'description' => 'For individuals', 'amount' => 30000],
        ['name' => 'Benefactor Membership - Gold', 'description' => 'For individuals', 'amount' => 50000],
        ['name' => 'Organization Membership', 'description' => 'For institutions/corporates', 'amount' => 50000],
    ],
];

