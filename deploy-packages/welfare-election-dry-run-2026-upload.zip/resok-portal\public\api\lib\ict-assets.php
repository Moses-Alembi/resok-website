<?php
declare(strict_types=1);

/**
 * ICT assets, assignments and maintenance.
 *
 * Replaces the equipment spreadsheet. Three things the shape of this file is built around:
 *
 * Assignment is history, not a field. "Who has this laptop" is the newest row with no return
 * date, and every previous holder stays on the record. A current_holder column would answer
 * today's question and destroy the answer to "who had it when it was damaged" - which is the
 * one that actually gets asked, usually months later.
 *
 * A holder is a person, not necessarily an account. Cleaners, drivers and interns are issued
 * equipment and will never have a portal login, so the name is stored directly and the user
 * link is filled in only when there is one.
 *
 * The QR code encodes the asset tag alone - never a URL. A QR that resolves to a public page
 * turns a sticker on a laptop into a way to read the inventory; scanning opens the portal,
 * which then asks who you are.
 */

const ICT_ASSET_CATEGORIES = [
    'laptop' => 'LAP', 'desktop' => 'DSK', 'monitor' => 'MON', 'tablet' => 'TAB',
    'phone' => 'PHN', 'printer' => 'PRN', 'scanner' => 'SCN', 'projector' => 'PRJ',
    'server' => 'SRV', 'router' => 'RTR', 'switch' => 'SWT', 'access_point' => 'WAP',
    'ups' => 'UPS', 'cctv' => 'CCT', 'storage' => 'STO', 'accessory' => 'ACC',
    // The organisation's register is not ICT-only - half of it is furniture, appliances and
    // clinical equipment. One register that answers "what do we own" beats two that each
    // answer half.
    'furniture' => 'FUR', 'appliance' => 'APP', 'medical' => 'MED', 'office' => 'OFF',
    'other' => 'GEN',
];

const ICT_CONDITIONS = ['new', 'good', 'fair', 'poor', 'damaged'];
const ICT_ASSET_STATUSES = ['available', 'assigned', 'maintenance', 'damaged', 'lost', 'retired', 'disposed'];

function ictAssetsEnsureTables(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        $pdo->query('SELECT 1 FROM ict_assets LIMIT 1');
        $pdo->query('SELECT 1 FROM ict_assignments LIMIT 1');
        $pdo->query('SELECT 1 FROM ict_maintenance LIMIT 1');
        return $ready = true;
    } catch (Throwable $e) {
        error_log('ICT asset tables unavailable: ' . $e->getMessage());
        return $ready = false;
    }
}

/**
 * The next tag for a category, e.g. ICT-LAP-0042.
 *
 * Numbered per category rather than globally, because that is how people read a shelf of
 * stickers - the laptops run 0001 upwards whatever else was bought in between.
 */
function ictAssetNextTag(PDO $pdo, string $category): string
{
    $code = ICT_ASSET_CATEGORIES[$category] ?? 'GEN';
    $prefix = 'ICT-' . $code . '-';

    $stmt = $pdo->prepare('SELECT asset_tag FROM ict_assets WHERE asset_tag LIKE ?
                           ORDER BY LENGTH(asset_tag) DESC, asset_tag DESC LIMIT 1');
    $stmt->execute([$prefix . '%']);
    $last = $stmt->fetch();

    $next = 1;
    if ($last && preg_match('/(\d+)$/', (string)$last['asset_tag'], $m)) {
        $next = (int)$m[1] + 1;
    }
    return $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
}

/** The open assignment for an asset, or null when nobody holds it. */
function ictAssetHolder(PDO $pdo, int $assetId): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM ict_assignments
                           WHERE asset_id = ? AND returned_at IS NULL
                           ORDER BY assigned_at DESC, id DESC LIMIT 1');
    $stmt->execute([$assetId]);
    return $stmt->fetch() ?: null;
}

function ictAssetShape(array $row, ?array $holder = null): array
{
    $warranty = null;
    if (!empty($row['warranty_expires_on']) && function_exists('ictInfraHealth')) {
        // Same banding as infrastructure renewals, so an expiring warranty reads the same
        // way as an expiring domain and there is only one thing to learn.
        $warranty = ictInfraHealth($row['warranty_expires_on']);
    }
    return [
        'id'            => (int)$row['id'],
        'version'       => $row['updated_at'] ?? null,   // sent back on save (editConflictGuard)
        'assetTag'      => $row['asset_tag'],
        'category'      => $row['category'],
        'name'          => $row['name'],
        'manufacturer'  => $row['manufacturer'],
        'model'         => $row['model'],
        'serialNumber'  => $row['serial_number'],
        'specifications'=> $row['specifications'],
        'purchaseDate'  => $row['purchase_date'],
        'purchaseCost'  => $row['purchase_cost'] === null ? null : (float)$row['purchase_cost'],
        'currency'      => $row['currency'],
        'supplier'      => $row['supplier'],
        'warrantyExpiresOn' => $row['warranty_expires_on'],
        'warranty'      => $warranty,
        'condition'     => $row['condition'],
        'status'        => $row['status'],
        'location'      => $row['location'],
        'department'    => $row['department'],
        'notes'         => $row['notes'],
        'holder'        => $holder ? [
            'assignmentId' => (int)$holder['id'],
            'name'         => $holder['holder_name'],
            'email'        => $holder['holder_email'],
            'department'   => $holder['department'],
            'since'        => $holder['assigned_at'],
            'conditionOut' => $holder['condition_out'],
        ] : null,
    ];
}

/**
 * The asset list, with the current holder resolved in one query rather than one per row.
 *
 * @param array{search?:string,status?:string,category?:string} $filters
 */
function ictAssetsList(PDO $pdo, array $filters = []): array
{
    if (!ictAssetsEnsureTables($pdo)) return [];

    $where = [];
    $args = [];
    if (!empty($filters['status']) && in_array($filters['status'], ICT_ASSET_STATUSES, true)) {
        $where[] = 'a.status = ?';
        $args[] = $filters['status'];
    }
    if (!empty($filters['category']) && isset(ICT_ASSET_CATEGORIES[$filters['category']])) {
        $where[] = 'a.category = ?';
        $args[] = $filters['category'];
    }
    if (!empty($filters['search'])) {
        // Tag, serial, name, model and the holder's name - the five things someone actually
        // has in front of them when they are looking for a record.
        $where[] = '(a.asset_tag LIKE ? OR a.serial_number LIKE ? OR a.name LIKE ?
                     OR a.model LIKE ? OR h.holder_name LIKE ?)';
        $like = '%' . $filters['search'] . '%';
        array_push($args, $like, $like, $like, $like, $like);
    }
    $clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $sql = "SELECT a.*,
                   h.id AS h_id, h.holder_name, h.holder_email, h.department AS h_department,
                   h.assigned_at, h.condition_out
            FROM ict_assets a
            LEFT JOIN ict_assignments h
              ON h.asset_id = a.id AND h.returned_at IS NULL
            {$clause}
            ORDER BY a.asset_tag
            LIMIT 500";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($args);

    return array_map(function (array $row): array {
        $holder = $row['h_id'] ? [
            'id' => $row['h_id'], 'holder_name' => $row['holder_name'],
            'holder_email' => $row['holder_email'], 'department' => $row['h_department'],
            'assigned_at' => $row['assigned_at'], 'condition_out' => $row['condition_out'],
        ] : null;
        return ictAssetShape($row, $holder);
    }, $stmt->fetchAll());
}

/** One asset with its full history - what a QR scan opens. */
function ictAssetFind(PDO $pdo, int $id): ?array
{
    if (!ictAssetsEnsureTables($pdo)) return null;
    $stmt = $pdo->prepare('SELECT * FROM ict_assets WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) return null;

    $asset = ictAssetShape($row, ictAssetHolder($pdo, $id));

    $history = $pdo->prepare('SELECT * FROM ict_assignments WHERE asset_id = ?
                              ORDER BY assigned_at DESC, id DESC LIMIT 100');
    $history->execute([$id]);
    $asset['assignments'] = array_map(fn($h) => [
        'id'           => (int)$h['id'],
        'name'         => $h['holder_name'],
        'email'        => $h['holder_email'],
        'department'   => $h['department'],
        'assignedAt'   => $h['assigned_at'],
        'conditionOut' => $h['condition_out'],
        'returnedAt'   => $h['returned_at'],
        'conditionIn'  => $h['condition_in'],
        'notes'        => $h['handover_notes'],
        'returnNotes'  => $h['return_notes'],
    ], $history->fetchAll());

    $maint = $pdo->prepare('SELECT * FROM ict_maintenance WHERE asset_id = ?
                            ORDER BY performed_on DESC, id DESC LIMIT 100');
    $maint->execute([$id]);
    $asset['maintenance'] = array_map(fn($m) => [
        'id'          => (int)$m['id'],
        'performedOn' => $m['performed_on'],
        'kind'        => $m['kind'],
        'problem'     => $m['problem_reported'],
        'diagnosis'   => $m['diagnosis'],
        'workDone'    => $m['work_done'],
        'partsUsed'   => $m['parts_used'],
        'technician'  => $m['technician'],
        'vendor'      => $m['vendor'],
        'cost'        => $m['cost'] === null ? null : (float)$m['cost'],
        'currency'    => $m['currency'],
        'result'      => $m['result'],
        'nextDueOn'   => $m['next_due_on'],
        'notes'       => $m['notes'],
    ], $maint->fetchAll());

    return $asset;
}

/** Look one up by the tag on the sticker - the QR scan path. */
function ictAssetFindByTag(PDO $pdo, string $tag): ?array
{
    if (!ictAssetsEnsureTables($pdo)) return null;
    $stmt = $pdo->prepare('SELECT id FROM ict_assets WHERE asset_tag = ? LIMIT 1');
    $stmt->execute([trim($tag)]);
    $row = $stmt->fetch();
    return $row ? ictAssetFind($pdo, (int)$row['id']) : null;
}

/**
 * The scanner's lookup: whatever the barcode reader or a person typed, matched to a tag.
 *
 * The register's stickers carry six-digit numbers (000009). A reader returns them as
 * printed, but someone typing from a worn sticker writes "9" or "0009", so an all-digit
 * value also matches any tag that is the same number once leading zeros are dropped.
 * Spaces are removed first: some readers return the human-readable line with gaps in it.
 */
function ictAssetFindByScan(PDO $pdo, string $scanned): ?array
{
    if (!ictAssetsEnsureTables($pdo)) return null;
    $tag = preg_replace('/\s+/', '', trim($scanned));
    if ($tag === '' || strlen($tag) > 40) return null;

    $found = ictAssetFindByTag($pdo, $tag);
    if ($found || !ctype_digit($tag)) return $found;

    $number = ltrim($tag, '0');
    $stmt = $pdo->prepare("SELECT id FROM ict_assets
                           WHERE asset_tag REGEXP '^[0-9]+$' AND TRIM(LEADING '0' FROM asset_tag) = ?
                           ORDER BY id LIMIT 1");
    $stmt->execute([$number]);
    $row = $stmt->fetch();
    return $row ? ictAssetFind($pdo, (int)$row['id']) : null;
}

/* ------------------------------------------------------------------------------------- */

function ictAssetWritableFields(): array
{
    return [
        'category'          => ['category', 'enum', array_keys(ICT_ASSET_CATEGORIES)],
        'name'              => ['name', 'string', 160],
        'manufacturer'      => ['manufacturer', 'string', 120],
        'model'             => ['model', 'string', 120],
        'serialNumber'      => ['serial_number', 'string', 120],
        'specifications'    => ['specifications', 'text'],
        'purchaseDate'      => ['purchase_date', 'date'],
        'purchaseCost'      => ['purchase_cost', 'decimal'],
        'supplier'          => ['supplier', 'string', 160],
        'warrantyExpiresOn' => ['warranty_expires_on', 'date'],
        'condition'         => ['condition', 'enum', ICT_CONDITIONS],
        'status'            => ['status', 'enum', ICT_ASSET_STATUSES],
        'location'          => ['location', 'string', 160],
        'department'        => ['department', 'string', 120],
        'notes'             => ['notes', 'text'],
    ];
}

function ictAssetNullable(): array
{
    return ['manufacturer', 'model', 'serial_number', 'specifications', 'purchase_date',
            'purchase_cost', 'supplier', 'warranty_expires_on', 'location', 'department', 'notes'];
}

/** @return array{0:array,1:array<string,string>} */
function ictAssetCollect(array $data, bool $isCreate): array
{
    $columns = [];
    $errors = [];

    foreach (ictAssetWritableFields() as $key => $spec) {
        if (!array_key_exists($key, $data)) continue;
        [$column, $kind] = $spec;
        $value = $data[$key];

        if ($value === null || $value === '') {
            if (in_array($column, ictAssetNullable(), true)) $columns[$column] = null;
            continue;
        }
        switch ($kind) {
            case 'enum':
                if (!in_array($value, $spec[2], true)) $errors[$key] = 'Choose one of: ' . implode(', ', $spec[2]) . '.';
                else $columns[$column] = $value;
                break;
            case 'decimal':
                if (!is_numeric($value) || (float)$value < 0) $errors[$key] = 'Must be an amount of zero or more.';
                else $columns[$column] = round((float)$value, 2);
                break;
            case 'date':
                $time = strtotime((string)$value);
                if ($time === false) $errors[$key] = 'Not a date we could read.';
                else $columns[$column] = date('Y-m-d', $time);
                break;
            case 'text':
                $columns[$column] = mb_substr((string)$value, 0, 4000);
                break;
            default:
                $columns[$column] = mb_substr((string)$value, 0, $spec[2] ?? 255);
        }
    }

    if ($isCreate) {
        if (empty($columns['name']) && !isset($errors['name'])) {
            $errors['name'] = 'Give the asset a name, such as "Dell Latitude 5420".';
        }
        if (empty($columns['category']) && !isset($errors['category'])) {
            $errors['category'] = 'Choose a category.';
        }
    }
    if (!empty($columns['purchase_date']) && !empty($columns['warranty_expires_on'])
        && $columns['warranty_expires_on'] < $columns['purchase_date']) {
        $errors['warrantyExpiresOn'] = 'Warranty cannot expire before the asset was bought.';
    }
    return [$columns, $errors];
}

/** @return array{0:?array,1:array<string,string>} */
function ictAssetCreate(PDO $pdo, array $data, ?int $adminUserId): array
{
    if (!ictAssetsEnsureTables($pdo)) {
        return [null, ['_' => 'The asset tables are not available. Apply schema-ict-assets.sql.']];
    }
    [$columns, $errors] = ictAssetCollect($data, true);
    if ($errors) return [null, $errors];

    // A tag may be supplied when labels already exist on the shelf; otherwise one is issued.
    $tag = trim((string)($data['assetTag'] ?? ''));
    if ($tag === '') {
        $tag = ictAssetNextTag($pdo, (string)$columns['category']);
    } else {
        $exists = $pdo->prepare('SELECT id FROM ict_assets WHERE asset_tag = ? LIMIT 1');
        $exists->execute([$tag]);
        if ($exists->fetch()) return [null, ['assetTag' => 'That asset tag is already in use.']];
    }
    $columns['asset_tag'] = $tag;
    $columns['created_by'] = $adminUserId;

    $names = array_map(fn($c) => $c === 'condition' ? '`condition`' : $c, array_keys($columns));
    $pdo->prepare('INSERT INTO ict_assets (' . implode(', ', $names) . ') VALUES ('
                  . implode(', ', array_fill(0, count($names), '?')) . ')')
        ->execute(array_values($columns));

    return [ictAssetFind($pdo, (int)$pdo->lastInsertId()), []];
}

/** @return array{0:?array,1:array<string,string>,2:array} [asset, errors, before] */
function ictAssetUpdate(PDO $pdo, int $id, array $data): array
{
    if (!ictAssetsEnsureTables($pdo)) return [null, ['_' => 'The asset tables are not available.'], []];
    $existing = ictAssetFind($pdo, $id);
    if (!$existing) return [null, ['_' => 'That asset no longer exists.'], []];

    [$columns, $errors] = ictAssetCollect($data, false);
    $bought = array_key_exists('purchase_date', $columns) ? $columns['purchase_date'] : $existing['purchaseDate'];
    $warranty = array_key_exists('warranty_expires_on', $columns) ? $columns['warranty_expires_on'] : $existing['warrantyExpiresOn'];
    if ($bought && $warranty && $warranty < $bought) {
        $errors['warrantyExpiresOn'] = 'Warranty cannot expire before the asset was bought.';
    }
    if ($errors) return [null, $errors, []];
    if (!$columns) return [$existing, [], []];

    $set = implode(', ', array_map(
        fn($c) => ($c === 'condition' ? '`condition`' : $c) . ' = ?', array_keys($columns)));
    $pdo->prepare("UPDATE ict_assets SET {$set} WHERE id = ?")
        ->execute([...array_values($columns), $id]);

    return [ictAssetFind($pdo, $id), [], $existing];
}

/* ------------------------------------------------------------------------------------- */

/**
 * Hands an asset to someone.
 *
 * Refuses if it is already out. Reassigning without a return would leave two open rows and
 * no honest answer to who is holding it - the record has to be returned first, which is also
 * what should happen physically.
 *
 * @return array{0:?array,1:?string} [asset, error]
 */
function ictAssetAssign(PDO $pdo, int $assetId, array $data, ?int $adminUserId): array
{
    if (!ictAssetsEnsureTables($pdo)) return [null, 'The asset tables are not available.'];

    $asset = ictAssetFind($pdo, $assetId);
    if (!$asset) return [null, 'That asset no longer exists.'];
    if ($asset['holder']) {
        return [null, 'This is currently with ' . $asset['holder']['name'] . '. Record its return first.'];
    }
    if (in_array($asset['status'], ['retired', 'disposed', 'lost'], true)) {
        return [null, 'An asset marked ' . $asset['status'] . ' cannot be assigned.'];
    }

    $name = trim((string)($data['holderName'] ?? ''));
    if ($name === '') return [null, 'Who is receiving it?'];

    $condition = in_array($data['conditionOut'] ?? '', ICT_CONDITIONS, true)
        ? $data['conditionOut'] : $asset['condition'];

    // Linked to an account when the address matches one, so an asset shows up against a
    // member record - but never required, because most holders have no login.
    $userId = null;
    $email = trim((string)($data['holderEmail'] ?? ''));
    if ($email !== '') {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1');
        $stmt->execute([strtolower($email)]);
        if ($found = $stmt->fetch()) $userId = (int)$found['id'];
    }

    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO ict_assignments
                        (asset_id, holder_user_id, holder_name, holder_email, department,
                         assigned_at, assigned_by, condition_out, handover_notes)
                       VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?)')
            ->execute([$assetId, $userId, mb_substr($name, 0, 160), $email ?: null,
                       mb_substr(trim((string)($data['department'] ?? '')), 0, 120) ?: null,
                       $adminUserId, $condition,
                       mb_substr(trim((string)($data['notes'] ?? '')), 0, 4000) ?: null]);
        $pdo->prepare("UPDATE ict_assets SET status = 'assigned' WHERE id = ?")->execute([$assetId]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return [null, 'Nothing was changed: ' . $e->getMessage()];
    }
    return [ictAssetFind($pdo, $assetId), null];
}

/**
 * Records a return.
 *
 * The condition it comes back in sets the asset's condition, and anything worse than fair
 * sends it to maintenance rather than straight back on the shelf - otherwise a damaged
 * laptop gets handed to the next person.
 *
 * @return array{0:?array,1:?string}
 */
function ictAssetReturn(PDO $pdo, int $assetId, array $data, ?int $adminUserId): array
{
    if (!ictAssetsEnsureTables($pdo)) return [null, 'The asset tables are not available.'];

    $holder = ictAssetHolder($pdo, $assetId);
    if (!$holder) return [null, 'Nobody is currently holding this.'];

    $condition = in_array($data['conditionIn'] ?? '', ICT_CONDITIONS, true)
        ? (string)$data['conditionIn'] : 'good';
    $status = in_array($condition, ['poor', 'damaged'], true) ? 'maintenance' : 'available';

    $pdo->beginTransaction();
    try {
        $pdo->prepare('UPDATE ict_assignments
                       SET returned_at = NOW(), received_by = ?, condition_in = ?, return_notes = ?
                       WHERE id = ?')
            ->execute([$adminUserId, $condition,
                       mb_substr(trim((string)($data['notes'] ?? '')), 0, 4000) ?: null,
                       (int)$holder['id']]);
        $pdo->prepare('UPDATE ict_assets SET status = ?, `condition` = ? WHERE id = ?')
            ->execute([$status, $condition, $assetId]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return [null, 'Nothing was changed: ' . $e->getMessage()];
    }
    return [ictAssetFind($pdo, $assetId), null];
}

/**
 * Hands an asset straight from its current holder to someone else - "change user".
 *
 * A return followed by an assignment, in one transaction. Done as two requests from a phone
 * in a corridor, a dropped connection between them leaves the item recorded as on the shelf
 * when it is in somebody's bag. The old holder's row is closed with the handover noted, so
 * the chain of custody reads straight through.
 *
 * @return array{0:?array,1:?string}
 */
function ictAssetTransfer(PDO $pdo, int $assetId, array $data, ?int $adminUserId): array
{
    if (!ictAssetsEnsureTables($pdo)) return [null, 'The asset tables are not available.'];

    $asset = ictAssetFind($pdo, $assetId);
    if (!$asset) return [null, 'That asset no longer exists.'];
    if (!$asset['holder']) return [null, 'Nobody is holding this, so assign it instead.'];

    $name = trim((string)($data['holderName'] ?? ''));
    if ($name === '') return [null, 'Who is receiving it?'];
    $email = trim((string)($data['holderEmail'] ?? ''));
    if (strcasecmp($name, (string)$asset['holder']['name']) === 0
        && strcasecmp($email, (string)($asset['holder']['email'] ?? '')) === 0) {
        return [null, 'It is already with ' . $asset['holder']['name'] . '.'];
    }

    $condition = in_array($data['condition'] ?? '', ICT_CONDITIONS, true)
        ? (string)$data['condition'] : $asset['condition'];
    $notes = mb_substr(trim((string)($data['notes'] ?? '')), 0, 4000) ?: null;

    $userId = null;
    if ($email !== '') {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1');
        $stmt->execute([strtolower($email)]);
        if ($found = $stmt->fetch()) $userId = (int)$found['id'];
    }

    $pdo->beginTransaction();
    try {
        $pdo->prepare('UPDATE ict_assignments
                       SET returned_at = NOW(), received_by = ?, condition_in = ?, return_notes = ?
                       WHERE id = ?')
            ->execute([$adminUserId, $condition, 'Handed over to ' . mb_substr($name, 0, 160),
                       (int)$asset['holder']['assignmentId']]);
        $pdo->prepare('INSERT INTO ict_assignments
                        (asset_id, holder_user_id, holder_name, holder_email, department,
                         assigned_at, assigned_by, condition_out, handover_notes)
                       VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?)')
            ->execute([$assetId, $userId, mb_substr($name, 0, 160), $email ?: null,
                       mb_substr(trim((string)($data['department'] ?? '')), 0, 120) ?: null,
                       $adminUserId, $condition, $notes]);
        $pdo->prepare("UPDATE ict_assets SET status = 'assigned', `condition` = ? WHERE id = ?")
            ->execute([$condition, $assetId]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return [null, 'Nothing was changed: ' . $e->getMessage()];
    }
    return [ictAssetFind($pdo, $assetId), null];
}

/** Everything currently held by one person - what to run when someone leaves. */
function ictAssetsHeldBy(PDO $pdo, string $email): array
{
    if (!ictAssetsEnsureTables($pdo)) return [];
    $stmt = $pdo->prepare('SELECT a.*, h.holder_name, h.assigned_at
                           FROM ict_assignments h
                           JOIN ict_assets a ON a.id = h.asset_id
                           WHERE h.returned_at IS NULL AND LOWER(h.holder_email) = ?
                           ORDER BY h.assigned_at');
    $stmt->execute([strtolower(trim($email))]);
    return array_map(fn($r) => [
        'id'       => (int)$r['id'],
        'assetTag' => $r['asset_tag'],
        'name'     => $r['name'],
        'category' => $r['category'],
        'since'    => $r['assigned_at'],
    ], $stmt->fetchAll());
}

/* ------------------------------------------------------------------------------------- */

/** @return array{0:?array,1:?string} */
function ictMaintenanceAdd(PDO $pdo, int $assetId, array $data, ?int $adminUserId): array
{
    if (!ictAssetsEnsureTables($pdo)) return [null, 'The asset tables are not available.'];
    if (!ictAssetFind($pdo, $assetId)) return [null, 'That asset no longer exists.'];

    $performed = strtotime((string)($data['performedOn'] ?? 'today'));
    if ($performed === false) return [null, 'Not a date we could read.'];

    $kinds = ['preventive', 'repair', 'upgrade', 'inspection', 'decommission'];
    $results = ['resolved', 'unresolved', 'replaced', 'written_off'];
    $kind = in_array($data['kind'] ?? '', $kinds, true) ? $data['kind'] : 'repair';
    $result = in_array($data['result'] ?? '', $results, true) ? $data['result'] : 'resolved';

    $nextDue = null;
    if (!empty($data['nextDueOn'])) {
        $t = strtotime((string)$data['nextDueOn']);
        if ($t === false) return [null, 'The next-due date could not be read.'];
        $nextDue = date('Y-m-d', $t);
    }
    $cost = ($data['cost'] ?? '') === '' ? null : (float)$data['cost'];
    if ($cost !== null && $cost < 0) return [null, 'Cost cannot be negative.'];

    $text = fn($key, $max = 4000) => mb_substr(trim((string)($data[$key] ?? '')), 0, $max) ?: null;

    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO ict_maintenance
                        (asset_id, performed_on, kind, problem_reported, diagnosis, work_done,
                         parts_used, technician, vendor, cost, result, next_due_on, notes, recorded_by)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$assetId, date('Y-m-d', $performed), $kind, $text('problem'),
                       $text('diagnosis'), $text('workDone'), $text('partsUsed'),
                       $text('technician', 160), $text('vendor', 160), $cost, $result,
                       $nextDue, $text('notes'), $adminUserId]);

        // A write-off is the end of the asset's life, so the status follows rather than
        // leaving something scrapped sitting in the available pool.
        if ($result === 'written_off') {
            $pdo->prepare("UPDATE ict_assets SET status = 'retired' WHERE id = ?")->execute([$assetId]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return [null, 'Nothing was recorded: ' . $e->getMessage()];
    }
    return [ictAssetFind($pdo, $assetId), null];
}

/** Counts for the ICT Overview. */
function ictAssetsSummary(PDO $pdo): array
{
    if (!ictAssetsEnsureTables($pdo)) {
        return ['total' => 0, 'byStatus' => [], 'value' => 0.0, 'warrantyExpiring' => 0, 'maintenanceDue' => 0];
    }
    $byStatus = [];
    foreach ($pdo->query('SELECT status, COUNT(*) c FROM ict_assets GROUP BY status')->fetchAll() as $row) {
        $byStatus[$row['status']] = (int)$row['c'];
    }
    $one = fn(string $sql) => (int)($pdo->query($sql)->fetch()['c'] ?? 0);

    return [
        'total'    => array_sum($byStatus),
        'byStatus' => $byStatus,
        'value'    => (float)($pdo->query("SELECT COALESCE(SUM(purchase_cost),0) v FROM ict_assets
                                           WHERE status NOT IN ('disposed','lost')")->fetch()['v'] ?? 0),
        'warrantyExpiring' => $one("SELECT COUNT(*) c FROM ict_assets
                                     WHERE warranty_expires_on IS NOT NULL
                                       AND warranty_expires_on BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)"),
        'maintenanceDue'   => $one("SELECT COUNT(*) c FROM ict_maintenance
                                     WHERE next_due_on IS NOT NULL AND next_due_on <= CURDATE()"),
    ];
}

// ---------------------------------------------------------------------------------------
// Stock-take
// ---------------------------------------------------------------------------------------

/*
 * A physical check of the register: walk round, scan every sticker found, and the register
 * ticks each one. Whatever is still unticked at the end is what nobody could find.
 *
 * One stock-take is open at a time. While it is, every scan through the tag scanner ticks
 * the asset, whatever else the scan was for, so a check can happen in passing. Finishing
 * keeps the record and lists the assets not seen; nothing is marked lost automatically,
 * because "not found today" is often "in someone's bag", and that is for a person to decide.
 *
 * Retired, disposed and lost assets are not expected to be found, so they do not count
 * towards the total. If one turns up and is scanned anyway, it is ticked all the same.
 */
const ICT_STOCKTAKE_EXCLUDED = ['retired', 'disposed', 'lost'];

function ictStocktakeEnsureTables(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        // The same statements are in server/schema-ict-assets.sql; keep the two in step.
        $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
        $pdo->exec("CREATE TABLE IF NOT EXISTS ict_stocktakes (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(120) NOT NULL,
            started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            started_by INT UNSIGNED NULL,
            finished_at DATETIME NULL,
            finished_by INT UNSIGNED NULL,
            expected INT UNSIGNED NULL,
            PRIMARY KEY (id),
            KEY ict_stocktakes_open (finished_at)
        )" . $tail);
        $pdo->exec("CREATE TABLE IF NOT EXISTS ict_stocktake_scans (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            stocktake_id INT UNSIGNED NOT NULL,
            asset_id INT UNSIGNED NOT NULL,
            scanned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            scanned_by INT UNSIGNED NULL,
            PRIMARY KEY (id),
            UNIQUE KEY ict_stocktake_scans_once (stocktake_id, asset_id),
            KEY ict_stocktake_scans_asset (asset_id)
        )" . $tail);
        return $ready = true;
    } catch (Throwable $e) {
        error_log('Stock-take tables unavailable: ' . $e->getMessage());
        return $ready = false;
    }
}

function ictStocktakeExpectedSql(string $alias = ''): string
{
    return $alias . "status NOT IN ('" . implode("','", ICT_STOCKTAKE_EXCLUDED) . "')";
}

/** The open stock-take with its progress, or null. */
function ictStocktakeCurrent(PDO $pdo): ?array
{
    if (!ictStocktakeEnsureTables($pdo)) return null;
    $row = $pdo->query('SELECT * FROM ict_stocktakes WHERE finished_at IS NULL ORDER BY id DESC LIMIT 1')->fetch();
    return $row ? ictStocktakeShape($pdo, $row) : null;
}

function ictStocktakeShape(PDO $pdo, array $row): array
{
    $id = (int)$row['id'];
    $open = $row['finished_at'] === null;
    // While open, the total follows the register (an asset added mid-count counts); once
    // finished, it is the number frozen at that moment.
    $expected = $open
        ? (int)$pdo->query('SELECT COUNT(*) FROM ict_assets WHERE ' . ictStocktakeExpectedSql())->fetchColumn()
        : (int)$row['expected'];
    $seen = $pdo->prepare('SELECT COUNT(*) FROM ict_stocktake_scans s JOIN ict_assets a ON a.id = s.asset_id
                           WHERE s.stocktake_id = ? AND ' . ictStocktakeExpectedSql('a.'));
    $seen->execute([$id]);
    $seenExpected = (int)$seen->fetchColumn();
    $all = $pdo->prepare('SELECT COUNT(*) FROM ict_stocktake_scans WHERE stocktake_id = ?');
    $all->execute([$id]);
    return [
        'id' => $id, 'name' => $row['name'], 'open' => $open,
        'startedAt' => $row['started_at'], 'finishedAt' => $row['finished_at'],
        'expected' => $expected, 'seen' => $seenExpected,
        'extra' => (int)$all->fetchColumn() - $seenExpected,   // retired or lost items that turned up
    ];
}

/** @return array{0: ?array, 1: ?string} [stock-take, error] */
function ictStocktakeStart(PDO $pdo, string $name, int $userId): array
{
    if (!ictStocktakeEnsureTables($pdo)) return [null, 'The stock-take tables could not be created.'];
    if (ictStocktakeCurrent($pdo)) return [null, 'A stock-take is already open. Finish it before starting another.'];
    $name = trim((string)preg_replace('/\s+/', ' ', $name));
    if ($name === '') $name = 'Stock-take ' . date('j M Y');
    $pdo->prepare('INSERT INTO ict_stocktakes (name, started_by) VALUES (?, ?)')->execute([mb_substr($name, 0, 120), $userId]);
    return [ictStocktakeCurrent($pdo), null];
}

/**
 * Ticks one asset in the open stock-take. Ticking twice keeps the first time, so the
 * record says when it was first found.
 *
 * @return array{stocktake: ?array, verifiedAt: ?string, already: bool}
 */
function ictStocktakeVerify(PDO $pdo, int $assetId, int $userId): array
{
    $current = ictStocktakeCurrent($pdo);
    if (!$current) return ['stocktake' => null, 'verifiedAt' => null, 'already' => false];
    $insert = $pdo->prepare('INSERT IGNORE INTO ict_stocktake_scans (stocktake_id, asset_id, scanned_by) VALUES (?, ?, ?)');
    $insert->execute([$current['id'], $assetId, $userId]);
    $at = $pdo->prepare('SELECT scanned_at FROM ict_stocktake_scans WHERE stocktake_id = ? AND asset_id = ?');
    $at->execute([$current['id'], $assetId]);
    return ['stocktake' => ictStocktakeCurrent($pdo), 'verifiedAt' => $at->fetchColumn() ?: null, 'already' => $insert->rowCount() === 0];
}

/** Takes a tick off again, for a scan of the wrong sticker. */
function ictStocktakeUnverify(PDO $pdo, int $assetId): ?array
{
    $current = ictStocktakeCurrent($pdo);
    if (!$current) return null;
    $pdo->prepare('DELETE FROM ict_stocktake_scans WHERE stocktake_id = ? AND asset_id = ?')->execute([$current['id'], $assetId]);
    return ictStocktakeCurrent($pdo);
}

/** When each asset was ticked in a stock-take: [asset id => scanned_at]. */
function ictStocktakeTicks(PDO $pdo, int $stocktakeId): array
{
    $stmt = $pdo->prepare('SELECT asset_id, scanned_at FROM ict_stocktake_scans WHERE stocktake_id = ?');
    $stmt->execute([$stocktakeId]);
    return array_column($stmt->fetchAll(), 'scanned_at', 'asset_id');
}

/** Freezes the count and returns the report. @return array{0: ?array, 1: ?string} */
function ictStocktakeFinish(PDO $pdo, int $userId): array
{
    $current = ictStocktakeCurrent($pdo);
    if (!$current) return [null, 'There is no open stock-take.'];
    $pdo->prepare('UPDATE ict_stocktakes SET finished_at = NOW(), finished_by = ?, expected = ? WHERE id = ? AND finished_at IS NULL')
        ->execute([$userId, $current['expected'], $current['id']]);
    return [ictStocktakeReport($pdo, $current['id']), null];
}

/**
 * The outcome of a stock-take: what was not seen, with who holds it and where it should be,
 * which is what someone needs in hand to go and look.
 *
 * Assets added after a stock-take finished are not listed as missing from it.
 */
function ictStocktakeReport(PDO $pdo, int $id): ?array
{
    if (!ictStocktakeEnsureTables($pdo)) return null;
    $stmt = $pdo->prepare('SELECT * FROM ict_stocktakes WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) return null;
    $cutoff = $row['finished_at'] ?? date('Y-m-d H:i:s');
    $missing = $pdo->prepare('SELECT a.id, a.asset_tag, a.name, a.status, a.location, a.department, h.holder_name
                              FROM ict_assets a
                              LEFT JOIN ict_assignments h ON h.asset_id = a.id AND h.returned_at IS NULL
                              LEFT JOIN ict_stocktake_scans s ON s.asset_id = a.id AND s.stocktake_id = ?
                              WHERE s.id IS NULL AND ' . ictStocktakeExpectedSql('a.') . ' AND a.created_at <= ?
                              ORDER BY a.asset_tag');
    $missing->execute([$id, $cutoff]);
    return ictStocktakeShape($pdo, $row) + [
        'missing' => array_map(static fn($r) => [
            'id' => (int)$r['id'], 'assetTag' => $r['asset_tag'], 'name' => $r['name'], 'status' => $r['status'],
            'location' => $r['location'], 'department' => $r['department'], 'holder' => $r['holder_name'],
        ], $missing->fetchAll()),
    ];
}

/** Finished stock-takes, newest first. */
function ictStocktakeHistory(PDO $pdo, int $limit = 10): array
{
    if (!ictStocktakeEnsureTables($pdo)) return [];
    $rows = $pdo->query('SELECT * FROM ict_stocktakes WHERE finished_at IS NOT NULL ORDER BY finished_at DESC LIMIT ' . (int)$limit)->fetchAll();
    return array_map(static fn($r) => ictStocktakeShape($pdo, $r), $rows);
}
